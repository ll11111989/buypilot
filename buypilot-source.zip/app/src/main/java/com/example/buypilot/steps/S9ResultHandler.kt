package com.example.buypilot.steps

import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.StepHandler
import com.example.buypilot.state.StepOutcome

/**
 * S9 RESULT — verify the reported submit result and complete
 * the run only on a confirmed success. S9 performs no submit
 * action of its own, so an Advance here can never resubmit:
 * it only completes a run whose submit already happened.
 *
 * Dispatch invariant: S9 requires snapshot.submitted = true.
 * If the machine reaches S9 without a dispatch (for example
 * a test wiring that skipped S8's onDispatch), the handler
 * Pauses (E08) and never completes — a result without a
 * submit is a flow error, not a success.
 *
 * Outcome mapping (this package's mapping, for QA to check):
 * - time over limit -> Pause; queue -> Wait (E02, which the
 *   core already routes to UNKNOWN after submit); 541 ->
 *   Block (E03); CAPTCHA -> Block (E04); loading -> Stay.
 * - page ERROR/UNKNOWN, or page not RESULT -> see below:
 *   ERROR/UNKNOWN page with submitted = true is treated as
 *   an unknown result (Fail, E18), not as a page mismatch,
 *   because after a dispatch a missing result page means
 *   the result cannot be determined.
 * - result SUCCESS -> Advance (run completes at S9).
 * - result UNKNOWN, or no result reported (null) -> Fail
 *   (E18, submit result unknown). With submitted = true
 *   the core routes this to UNKNOWN, which is exactly the
 *   master priority for an unknown post-submit result, and
 *   it never auto-resubmits.
 * - result PENDING -> Stay (result not yet determined;
 *   re-check next execute; the flow layer, not this handler,
 *   decides when pending becomes unknown).
 * - result DECLINED -> Decline (E19, explicit refusal).
 *   Resolved by D-34 (2026-10-27): the core decline()
 *   mapping was changed so an explicit refusal after
 *   submit ends as DECLINED, not UNKNOWN — a known result
 *   reported accurately. (Before D-34 the core routed it
 *   to UNKNOWN; that was this handler's former open item,
 *   now closed. The handler itself did not change.)
 */
class S9ResultHandler(
    private val driver: PageDriver,
) : StepHandler {

    override fun execute(snapshot: MachineSnapshot): StepOutcome {
        StepChecks.timeCheck(snapshot)?.let { return it }
        val model = driver.snapshot()
        StepChecks.globalPageCheck(model)?.let { return it }
        if (!snapshot.submitted) {
            return StepOutcome.Pause(reason = "SUBMIT_NOT_DISPATCHED", errorId = "E08")
        }
        if (model.pageState == PageState.ERROR || model.pageState == PageState.UNKNOWN) {
            return StepOutcome.Fail(reason = "RESULT_UNKNOWN", errorId = "E18")
        }
        if (model.pageState != PageState.RESULT) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        return when (model.resultStatus) {
            ResultStatus.SUCCESS -> StepOutcome.Advance
            ResultStatus.PENDING -> StepOutcome.Stay
            ResultStatus.DECLINED ->
                StepOutcome.Decline
            ResultStatus.UNKNOWN, null ->
                StepOutcome.Fail(reason = "RESULT_UNKNOWN", errorId = "E18")
        }
    }
}
