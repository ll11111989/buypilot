package com.example.buypilot.integration

import com.example.buypilot.payment.CardSession
import com.example.buypilot.payment.CardValidator
import com.example.buypilot.storage.PickupGroup
import com.example.buypilot.storage.ProductGroup
import com.example.buypilot.storage.ProfileInput
import com.example.buypilot.storage.ProfileRepository
import com.example.buypilot.storage.SaveBlock
import com.example.buypilot.storage.SaveOutcome
import com.example.buypilot.storage.WorkingCopy

/**
 * S6 "save as combination" wiring (D-47 explicit-save only).
 *
 * This is the SOLE call point that turns a live S6 input into
 * a stored combination. It is called only from the S6 screen's
 * "儲存為組合" button, after the user has confirmed a
 * combination name. Nothing else in the app calls
 * saveProfile: run input, S7 filling, submit completion /
 * refusal, timeout, cancel and background never reach here.
 *
 * Why the borrow-then-materialize shape (read this before
 * changing it): CardSession.withCardData lends the buffers
 * and clears them in `finally` (SESSION_ENDED) — that is
 * S6/S7's standing contract and this wiring does not weaken
 * it. So the save must be ordered as:
 *  1. Pre-check WITHOUT touching card data (name non-empty,
 *     name unique, count under cap, all from listProfiles
 *     summaries). A pre-check failure returns with the
 *     session fully intact — the user fixes the name and
 *     retries, nothing is lost.
 *  2. One borrow: build ProfileInput from the number/expiry
 *     buffers (CVV is never saved, D-46 — ProfileInput has
 *     no CVV field), call saveProfile, then immediately
 *     materializeForRun with the borrowed CVV copy so the
 *     CURRENT run can continue from the stored WorkingCopy.
 *     The borrow's `finally` then clears the session, as
 *     designed; the run no longer needs it.
 *  3. After the borrow, the flow layer continues the run
 *     via the returned WorkingCopy (S7 stored path, see
 *     S7StoredCopyWiring — its finally calls close()).
 *     The Saved outcome also carries the S6 session's
 *     already-elapsed clocks, read BEFORE the borrow
 *     (absolute + idle, D-54 carry-over): the flow layer
 *     must pass them to the S7 stored path so the D-19
 *     absolute cap keeps running from the original S6
 *     begin instead of restarting on a fresh clock.
 *
 * Defensive outcomes, stated not hidden:
 * - SaveBlockedAfterBorrow: saveProfile still blocked after
 *   a passing pre-check (only possible if the store changed
 *   between pre-check and save on another thread). The
 *   session is already ended by the borrow, so the flow
 *   layer must return the user to S6 re-input. This path
 *   cannot happen in the single-threaded UI flow.
 * - MaterializeFailedAfterBorrow: the combination WAS saved
 *   (it exists for future runs), but the current run could
 *   not be materialized from it (decryption failure or
 *   missing record). The flow layer must not continue this
 *   run from a half-built copy; it returns to S6 re-input
 *   or lets the user pick the saved combination again.
 * Neither outcome writes a partial combination: saveProfile
 * itself writes only on full success.
 *
 * Read failures (D-79): the pre-check list read, the
 * repository's internal validation read, and the
 * materialize read are all contained — a read failure is
 * STOPPED with a read-failure report (PrecheckReadFailed
 * before the borrow, session intact; SaveReadFailedAfterBorrow
 * inside the borrow, session ended, no write had occurred;
 * a materialize read failure maps to
 * MaterializeFailedAfterBorrow, the combination having
 * been saved). No exception from this call path propagates
 * raw to the screen.
 *
 * Caller responsibility (host): pass the run's product and
 * pickup groups from the S1–S5 configuration. This helper
 * does not invent them.
 */
sealed class SaveS6Outcome {
    data class PrecheckBlocked(val reason: SaveBlock) : SaveS6Outcome()
    object SessionNotReady : SaveS6Outcome()
    data class Saved(
        val copy: WorkingCopy,
        /** S6 absolute clock already consumed at save time (D-54). */
        val absoluteElapsedMs: Long,
        /** S6 idle clock already consumed at save time (D-54). */
        val idleElapsedMs: Long,
    ) : SaveS6Outcome()
    object SaveBlockedAfterBorrow : SaveS6Outcome()
    object MaterializeFailedAfterBorrow : SaveS6Outcome()

    /**
     * Encryption (incl. first key creation) failed inside the
     * borrow (SaveOutcome.EncryptionFailed, Water's D-53
     * reservation (5) supplement): nothing was written and no
     * combination exists afterwards; the borrow still ended
     * the session, so the flow returns to S6 re-input. The
     * handling is STOPPED-style, never a silent success and
     * never confused with a name/limit block.
     */
    object EncryptionFailedAfterBorrow : SaveS6Outcome()

    /**
     * Storage write failed inside the borrow
     * (SaveOutcome.StorageWriteFailed, D-66/D-67): the write
     * status was unknown, so the borrow re-listed (D-67) and
     * the listing proved this combination is NOT stored.
     * The borrow still ended the session, so the flow
     * returns to S6 re-input. STOPPED-style, never a silent
     * success.
     */
    object StorageWriteFailedAfterBorrow : SaveS6Outcome()

    /**
     * Storage write failed AND the D-67 re-list itself
     * failed: the write status cannot be verified at all.
     * The host must tell the user to verify later from the
     * management list and must not assume stored or not
     * stored. The borrow still ended the session.
     */
    object StorageWriteUnverifiableAfterBorrow : SaveS6Outcome()

    /**
     * Pre-save list read failed (D-79): the pre-check's
     * listProfiles read (the D-48 uniqueness / D-49 cap
     * prerequisite) threw, BEFORE any card data was
     * touched. No save was attempted and the session is
     * fully intact — the user retries from the same input.
     * STOPPED-style: the host must report the read failure
     * and must not silently continue to saveProfile, and
     * the exception must not propagate raw to the screen.
     */
    object PrecheckReadFailed : SaveS6Outcome()

    /**
     * The repository's own validation read inside
     * saveProfile threw (D-79, host-contained): saveProfile
     * reads the store before encrypting or writing
     * anything, so a throw from that read means no save
     * was performed; the borrow still ended the session,
     * so the flow returns to S6 re-input. STOPPED-style.
     * Contained here at the host layer — the repository
     * interface is unchanged.
     */
    object SaveReadFailedAfterBorrow : SaveS6Outcome()
}

fun saveS6InputAsProfile(
    repository: ProfileRepository,
    name: String,
    product: ProductGroup,
    pickup: PickupGroup,
    session: CardSession,
): SaveS6Outcome {
    if (!session.isActive || !session.hasAllFields()) {
        return SaveS6Outcome.SessionNotReady
    }
    val trimmedName = name.trim()
    if (trimmedName.isEmpty()) {
        return SaveS6Outcome.PrecheckBlocked(SaveBlock.EMPTY_NAME)
    }
    // D-79: the pre-check read is the D-48/D-49 prerequisite.
    // A failure here is STOPPED with a read-failure report —
    // never a silent continue to saveProfile, never a raw
    // throw to the screen. The session is untouched (the
    // borrow has not started), so the user retries as-is.
    val summaries = try {
        repository.listProfiles()
    } catch (e: Exception) {
        return SaveS6Outcome.PrecheckReadFailed
    }
    val key = trimmedName.lowercase()
    if (summaries.any { it.name.trim().lowercase() == key }) {
        return SaveS6Outcome.PrecheckBlocked(SaveBlock.DUPLICATE_NAME)
    }
    if (summaries.size >= ProfileRepository.MAX_PROFILES) {
        return SaveS6Outcome.PrecheckBlocked(SaveBlock.LIMIT_REACHED)
    }
    // D-54 carry-over: read the clocks BEFORE the borrow ends
    // the session; the S7 stored path needs them intact.
    val absoluteElapsedMs = session.absoluteElapsedMs()
    val idleElapsedMs = session.idleElapsedMs()
    var encryptionFailed = false
    var writeFailedVerified = false
    var writeUnverifiable = false
    var saveReadFailed = false
    var materializeThrew = false
    val materialized = session.withCardData { buffers ->
        val input = ProfileInput(
            name = trimmedName,
            product = product,
            pickup = pickup,
            cardNumber = buffers.getValue(CardValidator.Field.CARD_NUMBER),
            expiry = buffers.getValue(CardValidator.Field.EXPIRY),
        )
        // materializeForRun reads the store itself; a throw
        // from that read must not escape raw either (D-79's
        // no-raw-propagation rule for this call path). The
        // combination WAS saved at this point, so a throw
        // maps to the materialize-failed outcome below.
        val materialize: (String) -> com.example.buypilot.storage.MaterializeOutcome? =
            { id ->
                try {
                    repository.materializeForRun(
                        id,
                        buffers.getValue(CardValidator.Field.CVV),
                    )
                } catch (e: Exception) {
                    materializeThrew = true
                    null
                }
            }
        // D-79: saveProfile's internal validation read can
        // throw before any write; contain it here (host
        // layer, repository interface unchanged).
        val savedOutcome = try {
            repository.saveProfile(input)
        } catch (e: Exception) {
            saveReadFailed = true
            null
        }
        when (savedOutcome) {
            null -> null
            is SaveOutcome.Saved -> materialize(savedOutcome.id)
            is SaveOutcome.Blocked -> null
            SaveOutcome.EncryptionFailed -> {
                encryptionFailed = true
                null
            }
            SaveOutcome.StorageWriteFailed -> {
                // D-67: the write status is unknown (the
                // backend deletes the old file before
                // retrying the rename, so neither "unchanged"
                // nor "written" can be assumed). Re-list
                // inside the borrow, while the CVV is still
                // available: a listed entry with this name
                // must be the new combination (the pre-check
                // proved the name was unused), so the run
                // can continue from it; absence proves it
                // was not stored; a listing failure proves
                // nothing and is reported as unverifiable.
                val listed = try {
                    repository.listProfiles()
                } catch (e: Exception) {
                    null
                }
                val found = listed?.firstOrNull {
                    it.name.trim().lowercase() == trimmedName.lowercase()
                }
                when {
                    found != null -> materialize(found.id)
                    listed == null -> {
                        writeUnverifiable = true
                        null
                    }
                    else -> {
                        writeFailedVerified = true
                        null
                    }
                }
            }
        }
    }
    if (encryptionFailed) return SaveS6Outcome.EncryptionFailedAfterBorrow
    if (saveReadFailed) return SaveS6Outcome.SaveReadFailedAfterBorrow
    if (writeUnverifiable) return SaveS6Outcome.StorageWriteUnverifiableAfterBorrow
    if (writeFailedVerified) return SaveS6Outcome.StorageWriteFailedAfterBorrow
    if (materializeThrew) return SaveS6Outcome.MaterializeFailedAfterBorrow
    return when (materialized) {
        is com.example.buypilot.storage.MaterializeOutcome.Ok ->
            SaveS6Outcome.Saved(materialized.copy, absoluteElapsedMs, idleElapsedMs)
        is com.example.buypilot.storage.MaterializeOutcome.DecryptionFailed,
        is com.example.buypilot.storage.MaterializeOutcome.NotFound ->
            SaveS6Outcome.MaterializeFailedAfterBorrow
        null -> SaveS6Outcome.SaveBlockedAfterBorrow
    }
}
