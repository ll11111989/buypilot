package com.example.buypilot.state

/**
 * P2 state-machine core — what a step handler may return.
 *
 * A handler returns exactly one outcome. The machine, not the
 * handler, owns the global transition, so a handler can never
 * jump to another step, clear card data, or resubmit on its own.
 *
 * - Advance: this step is done; the machine moves to the next step
 *   (or completes the run at S9).
 * - Stay: stay on the same step for a re-check. This is the generic
 *   retry hook future S5 handlers will use (e.g. trying the next
 *   store/slot in the user's pre-set priority list, E13, or
 *   returning to S5 to fix rejected data, E14). The core does not
 *   choose the next store or fix the data — that is S5's package.
 * - Pause: halt as STOPPED. The run is resumable to the same step
 *   with re-validation. Future S2 handlers will use this for
 *   stop conditions such as E09 sold out / E10 price mismatch;
 *   the core does not decide which S2 condition maps to Pause
 *   versus Fail — that mapping belongs to the S2 package and its
 *   summary for Kenneth. The core only guarantees Pause never
 *   advances and never auto-retries.
 * - Wait: halt as WAITING (E02). The machine records the step it
 *   left; resume returns there with re-validation.
 * - Block: halt as BLOCKED (E03/E04). Never auto-resumed.
 * - Cancel / Decline / Fail: terminal outcomes, subject to the
 *   submitted-priority rule in StateMachine (after submit dispatch
 *   they become UNKNOWN, never CANCELLED/DECLINED).
 *
 * errorId, when present, must be a master-spec E-number (e.g. E02)
 * or null. Handlers must never invent a new E-number.
 */
sealed class StepOutcome {
    object Advance : StepOutcome()
    object Stay : StepOutcome()
    data class Pause(val reason: String, val errorId: String? = null) : StepOutcome()
    data class Wait(val reason: String, val errorId: String? = null) : StepOutcome()
    data class Block(val reason: String, val errorId: String? = null) : StepOutcome()
    object Cancel : StepOutcome()
    object Decline : StepOutcome()
    data class Fail(val reason: String, val errorId: String? = null) : StepOutcome()
}

/**
 * A step handler. It receives a read-only snapshot and returns one
 * outcome. It must not perform page filling, submission, or card
 * handling — those belong to their own locked/gated packages.
 */
fun interface StepHandler {
    fun execute(snapshot: MachineSnapshot): StepOutcome
}

/**
 * Placeholder for steps whose work package has not arrived yet
 * (in this delivery: S1–S5). It never advances, never fails the
 * run, and never touches a page: it pauses the run so a human can
 * see exactly where the machine stopped and why.
 */
object NotImplementedStepHandler : StepHandler {
    override fun execute(snapshot: MachineSnapshot): StepOutcome =
        StepOutcome.Pause(
            reason = "STEP_NOT_IMPLEMENTED",
            errorId = null,
        )
}
