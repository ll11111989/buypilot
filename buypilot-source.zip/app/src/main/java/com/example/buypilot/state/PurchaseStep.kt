package com.example.buypilot.state

/**
 * P2 state-machine core — step IDs.
 *
 * These IDs are frozen by the master spec v1.2 and are NOT renumbered
 * or renamed here. The full order is declared so later packages
 * (S1–S3, S4–S5, S6 host, S8, S9) can plug handlers into the same
 * machine without changing the core. This package implements NO
 * page logic for any step: S1–S5 handlers are placeholders until
 * their own work packages arrive, S6 is owned by the existing
 * app-s6 payment module, and S7 is locked (see StateMachine).
 */
enum class PurchaseStep(val code: String) {
    S1_ENTRY("S1"),
    S2_CONFIGURE("S2"),
    S3_ADD_TO_BAG("S3"),
    S4_CHECKOUT("S4"),
    S5_FULFILLMENT("S5"),
    S6_PAYMENT_INPUT("S6"),
    S7_PAYMENT_FILL("S7"),
    S8_SUBMIT_CONFIRM("S8"),
    S9_RESULT("S9");

    /** Next step in master order, or null after S9. */
    fun next(): PurchaseStep? = when (this) {
        S1_ENTRY -> S2_CONFIGURE
        S2_CONFIGURE -> S3_ADD_TO_BAG
        S3_ADD_TO_BAG -> S4_CHECKOUT
        S4_CHECKOUT -> S5_FULFILLMENT
        S5_FULFILLMENT -> S6_PAYMENT_INPUT
        S6_PAYMENT_INPUT -> S7_PAYMENT_FILL
        S7_PAYMENT_FILL -> S8_SUBMIT_CONFIRM
        S8_SUBMIT_CONFIRM -> S9_RESULT
        S9_RESULT -> null
    }

    /** True for steps at or after S6, where card clearing applies. */
    val isPaymentSegmentOrLater: Boolean
        get() = ordinal >= S6_PAYMENT_INPUT.ordinal
}
