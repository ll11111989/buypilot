package com.example.buypilot.steps

import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.StepHandler
import com.example.buypilot.state.StepOutcome

/**
 * S8 SUBMIT_CONFIRM — revised for automatic submission
 * (D-31 + D-36, Kenneth, main chat, 2026-10-27).
 *
 * What changed from the original (v1.2) handler: there is
 * NO general user-confirmation gate any more. Once the
 * page and summary checks pass, the handler dispatches
 * automatically via [onDispatch] and advances to S9 —
 * the flow layer's onDispatch performs the actual page
 * submit and calls machine.markSubmitted(), exactly as
 * before; this handler still performs no submission
 * itself, and an onDispatch exception still surfaces
 * instead of becoming an Advance.
 *
 * What did NOT change, deliberately (design point, stated
 * for QA/Kenneth, not silently kept): the summary is still
 * verified exactly (product / total / pickup, Pause E08
 * on any mismatch or missing fact) and the sold-out /
 * fulfillment-rejected halts remain. No ruling has named
 * the S8 summary check for removal; D-36's pattern is that
 * automatic flow still stops for known integrity
 * exceptions, and submitting an order whose page summary
 * differs from the configured one is exactly that class.
 * If Kenneth wants the summary check removed as well, one
 * ruling removes it — this handler does not guess.
 *
 * D-36 exception — unverified fields (E16 read-back was
 * impossible at S7): they are NEVER silently auto-submitted.
 * The flow layer passes S7's reported codes in through
 * [unverifiedProvider] (field CODES only, never values):
 * - no unverified fields -> automatic dispatch as above.
 * - unverified fields present and NOT all item-confirmed:
 *   the handler lists them item by item through
 *   [onUnverifiedListed] (the flow layer displays them)
 *   and returns Stay — no dispatch, no cancel. Only when
 *   the user has confirmed EACH listed field individually
 *   (its code present in
 *   [S8UnverifiedStatus.confirmedCodes]) does a later
 *   execute dispatch. Partial confirmation never dispatches.
 * The status is re-asked from the provider on every
 * execute(), never cached by the handler, so a WAITING /
 * STOPPED resume uses the current confirmations, not
 * stale ones. If the user never confirms, the run simply
 * stays at S8; leaving it is the user's explicit cancel
 * through the machine API, not a handler outcome.
 *
 * Outcome mapping (this package's mapping, for QA to check):
 * - time over limit -> Pause; queue -> Wait (E02); 541 ->
 *   Block (E03); CAPTCHA -> Block (E04); loading -> Stay.
 * - sold out -> Pause (E09); fulfillment data rejected ->
 *   Pause (E14); page not SUBMIT_CONFIRM, or summary
 *   mismatch/missing -> Pause (E08).
 * - unverified fields not fully item-confirmed -> listed
 *   item by item, then Stay.
 * - all checks pass -> onDispatch(), then Advance to S9.
 */
data class SummaryData(
    val productKey: String,
    val totalText: String,
    val pickupText: String,
)

data class S8UnverifiedStatus(
    val fieldCodes: List<String> = emptyList(),
    val confirmedCodes: Set<String> = emptySet(),
)

class S8SubmitConfirmHandler(
    private val driver: PageDriver,
    private val summary: SummaryData,
    private val unverifiedProvider: () -> S8UnverifiedStatus,
    private val onDispatch: () -> Unit,
    private val onUnverifiedListed: (List<String>) -> Unit = {},
) : StepHandler {

    init {
        require(summary.productKey.isNotBlank()) { "S8 summary productKey must be supplied" }
        require(summary.totalText.isNotBlank()) { "S8 summary totalText must be supplied" }
        require(summary.pickupText.isNotBlank()) { "S8 summary pickupText must be supplied" }
    }

    override fun execute(snapshot: MachineSnapshot): StepOutcome {
        StepChecks.timeCheck(snapshot)?.let { return it }
        val model = driver.snapshot()
        StepChecks.globalPageCheck(model)?.let { return it }
        if (model.pageState == PageState.ERROR || model.pageState == PageState.UNKNOWN) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        if (model.soldOut) {
            return StepOutcome.Pause(reason = "SOLD_OUT", errorId = "E09")
        }
        if (model.fulfillmentDataRejected) {
            return StepOutcome.Pause(reason = "FULFILLMENT_DATA_REJECTED", errorId = "E14")
        }
        if (model.pageState != PageState.SUBMIT_CONFIRM) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        if (model.summaryProductKey != summary.productKey ||
            model.summaryTotalText != summary.totalText ||
            model.summaryPickupText != summary.pickupText
        ) {
            return StepOutcome.Pause(reason = "SUMMARY_MISMATCH", errorId = "E08")
        }
        val unverified = unverifiedProvider()
        if (unverified.fieldCodes.isNotEmpty() &&
            !unverified.confirmedCodes.containsAll(unverified.fieldCodes)
        ) {
            // D-36: list item by item, never silently submit.
            onUnverifiedListed(unverified.fieldCodes)
            return StepOutcome.Stay
        }
        onDispatch()
        return StepOutcome.Advance
    }
}
