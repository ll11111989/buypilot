package com.example.buypilot.flow

import android.content.Intent
import com.example.buypilot.steps.SummaryData
import com.example.buypilot.storage.PickupGroup
import com.example.buypilot.storage.ProductGroup

/**
 * Run-configuration transport (Android only): builds a
 * FlowConfig from Intent extras supplied by the launcher
 * (a future product-selection UI or the D-28 trigger).
 *
 * Required extras: product_key, summary_total_text,
 * summary_pickup_text. Optional: summary_product_key
 * (defaults to product_key), stores (string array; S5
 * requires at least one non-blank, distinct store —
 * invalid lists yield null here rather than a handler
 * construction crash), profile_id (stored path when
 * present). NOTE (D-27 alignment): price and quantity
 * are no longer run parameters — S2 no longer compares
 * price and S3 no longer verifies quantity — so the
 * launcher need not supply them.
 *
 * Optional save-group extras (S6 save button, D-47/D-54):
 * model, colour, capacity, group_quantity (> 0),
 * apple_care ("true"/"false"), trade_in ("true"/"false"),
 * method, slot_preference, pickup_name, pickup_phone,
 * pickup_email, delivery_address. When model, colour and
 * capacity are all present and group_quantity is positive,
 * the product/pickup groups are built (method defaults to
 * "pickup", storePriority reuses the run's stores, the
 * rest default to null); otherwise both groups are null
 * and the host passes no save callbacks, so the save
 * button stays hidden — the host never invents groups.
 * NOTE: group_quantity is the saved combination's
 * quantity field only; it is NOT a flow parameter and
 * S3 does not use it.
 *
 * Returns null when anything required is missing or
 * invalid: the host invents no product, price, or summary,
 * and a run simply cannot be built until the launcher
 * supplies a complete configuration.
 */
object FlowIntentConfig {
    private const val PREFIX = "buypilot.flow."
    const val EXTRA_PRODUCT_KEY = PREFIX + "product_key"
    const val EXTRA_STORES = PREFIX + "stores"
    const val EXTRA_SUMMARY_PRODUCT_KEY = PREFIX + "summary_product_key"
    const val EXTRA_SUMMARY_TOTAL_TEXT = PREFIX + "summary_total_text"
    const val EXTRA_SUMMARY_PICKUP_TEXT = PREFIX + "summary_pickup_text"
    const val EXTRA_PROFILE_ID = PREFIX + "profile_id"
    const val EXTRA_MODEL = PREFIX + "model"
    const val EXTRA_COLOUR = PREFIX + "colour"
    const val EXTRA_CAPACITY = PREFIX + "capacity"
    const val EXTRA_GROUP_QUANTITY = PREFIX + "group_quantity"
    const val EXTRA_APPLE_CARE = PREFIX + "apple_care"
    const val EXTRA_TRADE_IN = PREFIX + "trade_in"
    const val EXTRA_METHOD = PREFIX + "method"
    const val EXTRA_SLOT_PREFERENCE = PREFIX + "slot_preference"
    const val EXTRA_PICKUP_NAME = PREFIX + "pickup_name"
    const val EXTRA_PICKUP_PHONE = PREFIX + "pickup_phone"
    const val EXTRA_PICKUP_EMAIL = PREFIX + "pickup_email"
    const val EXTRA_DELIVERY_ADDRESS = PREFIX + "delivery_address"

    fun fromIntent(intent: Intent): FlowConfig? {
        val productKey = intent.getStringExtra(EXTRA_PRODUCT_KEY)
            ?.takeIf { it.isNotBlank() } ?: return null
        val totalText = intent.getStringExtra(EXTRA_SUMMARY_TOTAL_TEXT)
            ?.takeIf { it.isNotBlank() } ?: return null
        val pickupText = intent.getStringExtra(EXTRA_SUMMARY_PICKUP_TEXT)
            ?.takeIf { it.isNotBlank() } ?: return null
        val stores = intent.getStringArrayExtra(EXTRA_STORES)
            ?.filter { it.isNotBlank() }
            ?.distinct()
            ?: emptyList()
        if (stores.isEmpty()) return null
        val summaryProductKey = intent
            .getStringExtra(EXTRA_SUMMARY_PRODUCT_KEY)
            ?.takeIf { it.isNotBlank() }
            ?: productKey
        fun text(extra: String): String? =
            intent.getStringExtra(extra)?.takeIf { it.isNotBlank() }
        fun triState(extra: String): Boolean? = when (text(extra)) {
            "true" -> true
            "false" -> false
            else -> null
        }
        val model = text(EXTRA_MODEL)
        val colour = text(EXTRA_COLOUR)
        val capacity = text(EXTRA_CAPACITY)
        val groupQuantity = intent.getIntExtra(EXTRA_GROUP_QUANTITY, 0)
        val productGroup = if (model != null && colour != null &&
            capacity != null && groupQuantity > 0
        ) {
            ProductGroup(
                model = model,
                colour = colour,
                capacity = capacity,
                quantity = groupQuantity,
                appleCare = triState(EXTRA_APPLE_CARE),
                tradeIn = triState(EXTRA_TRADE_IN),
            )
        } else {
            null
        }
        val pickupGroup = if (productGroup != null) {
            PickupGroup(
                method = text(EXTRA_METHOD) ?: "pickup",
                storePriority = stores,
                slotPreference = text(EXTRA_SLOT_PREFERENCE),
                pickupName = text(EXTRA_PICKUP_NAME),
                pickupPhone = text(EXTRA_PICKUP_PHONE),
                pickupEmail = text(EXTRA_PICKUP_EMAIL),
                deliveryAddress = text(EXTRA_DELIVERY_ADDRESS),
            )
        } else {
            null
        }
        return FlowConfig(
            productKey = productKey,
            priorityStores = stores,
            summary = SummaryData(summaryProductKey, totalText, pickupText),
            selectedProfileId = intent.getStringExtra(EXTRA_PROFILE_ID)
                ?.takeIf { it.isNotBlank() },
            productGroup = productGroup,
            pickupGroup = pickupGroup,
        )
    }
}
