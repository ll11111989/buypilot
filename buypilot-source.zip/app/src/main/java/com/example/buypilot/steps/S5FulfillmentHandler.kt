package com.example.buypilot.steps

import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.StepHandler
import com.example.buypilot.state.StepOutcome

/**
 * S5 FULFILLMENT — select a store/slot from the user's
 * pre-set priority list, or stop when the list is exhausted;
 * rejected fulfillment data returns to S5 to be fixed and
 * never advances to payment.
 *
 * The priority list ([priorityStores], in order) is supplied
 * by the flow layer and must be non-empty, non-blank and
 * duplicate-free; the handler never invents, reorders or
 * extends it. Availability comes only from the page
 * ([PageModel.storeOptions]): the handler picks the FIRST
 * priority store the page reports as slot-available. It never
 * picks a store outside the list, and it never treats a
 * missing store-options report as availability — no option
 * at all means no store can be selected.
 *
 * The handler does NOT fix rejected data: E14 means the data
 * as reported was rejected, so the handler Pauses (STOPPED)
 * and the flow layer / user fixes the data outside the
 * handler; the next execute re-reads the page and only then
 * proceeds. No handler in this package rewrites user data.
 *
 * Outcome mapping (this package's mapping, for QA to check):
 * - time over limit -> Pause; queue -> Wait (E02); 541 ->
 *   Block (E03); CAPTCHA -> Block (E04); loading -> Stay.
 * - sold out -> Pause (E09), before any selection.
 * - fulfillment data rejected -> Pause (E14), before any
 *   selection and before any Advance; never skips to payment.
 * - already on FULFILLMENT with a selected store that is in
 *   the priority list -> Advance, no selection (idempotent:
 *   resume never re-selects a completed fulfillment, and an
 *   already-fulfilled store is accepted even if it is not
 *   the first priority store — selection order only governs
 *   fresh selection).
 * - already on FULFILLMENT with a selected store outside
 *   the list, or with no selected store -> Pause (E08).
 * - page state not CHECKOUT (and not already FULFILLMENT)
 *   -> Pause (E08); ERROR/UNKNOWN -> Pause (E08).
 * - no priority store slot-available -> Pause (E13, list
 *   exhausted — stop, do not switch delivery method on the
 *   handler's own initiative).
 * - select element missing -> Pause (E05); duplicate ->
 *   Pause (E07); not clickable -> Pause (E06).
 * - selectStore returns false -> Pause (E13, that store/slot
 *   is not actually selectable).
 * - after selection: global page state re-checked first
 *   (queue/blocked/loading); rejected data -> Pause (E14);
 *   page not FULFILLMENT, or selected store not the chosen
 *   store -> Pause (E08); otherwise Advance to S6.
 *
 * Advancing from S5 means "fulfillment complete, S6 may
 * start" — it is not payment filling (S7 stays locked) and
 * it never happens while data is rejected or the list is
 * exhausted.
 */
class S5FulfillmentHandler(
    private val driver: PageDriver,
    private val priorityStores: List<String>,
    private val selectElementId: String = PageElements.STORE_SELECT,
) : StepHandler {

    init {
        require(priorityStores.isNotEmpty()) { "S5 priorityStores must be supplied, not inferred" }
        require(priorityStores.all { it.isNotBlank() }) { "S5 priorityStores must not contain blanks" }
        require(priorityStores.distinct().size == priorityStores.size) {
            "S5 priorityStores must not contain duplicates"
        }
    }

    override fun execute(snapshot: MachineSnapshot): StepOutcome {
        StepChecks.timeCheck(snapshot)?.let { return it }
        var model = driver.snapshot()
        StepChecks.globalPageCheck(model)?.let { return it }
        if (model.pageState == PageState.ERROR || model.pageState == PageState.UNKNOWN) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        if (model.soldOut) {
            return StepOutcome.Pause(reason = "SOLD_OUT", errorId = "E09")
        }
        if (model.fulfillmentDataRejected) {
            return StepOutcome.Pause(reason = "FULFILLMENT_DATA_REJECTED", errorId = "E14")
        }

        // Already fulfilled with a priority store: advance.
        if (model.pageState == PageState.FULFILLMENT) {
            val selected = model.selectedStoreKey
            return if (selected != null && selected in priorityStores) {
                StepOutcome.Advance
            } else {
                StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
            }
        }
        if (model.pageState != PageState.CHECKOUT) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }

        // First priority store the page reports as available.
        val firstAvailable = priorityStores.firstOrNull { key ->
            model.storeOptions.any { it.storeKey == key && it.slotAvailable }
        } ?: return StepOutcome.Pause(reason = "STORE_SLOT_EXHAUSTED", errorId = "E13")

        StepChecks.requireUnique(selectElementId, model)?.let { return it }
        StepChecks.requireClickable(selectElementId, model)?.let { return it }
        if (!driver.selectStore(firstAvailable)) {
            return StepOutcome.Pause(reason = "STORE_SLOT_EXHAUSTED", errorId = "E13")
        }
        model = driver.snapshot()
        StepChecks.afterClickLoading(model)?.let { return it }
        if (model.fulfillmentDataRejected) {
            return StepOutcome.Pause(reason = "FULFILLMENT_DATA_REJECTED", errorId = "E14")
        }
        if (model.pageState != PageState.FULFILLMENT) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        if (model.selectedStoreKey != firstAvailable) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        return StepOutcome.Advance
    }
}
