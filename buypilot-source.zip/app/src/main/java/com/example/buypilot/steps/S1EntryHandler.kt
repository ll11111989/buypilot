package com.example.buypilot.steps

import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.StepHandler
import com.example.buypilot.state.StepOutcome

/**
 * S1 ENTRY — verify the official entry page is reached.
 *
 * Division of labour (so there is no gap and no overlap):
 * S1 only verifies: time deviation, global page state, entry
 * page state, and the unique presence of the entry element.
 * S1 does NOT click and does NOT navigate: product navigation
 * is S2's first action (see S2ConfigureHandler, ENTRY branch).
 * Advancing from S1 therefore means "entry verified, S2 may
 * navigate", not "already on the product page".
 *
 * Outcome mapping (this package's mapping, for QA to check
 * against master v1.2; no new E-number is invented):
 * - time over limit -> Pause (STOPPED, resumable; O-01 limit
 *   itself is still undecided and is never invented here — the
 *   handler only reads snapshot.timeCheck, which the machine
 *   sets from its Config; a null limit stays LimitUndecided
 *   and does not block).
 * - queue/maintenance -> Wait (E02); 541 -> Block (E03);
 *   CAPTCHA -> Block (E04); loading -> Stay.
 * - load ERROR -> Pause (E01, entry load failure/timeout).
 * - page state other than ENTRY -> Pause (E08).
 * - entry element missing -> Pause (E05); duplicate -> Pause
 *   (E07). Clickability (E06) is NOT checked here because S1
 *   performs no click; checking it would invent a requirement.
 */
class S1EntryHandler(
    private val driver: PageDriver,
    private val entryElementId: String = PageElements.ENTRY_CONTINUE,
) : StepHandler {

    override fun execute(snapshot: MachineSnapshot): StepOutcome {
        StepChecks.timeCheck(snapshot)?.let { return it }
        val model = driver.snapshot()
        StepChecks.globalPageCheck(model)?.let { return it }
        if (model.pageState == PageState.ERROR) {
            return StepOutcome.Pause(reason = "ENTRY_LOAD_FAILED", errorId = "E01")
        }
        if (model.pageState != PageState.ENTRY) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        StepChecks.requireUnique(entryElementId, model)?.let { return it }
        return StepOutcome.Advance
    }
}
