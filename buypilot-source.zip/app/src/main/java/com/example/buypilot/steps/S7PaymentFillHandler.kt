package com.example.buypilot.steps

import com.example.buypilot.payment.CardSession
import com.example.buypilot.payment.CardValidator
import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.StepHandler
import com.example.buypilot.state.StepOutcome

/**
 * S7 PAYMENT_FILL — fill the payment page's 3 fields from the
 * card session and verify the fill by E16 read-back.
 * Implemented under rulings D-31/D-32 (Kenneth, main chat,
 * 2026-10-27): S7 is unlocked and the app handles payment
 * automatically; this handler fills, it does NOT submit —
 * submission remains S8's dispatch (also automatic under
 * D-31, redesigned in its own step, not here).
 *
 * Field scope is the D-16 3 fields, by field CODE only:
 * cc-number / cc-exp / cc-csc. There is no cardholder-name
 * field in scope. Values exist only inside the borrowed
 * [CardSession] buffers and this call's local comparison
 * variables: never logged, never stored by this handler,
 * never included in any reason string or evidence file.
 *
 * Detection before any fill (D-17 handler-level counterpart
 * of the live-DOM frame check): every required field must
 * be present (missing -> Pause E05), unique (duplicate ->
 * Pause E07), and in the page's main frame (not main frame
 * -> Pause E15, the field cannot be filled by WebView
 * script). If any check fails, NO field is filled at all.
 *
 * Card data source: the [CardSession] the flow layer hands
 * in. Under D-31 the persistent store lives inside the app
 * (its own component, coordinated with Water's lifecycle
 * work); this handler only borrows the session's working
 * copy via [CardSession.withCardData]. That contract clears
 * the working copy when the fill attempt ends, on EVERY
 * outcome — success, fill failure, read-back mismatch —
 * and this handler relies on exactly that: an attempt is
 * never retried inside one execute(), and buffers are never
 * held into S8. Clearing the working copy does not delete
 * the app-internal stored combination; the store is not
 * this handler's object.
 *
 * E16 read-back (Water 6 corrections, 3-field scope):
 * - number: digit count + last 4, separators stripped.
 * - expiry: digits compared as an MMYY string, leading
 *   zero preserved (string compare, never numeric).
 * - CVV: non-empty + length only.
 * A field that reads back as null is UNREADABLE, not a
 * mismatch: its code is reported to the flow layer through
 * [onUnverifiedFields] and the run advances, so that S8
 * can require the itemised confirmation E16 prescribes —
 * unless and until a later Kenneth ruling changes the
 * automatic flow, this handler does not silently drop the
 * unverified distinction. A field that reads back with a
 * DIFFERENT value is a mismatch: Pause (E16) hard stop;
 * no confirmation can override it, and nothing is filled
 * again in the same execute.
 *
 * Outcome mapping (this package's mapping, for QA to check):
 * - time over limit -> Pause; queue -> Wait (E02); 541 ->
 *   Block (E03); CAPTCHA -> Block (E04); loading -> Stay.
 * - page ERROR/UNKNOWN, or page not PAYMENT, or sold out
 *   -> Pause (E08 / E09 as applicable).
 * - field missing -> Pause (E05); field duplicate ->
 *   Pause (E07); field not in main frame, or a fill call
 *   refused -> Pause (E15, fill failed).
 * - session timed out -> Pause (CARD_SESSION_TIMEOUT);
 *   session missing fields / inactive -> Pause
 *   (CARD_DATA_UNAVAILABLE). Neither has an E-number in
 *   the master list, so none is claimed.
 * - read-back mismatch -> Pause (E16).
 * - all filled and verified (unreadable fields reported)
 *   -> Advance to S8.
 */
class S7PaymentFillHandler(
    private val driver: PageDriver,
    private val session: CardSession,
    private val onUnverifiedFields: (List<String>) -> Unit = {},
) : StepHandler {

    private enum class FillOutcome { SUCCESS, FILL_FAILED, MISMATCH }

    override fun execute(snapshot: MachineSnapshot): StepOutcome {
        StepChecks.timeCheck(snapshot)?.let { return it }
        val model = driver.snapshot()
        StepChecks.globalPageCheck(model)?.let { return it }
        if (model.pageState == PageState.ERROR || model.pageState == PageState.UNKNOWN) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        if (model.soldOut) {
            return StepOutcome.Pause(reason = "SOLD_OUT", errorId = "E09")
        }
        if (model.pageState != PageState.PAYMENT) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        // Detection phase: no field is filled unless every
        // required field passes first.
        for (code in PaymentFields.REQUIRED) {
            val fact = model.paymentFields.firstOrNull { it.fieldCode == code }
            if (fact == null || fact.count == 0) {
                return StepOutcome.Pause(reason = "PAYMENT_FIELD_MISSING", errorId = "E05")
            }
            if (fact.count > 1) {
                return StepOutcome.Pause(reason = "PAYMENT_FIELD_NOT_UNIQUE", errorId = "E07")
            }
            if (!fact.inMainFrame) {
                return StepOutcome.Pause(reason = "PAYMENT_FIELD_NOT_MAIN_FRAME", errorId = "E15")
            }
        }
        if (session.checkTimeout() != null) {
            return StepOutcome.Pause(reason = "CARD_SESSION_TIMEOUT")
        }
        if (!session.isActive || !session.hasAllFields()) {
            return StepOutcome.Pause(reason = "CARD_DATA_UNAVAILABLE")
        }
        val unverified = mutableListOf<String>()
        var outcome = FillOutcome.SUCCESS
        try {
            session.withCardData { buffers ->
                for (code in PaymentFields.REQUIRED) {
                    val value = buffers.getValue(fieldFor(code))
                    if (!driver.fillPaymentField(code, value)) {
                        outcome = FillOutcome.FILL_FAILED
                        return@withCardData
                    }
                }
                for (code in PaymentFields.REQUIRED) {
                    val pageText = driver.paymentFieldReadBack(code)
                    if (pageText == null) {
                        unverified += code
                        continue
                    }
                    if (!matches(code, buffers.getValue(fieldFor(code)), pageText)) {
                        outcome = FillOutcome.MISMATCH
                        return@withCardData
                    }
                }
            }
        } catch (e: IllegalStateException) {
            // Session became unready between the check and the
            // borrow (single-threaded in practice): fail safe,
            // never advance on an unborrowed session.
            return StepOutcome.Pause(reason = "CARD_DATA_UNAVAILABLE")
        }
        return when (outcome) {
            FillOutcome.FILL_FAILED ->
                StepOutcome.Pause(reason = "PAYMENT_FILL_FAILED", errorId = "E15")
            FillOutcome.MISMATCH ->
                StepOutcome.Pause(reason = "READBACK_MISMATCH", errorId = "E16")
            FillOutcome.SUCCESS -> {
                onUnverifiedFields(unverified.toList())
                StepOutcome.Advance
            }
        }
    }

    private fun fieldFor(code: String): CardValidator.Field = when (code) {
        PaymentFields.NUMBER -> CardValidator.Field.CARD_NUMBER
        PaymentFields.EXPIRY -> CardValidator.Field.EXPIRY
        else -> CardValidator.Field.CVV
    }

    /** E16 comparison only; never rewrites the filled value. */
    private fun matches(code: String, filled: CharArray, pageText: String): Boolean =
        when (code) {
            PaymentFields.NUMBER -> {
                val filledDigits = digitsOf(filled)
                val pageDigits = pageText.filter { it.isDigit() }
                filledDigits.length == pageDigits.length &&
                    filledDigits.takeLast(4) == pageDigits.takeLast(4)
            }
            PaymentFields.EXPIRY -> {
                digitsOf(filled) == pageText.filter { it.isDigit() }
            }
            else -> pageText.isNotEmpty() && pageText.length == filled.size
        }

    private fun digitsOf(value: CharArray): String {
        val out = StringBuilder()
        for (c in value) if (c.isDigit()) out.append(c)
        return out.toString()
    }
}
