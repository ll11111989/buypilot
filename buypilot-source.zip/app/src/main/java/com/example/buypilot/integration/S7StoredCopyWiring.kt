package com.example.buypilot.integration

import com.example.buypilot.payment.CardSession
import com.example.buypilot.payment.CardValidator
import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.StepOutcome
import com.example.buypilot.steps.S7PaymentFillHandler
import com.example.buypilot.steps.PageDriver
import com.example.buypilot.storage.WorkingCopy

/**
 * S7 stored-profile path wiring (D-52 reservation (4)).
 *
 * The accepted S7 handler (D-38) is NOT modified: it keeps
 * taking a CardSession and keeps its own withCardData
 * finally-clearing contract. The stored path is wired
 * around it, in the flow layer, as follows:
 *  1. The flow layer holds a WorkingCopy produced by
 *     materializeForRun (stored number/expiry + the CVV the
 *     user re-entered at S6 this run, D-46).
 *  2. [sessionFromWorkingCopy] copies the three buffers
 *     into a fresh CardSession via CardSession.seed (which
 *     copies, so the WorkingCopy buffers are never aliased
 *     by the session; seed, not put — construction must
 *     neither check timeouts nor move the carried clocks,
 *     see the function doc). The S7 handler then fills from
 *     that session
 *     exactly as in the manual-input path, including E16
 *     read-back and unverified reporting.
 *  3. [executeS7WithStoredCopy] wraps the handler call in
 *     try/finally and calls copy.close() on EVERY outcome
 *     — Advance, Pause, Stay, Wait, Block, and even an
 *     unexpected handler exception. That finally is the
 *     D-52 reservation (4) guarantee: a stored WorkingCopy
 *     is never left uncleared past one S7 attempt, and
 *     closing it does not delete the stored combination
 *     (D-43 layering: close clears RAM only).
 * Both copies are zeroed by attempt end: the CardSession
 * copy by S7's own withCardData finally, the WorkingCopy
 * by the outer finally here. The duplication exists only
 * inside one attempt and is never held into S8.
 *
 * Timeout rule (D-54, replacing the earlier fresh-clock note
 * in full — the fresh clock does NOT comply with D-19 and
 * is no longer used anywhere): the caller passes the S6
 * session's already-elapsed clocks (as carried by
 * SaveS6Outcome.Saved), and the copy session starts with
 * those amounts already elapsed via beginWithElapsed. The
 * D-19 absolute 5-minute cap therefore keeps running from
 * the original S6 begin across the save boundary; if the
 * carried clocks are already past a limit, the S7 handler's
 * CARD_SESSION_TIMEOUT check fires on this path exactly as
 * it does on the manual-input path. Callers must supply
 * real elapsed values — there is deliberately no default,
 * so a fresh (zero-elapsed) clock cannot slip in silently.
 */
fun sessionFromWorkingCopy(
    copy: WorkingCopy,
    absoluteElapsedMs: Long,
    idleElapsedMs: Long,
): CardSession {
    val session = CardSession()
    session.beginWithElapsed(absoluteElapsedMs, idleElapsedMs)
    // seed(), not put(): construction must neither check the
    // timeout (the S7 handler reports a carried timeout) nor
    // move the idle clock (that would erase the carry-over).
    session.seed(CardValidator.Field.CARD_NUMBER, copy.cardNumber)
    session.seed(CardValidator.Field.EXPIRY, copy.expiry)
    session.seed(CardValidator.Field.CVV, copy.cvv)
    return session
}

fun executeS7WithStoredCopy(
    driver: PageDriver,
    copy: WorkingCopy,
    snapshot: MachineSnapshot,
    absoluteElapsedMs: Long,
    idleElapsedMs: Long,
    onUnverifiedFields: (List<String>) -> Unit = {},
): StepOutcome {
    val session = sessionFromWorkingCopy(copy, absoluteElapsedMs, idleElapsedMs)
    try {
        return S7PaymentFillHandler(driver, session, onUnverifiedFields)
            .execute(snapshot)
    } finally {
        copy.close()
    }
}
