package com.example.buypilot.state

/**
 * P2 state-machine core — the only owner of step/global transitions.
 *
 * Pure Kotlin, no Android dependencies, so this file is unit-tested
 * on the JVM (see StateMachineTest). It contains NO page logic,
 * NO network access, NO submission, and NO card handling:
 * - Page logic lives in future step-handler packages (S1–S5) and
 *   in the existing S6 module; this core only calls handlers.
 * - S7 PAYMENT_FILL is locked by default (Config.s7Unlocked =
 *   false). While locked, reaching S7 pauses the run and the S7
 *   handler is never called. Kenneth unlocked S7 in D-32
 *   (2026-10-27); the default stays false as a safe default and
 *   the product wiring sets it true — a test-only machine may
 *   also set it true to prove the gate itself works.
 * - The core holds NO card data and performs NO card clearing
 *   (D-35, 2026-10-27: the app has no automatic deletion
 *   trigger for entered data — entered data and data
 *   combinations are retained in the app, and even a
 *   successful submit deletes nothing automatically; deletion
 *   is the user's own manual action, outside this core).
 *   Earlier versions delegated clearing to an onClearCardData
 *   callback invoked on cancel/decline/fail/block/background
 *   and UNKNOWN transitions; D-33 first removed it for the
 *   Pause/Block-after-submit transitions, and D-35 removed
 *   it entirely. The RAM working copy inside CardSession is
 *   a separate layer (its own lifecycle), not driven by
 *   this core.
 *
 * Submitted-priority rule (master v1.2, applied in exactly one
 * place — the terminal-transition helpers below): once
 * markSubmitted() has been called at S8, any later background /
 * crash / network / cancel / fail / waiting event
 * becomes UNKNOWN, never CANCELLED or FAILED, with later
 * amendments: D-21 fix (S8/S9 package, 2026-10-27): handler
 * Pause and Block outcomes are covered by the same rule —
 * after submit they also become UNKNOWN, instead of
 * STOPPED/BLOCKED. D-34 (2026-10-27): an explicit
 * decline after submit is a KNOWN result and ends as
 * DECLINED, not UNKNOWN. D-35 (2026-10-27): no transition
 * in this core clears or deletes entered data, before or
 * after submit. Before dispatch the same events map as:
 * background -> CANCELLED (E23), network loss -> STOPPED (E20),
 * crash / session expiry -> STOPPED (halted, re-validated on
 * resume; a real process crash restarts the app, so the next
 * launch is a new run — the in-process STOPPED mapping only
 * covers a simulated interrupt inside a live machine).
 *
 * S1 time-deviation check (open item O-01 — the LIMIT VALUE is
 * undecided and is deliberately not invented here):
 * - Config.timeDeviationLimitMs = null (the default) means the
 *   check is recorded as LimitUndecided, never claimed as passed,
 *   and does not block the run.
 * - If a limit and a provider are both supplied and the deviation
 *   exceeds the limit before start, no step handler runs: the run
 *   is created at S1 in STOPPED, so fixing the device time and
 *   resuming can proceed. During a run the same over-limit result
 *   also halts as STOPPED (master: in-run -> STOPPED).
 *
 * BLOCKED has no resume API by design (master: never bypass
 * E03/E04). A blocked run ends here; a human starts a fresh run
 * with resetForNewRun() after intervening outside the machine.
 */
class StateMachine(
    private val config: Config = Config(),
) {

    /** Injectable device-time source; null result = unmeasurable. */
    fun interface TimeDeviationProvider {
        fun deviationMs(): Long?
    }

    data class Config(
        val s7Unlocked: Boolean = false,
        /** O-01: null = undecided, never silently treated as passed. */
        val timeDeviationLimitMs: Long? = null,
        val timeProvider: TimeDeviationProvider? = null,
    )

    sealed class TimeCheck {
        object LimitUndecided : TimeCheck()
        object Unmeasurable : TimeCheck()
        data class WithinLimit(val deviationMs: Long) : TimeCheck()
        data class OverLimit(val deviationMs: Long) : TimeCheck()
    }

    enum class InterruptKind {
        APP_BACKGROUND, NETWORK_LOST, CRASH, SESSION_EXPIRED
    }

    private val handlers = mutableMapOf<PurchaseStep, StepHandler>()
    private val logEntries = mutableListOf<String>()

    var currentStep: PurchaseStep = PurchaseStep.S1_ENTRY
        private set
    var globalState: GlobalState? = null
        private set
    var isStarted: Boolean = false
        private set
    var isComplete: Boolean = false
        private set
    var submitted: Boolean = false
        private set
    var needsRevalidation: Boolean = false
        private set
    var timeCheck: TimeCheck? = null
        private set
    var lastReason: String? = null
        private set

    private var returnStep: PurchaseStep? = null

    val eventLog: List<String> get() = logEntries.toList()

    fun snapshot(): MachineSnapshot = MachineSnapshot(
        step = currentStep,
        global = globalState,
        submitted = submitted,
        needsRevalidation = needsRevalidation,
        isComplete = isComplete,
        s7Unlocked = config.s7Unlocked,
        timeCheck = timeCheck,
    )

    /** Plug in a step handler. Future S1–S5 packages use this. */
    fun registerHandler(step: PurchaseStep, handler: StepHandler) {
        handlers[step] = handler
    }

    // ---------- start / time check ----------

    private fun evaluateTime(): TimeCheck {
        val limit = config.timeDeviationLimitMs
            ?: return TimeCheck.LimitUndecided
        val deviation = config.timeProvider?.deviationMs()
            ?: return TimeCheck.Unmeasurable
        return if (deviation > limit) TimeCheck.OverLimit(deviation)
        else TimeCheck.WithinLimit(deviation)
    }

    /**
     * Creates a run at S1. If the time check is over the limit,
     * no handler runs: the run sits at S1 in STOPPED until the
     * device time is fixed and resumeFromStopped() is called.
     * Returns false only if a run is already RUNNING.
     */
    fun start(): Boolean {
        // A live, paused, waiting or blocked run is never silently
        // discarded by start(): resume it, or resetForNewRun() first.
        // Only a terminal run (or no run yet) may be (re)started.
        if (isStarted && globalState != null && !globalState!!.isTerminal) return false
        submitted = false
        isComplete = false
        needsRevalidation = false
        returnStep = null
        currentStep = PurchaseStep.S1_ENTRY
        isStarted = true
        timeCheck = evaluateTime()
        if (timeCheck is TimeCheck.OverLimit) {
            globalState = GlobalState.STOPPED
            lastReason = "S1_TIME_DEVIATION_OVER_LIMIT"
            log("START_BLOCKED_BY_TIME_DEVIATION")
        } else {
            globalState = GlobalState.RUNNING
            log("START")
        }
        return true
    }

    /** In-run time check: over limit halts as STOPPED (master). */
    fun checkTimeDeviationDuringRun(): TimeCheck {
        val check = evaluateTime()
        timeCheck = check
        if (check is TimeCheck.OverLimit && globalState == GlobalState.RUNNING) {
            globalState = GlobalState.STOPPED
            needsRevalidation = true
            lastReason = "S1_TIME_DEVIATION_OVER_LIMIT"
            log("TIME_DEVIATION_OVER_LIMIT_DURING_RUN")
        }
        return check
    }

    // ---------- step execution ----------

    /**
     * Runs the current step's handler once. Returns its outcome,
     * or null when the machine is not RUNNING (handler not called).
     * At locked S7 the handler is deliberately never called.
     */
    fun executeCurrentStep(): StepOutcome? {
        if (!isStarted || globalState != GlobalState.RUNNING) return null
        if (currentStep == PurchaseStep.S7_PAYMENT_FILL && !config.s7Unlocked) {
            globalState = GlobalState.STOPPED
            needsRevalidation = true
            lastReason = "S7_LOCKED"
            log("S7_LOCKED_NOT_ENTERED")
            return StepOutcome.Pause(reason = "S7_LOCKED")
        }
        val handler = handlers[currentStep] ?: NotImplementedStepHandler
        val outcome = handler.execute(snapshot())
        applyOutcome(outcome)
        return outcome
    }

    private fun applyOutcome(outcome: StepOutcome) {
        when (outcome) {
            is StepOutcome.Advance -> {
                val next = currentStep.next()
                if (next == null) {
                    isComplete = true
                    log("COMPLETE_AT_S9")
                } else {
                    log("ADVANCE ${currentStep.code}->${next.code}")
                    currentStep = next
                }
                needsRevalidation = false
            }
            is StepOutcome.Stay -> {
                needsRevalidation = true
                log("STAY ${currentStep.code}")
            }
            is StepOutcome.Pause -> {
                // D-21 fix: a handler Pause after submit is not a
                // resumable stop — the submit result is unknown.
                if (submitted) {
                    toUnknown("PAUSE_AFTER_SUBMIT:${outcome.reason}")
                } else {
                    globalState = GlobalState.STOPPED
                    needsRevalidation = true
                    lastReason = outcome.reason
                    log("STOPPED ${currentStep.code} ${outcome.reason}")
                }
            }
            is StepOutcome.Wait -> {
                lastReason = outcome.reason
                enterWaitingInternal(outcome.errorId)
            }
            is StepOutcome.Block -> {
                // D-21 fix: a handler Block after submit is not a
                // blocked run — the submit result is unknown.
                if (submitted) {
                    toUnknown("BLOCK_AFTER_SUBMIT:${outcome.reason}")
                } else {
                    globalState = GlobalState.BLOCKED
                    lastReason = outcome.reason
                    log("BLOCKED ${currentStep.code} ${outcome.reason}")
                }
            }
            is StepOutcome.Cancel -> cancel()
            is StepOutcome.Decline -> decline()
            is StepOutcome.Fail -> fail(outcome.reason, outcome.errorId)
        }
    }

    // ---------- global transitions ----------

    /** Human pause: RUNNING -> STOPPED, resumable at the same step. */
    fun pause(reason: String): Boolean {
        if (globalState != GlobalState.RUNNING) return false
        globalState = GlobalState.STOPPED
        needsRevalidation = true
        lastReason = reason
        log("PAUSED ${currentStep.code} $reason")
        return true
    }

    fun resumeFromStopped(): Boolean {
        if (globalState != GlobalState.STOPPED) return false
        globalState = GlobalState.RUNNING
        needsRevalidation = true
        log("RESUMED_FROM_STOPPED ${currentStep.code}")
        return true
    }

    private fun enterWaitingInternal(errorId: String?) {
        if (submitted) {
            toUnknown("WAITING_AFTER_SUBMIT")
            return
        }
        if (globalState != GlobalState.RUNNING) return
        returnStep = currentStep
        globalState = GlobalState.WAITING
        log("WAITING ${currentStep.code} ${errorId ?: ""}".trim())
    }

    fun enterWaiting(reason: String, errorId: String? = null): Boolean {
        if (!isStarted || globalState == null || globalState!!.isTerminal) return false
        lastReason = reason
        enterWaitingInternal(errorId)
        return true
    }

    fun resumeFromWaiting(): Boolean {
        if (globalState != GlobalState.WAITING) return false
        val back = returnStep ?: currentStep
        currentStep = back
        returnStep = null
        globalState = GlobalState.RUNNING
        needsRevalidation = true
        log("RESUMED_FROM_WAITING ${currentStep.code}")
        return true
    }

    fun cancel(): Boolean {
        if (!isStarted || globalState == null || globalState!!.isTerminal) return false
        if (submitted) {
            toUnknown("CANCEL_AFTER_SUBMIT")
            return true
        }
        globalState = GlobalState.CANCELLED
        log("CANCELLED ${currentStep.code}")
        return true
    }

    fun decline(): Boolean {
        if (!isStarted || globalState == null || globalState!!.isTerminal) return false
        if (submitted) {
            // D-34: an explicit refusal after submit is a KNOWN
            // result — the run ends DECLINED, not UNKNOWN.
            globalState = GlobalState.DECLINED
            log("DECLINED_AFTER_SUBMIT ${currentStep.code}")
            return true
        }
        globalState = GlobalState.DECLINED
        log("DECLINED ${currentStep.code}")
        return true
    }

    fun fail(reason: String, errorId: String? = null): Boolean {
        if (!isStarted || globalState == null || globalState!!.isTerminal) return false
        if (submitted) {
            toUnknown("FAIL_AFTER_SUBMIT")
            return true
        }
        globalState = GlobalState.FAILED
        lastReason = reason
        log("FAILED ${currentStep.code} $reason ${errorId ?: ""}".trim())
        return true
    }

    /**
     * Called by the S8 handler at the exact moment the submit
     * action is dispatched. After this call, interrupts and
     * unknown results end as UNKNOWN and an explicit refusal
     * ends as DECLINED (D-34) — never as CANCELLED or FAILED,
     * and never auto-resubmitted. Calling it from any
     * other step is a programming error and is refused.
     */
    fun markSubmitted() {
        check(currentStep == PurchaseStep.S8_SUBMIT_CONFIRM) {
            "markSubmitted is only valid at S8"
        }
        check(globalState == GlobalState.RUNNING) {
            "markSubmitted requires a RUNNING machine"
        }
        submitted = true
        log("SUBMIT_DISPATCHED")
    }

    /** Background / network / crash / session-expiry interrupt. */
    fun onInterrupt(kind: InterruptKind): Boolean {
        if (!isStarted || globalState == null || globalState!!.isTerminal) return false
        if (submitted) {
            toUnknown("INTERRUPT_AFTER_SUBMIT:$kind")
            return true
        }
        when (kind) {
            InterruptKind.APP_BACKGROUND -> {
                // E23: background before dispatch -> CANCELLED.
                globalState = GlobalState.CANCELLED
                log("CANCELLED_ON_BACKGROUND ${currentStep.code}")
            }
            InterruptKind.NETWORK_LOST,
            InterruptKind.CRASH,
            InterruptKind.SESSION_EXPIRED -> {
                globalState = GlobalState.STOPPED
                needsRevalidation = true
                lastReason = kind.name
                log("STOPPED_ON_INTERRUPT $kind ${currentStep.code}")
            }
        }
        return true
    }

    private fun toUnknown(reason: String) {
        globalState = GlobalState.UNKNOWN
        lastReason = reason
        log("UNKNOWN $reason ${currentStep.code}")
    }

    /** Fresh run after a terminal or BLOCKED state. */
    fun resetForNewRun() {
        currentStep = PurchaseStep.S1_ENTRY
        globalState = null
        isStarted = false
        isComplete = false
        submitted = false
        needsRevalidation = false
        returnStep = null
        timeCheck = null
        lastReason = null
        logEntries.clear()
        log("RESET_FOR_NEW_RUN")
    }

    private fun log(entry: String) {
        // Log carries step codes, global states and reasons only —
        // never values, never card data, never hashes.
        logEntries.add(entry)
    }
}

/** Read-only snapshot handed to step handlers. */
data class MachineSnapshot(
    val step: PurchaseStep,
    val global: GlobalState?,
    val submitted: Boolean,
    val needsRevalidation: Boolean,
    val isComplete: Boolean,
    val s7Unlocked: Boolean,
    val timeCheck: StateMachine.TimeCheck?,
)
