package com.example.buypilot.integration

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.buypilot.storage.AndroidKeystoreCrypto
import com.example.buypilot.storage.ProfileRepository
import java.util.UUID

/**
 * Host for the combination management screen.
 *
 * FLAG_SECURE is set for the whole window while stored
 * combinations are listed, mirroring PaymentHostActivity:
 * blocks screenshots and blanks the recents preview.
 * The repository is built here, in the App module, from
 * the FileProfileBackend (filesDir/profile_store/) and the
 * Keystore crypto — this is the App-module wiring point
 * Water's module leaves open (ProfileBackend is an
 * interface in the module, not an implementation).
 */
class ProfileManagementActivity : ComponentActivity() {

    private lateinit var repository: ProfileRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE,
        )
        repository = ProfileRepository(
            backend = FileProfileBackend(filesDir),
            crypto = AndroidKeystoreCrypto(),
            idGenerator = { UUID.randomUUID().toString() },
        )
        setContent {
            ProfileManagementScreen(
                repository = repository,
                onClose = { finish() },
            )
        }
    }
}
