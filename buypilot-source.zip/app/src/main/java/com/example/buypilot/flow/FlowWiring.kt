package com.example.buypilot.flow

import com.example.buypilot.payment.CardSession
import com.example.buypilot.payment.CardValidator
import com.example.buypilot.state.PurchaseStep
import com.example.buypilot.state.StateMachine
import com.example.buypilot.state.StepOutcome
import com.example.buypilot.steps.PageDriver
import com.example.buypilot.steps.S1EntryHandler
import com.example.buypilot.steps.S2ConfigureHandler
import com.example.buypilot.steps.S3AddToBagHandler
import com.example.buypilot.steps.S4CheckoutHandler
import com.example.buypilot.steps.S5FulfillmentHandler
import com.example.buypilot.steps.S8SubmitConfirmHandler
import com.example.buypilot.steps.S8UnverifiedStatus
import com.example.buypilot.steps.S9ResultHandler
import com.example.buypilot.storage.MaterializeOutcome
import com.example.buypilot.storage.ProfileRepository

/**
 * Control signal for the S8 submit click returning an
 * explicit false (D-61 reservation (3) fix): the submit was
 * NOT dispatched, so the run must not mark submitted and
 * must not advance to S9. runFlowUntilStop converts this
 * into a STOPPED Pause at S8; hosts driving the machine
 * step by step must catch it the same way.
 */
class S8SubmitClickFailedException :
    RuntimeException("S8 submit click returned false: submit was not dispatched")

/**
 * Post-merge flow wiring: registers the S1–S9 handlers into
 * one state machine, forming the executable complete flow.
 *
 * Registration notes:
 * - S4 is registered with expectedBagProductKey = null, so
 *   its optional bag-identity check stays off (D-27: no
 *   option verification; the check runs only when a caller
 *   supplies a key). S3's bag identity/quantity checks
 *   were removed by the D-27 alignment (D-64) — S3 no
 *   longer compares bag product or quantity; D-25 lifted
 *   the D-23 citation restriction only and does not
 *   exempt S3 from D-27.
 * - S6 is the flow bridge (FlowS6Handler); S7 is the
 *   two-path dispatcher (FlowS7Handler).
 * - S8's onDispatch performs the actual page submit click.
 *   It marks submitted ONLY when the click succeeds, or
 *   when the click throws (outcome unknown — the core's
 *   UNKNOWN protection then applies, and the error still
 *   surfaces). An explicit click failure (false) is NOT
 *   marked and does NOT advance: onDispatch throws
 *   S8SubmitClickFailedException, which runFlowUntilStop
 *   converts into a STOPPED Pause at S8 (D-61 reservation
 *   (3) fix — the old unconditional finally-mark could
 *   Advance to S9 and misreport UNKNOWN after a click
 *   that explicitly did not dispatch).
 * - D-63 retry: FlowS7Handler counts attempts (cap 3);
 *   supplyStoredRetryCvv() re-materializes a stored
 *   combination with a freshly topped-up CVV for the next
 *   attempt, reusing the S6 clocks captured at the first
 *   S6 advance. Manual retries re-enter all 3 fields at
 *   S6 through the normal screen. Neither path reuses a
 *   finally-cleared copy or session.
 * - S8's unverified provider reads the flow state: fields
 *   S7 could not read back are listed item by item and are
 *   never silently submitted (D-36); only codes the host
 *   explicitly confirms via state.confirmUnverified count
 *   as confirmed.
 * - s7Unlocked is a parameter, never hard-coded here: the
 *   product host passes the product default (locked); a
 *   test machine may pass true to exercise the flow, as in
 *   earlier packages. When the product default opens is
 *   Kenneth's decision, not this wiring's.
 * - The S1 time-deviation limit stays undecided (null):
 *   O-01 was cancelled by D-28 and no limit is invented.
 */
fun buildFlow(
    driver: PageDriver,
    config: FlowConfig,
    session: CardSession,
    repository: ProfileRepository?,
    s7Unlocked: Boolean,
): FlowRun {
    require(config.selectedProfileId == null || repository != null) {
        "stored path requires a ProfileRepository"
    }
    val state = FlowRuntimeState(config.selectedProfileId)
    val machine = StateMachine(
        StateMachine.Config(
            s7Unlocked = s7Unlocked,
            timeDeviationLimitMs = null,
            timeProvider = null,
        ),
    )
    machine.registerHandler(PurchaseStep.S1_ENTRY, S1EntryHandler(driver))
    machine.registerHandler(
        PurchaseStep.S2_CONFIGURE,
        S2ConfigureHandler(driver, config.productKey),
    )
    machine.registerHandler(
        PurchaseStep.S3_ADD_TO_BAG,
        S3AddToBagHandler(driver, config.productKey),
    )
    machine.registerHandler(
        PurchaseStep.S4_CHECKOUT,
        S4CheckoutHandler(driver, expectedBagProductKey = null),
    )
    machine.registerHandler(
        PurchaseStep.S5_FULFILLMENT,
        S5FulfillmentHandler(driver, config.priorityStores),
    )
    machine.registerHandler(
        PurchaseStep.S6_PAYMENT_INPUT,
        FlowS6Handler(session, repository, state),
    )
    machine.registerHandler(
        PurchaseStep.S7_PAYMENT_FILL,
        FlowS7Handler(driver, session, state),
    )
    machine.registerHandler(
        PurchaseStep.S8_SUBMIT_CONFIRM,
        S8SubmitConfirmHandler(
            driver = driver,
            summary = config.summary,
            unverifiedProvider = {
                S8UnverifiedStatus(
                    fieldCodes = state.unverifiedFieldCodes,
                    confirmedCodes = state.confirmedUnverifiedCodes,
                )
            },
            onDispatch = {
                val clicked = try {
                    driver.click(FlowElements.SUBMIT_BUTTON)
                } catch (e: Exception) {
                    // Click outcome unknown: the dispatch may
                    // have happened, so mark submitted (the
                    // core's UNKNOWN protection applies) and
                    // let the error surface to the host.
                    machine.markSubmitted()
                    throw e
                }
                if (clicked) {
                    machine.markSubmitted()
                } else {
                    // Explicit false: nothing was dispatched.
                    // Do not mark, do not advance — the throw
                    // is converted by runFlowUntilStop into a
                    // STOPPED Pause at S8.
                    throw S8SubmitClickFailedException()
                }
            },
            onUnverifiedListed = { codes -> state.lastUnverifiedListed = codes },
        ),
    )
    machine.registerHandler(PurchaseStep.S9_RESULT, S9ResultHandler(driver))
    return FlowRun(machine, state)
}

/**
 * Drives the flow until it stops: executes steps while the
 * machine is RUNNING, continuing through Advance and Stay
 * (S2 navigates with a Stay before its configuring execute;
 * S8's unverified Stay and S9's PENDING Stay are bounded by
 * maxSteps), and stops at the first Pause / Wait / Block /
 * terminal outcome, when the machine completes, or when
 * maxSteps is exhausted. Returns the last outcome (null if
 * the machine was not running at all).
 *
 * The host calls this for page-driven stretches and calls
 * it again after user input (S6), after resuming, or after
 * confirming listed unverified fields. UI work and page
 * waiting happen between calls, never inside this loop.
 */
fun runFlowUntilStop(run: FlowRun, maxSteps: Int = 32): StepOutcome? {
    var last: StepOutcome? = null
    var executed = 0
    while (executed < maxSteps && !run.machine.isComplete) {
        val outcome = try {
            run.machine.executeCurrentStep()
        } catch (e: S8SubmitClickFailedException) {
            // The submit was explicitly not dispatched: stop
            // at S8 (resumable), submitted stays false.
            run.machine.pause("S8_SUBMIT_CLICK_FAILED")
            StepOutcome.Pause(reason = "S8_SUBMIT_CLICK_FAILED")
        } ?: break
        last = outcome
        executed++
        if (outcome !is StepOutcome.Advance && outcome !is StepOutcome.Stay) break
    }
    return last
}

/**
 * Stored-path retry supply (D-63): materializes the
 * selected combination again with a CVV freshly topped up
 * in [session] (CvvTopUpScreen, one field only), and stores
 * the new working copy in the flow state for the next S7
 * execute. The S6 clocks captured at the first S6 advance
 * are reused (the stored S7 path reads them on every
 * execute). Returns false when there is no selected
 * combination, no unconsumed copy slot, no active session,
 * no CVV, or materialization fails (decryption failure /
 * deleted combination) — the host then reports the retry
 * as failed instead of executing. Either way the top-up
 * session is ended and the CVV copy taken here is zeroed
 * in finally (the top-up obeys the same S6 lifecycle /
 * timeout / finally-clear constraints as the first input).
 */
fun supplyStoredRetryCvv(
    run: FlowRun,
    session: CardSession,
    repository: ProfileRepository,
): Boolean {
    val profileId = run.state.selectedProfileId ?: return false
    if (run.state.storedWorkingCopy != null) return false
    if (!session.isActive) return false
    val cvv = session.copyField(CardValidator.Field.CVV) ?: return false
    try {
        return when (val outcome = repository.materializeForRun(profileId, cvv)) {
            is MaterializeOutcome.Ok -> {
                run.state.storedWorkingCopy = outcome.copy
                true
            }
            else -> false
        }
    } finally {
        cvv.fill('\u0000')
        session.clear(CardSession.ClearTrigger.SESSION_ENDED)
    }
}
