package com.example.buypilot.integration

import com.example.buypilot.storage.PickupGroup
import com.example.buypilot.storage.ProductGroup
import com.example.buypilot.storage.ProfileBackend
import com.example.buypilot.storage.StoredProfile
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * App-module ProfileBackend implementation (Fire wiring for
 * Water's seq 4478 storage module, D-52 accepted).
 *
 * Storage location is exactly the agreed one: the app-private
 * filesDir's `profile_store/` directory — never any other
 * location, so the module's backup_rules.xml (which excludes
 * file-domain `profile_store/`) lines up with the actual files.
 * The P1 manifest additionally sets allowBackup=false, so
 * exclusion does not rest on this file alone.
 *
 * Format (single file `profiles.bin`, versioned by magic):
 * magic "BPS1", then Int count, then one record per profile
 * in a fixed field order. Strings are Int length + UTF-8
 * bytes (-1 = null); byte arrays are Int length + raw bytes;
 * booleans-or-null are a single byte (-1 null, 0 false,
 * 1 true); Ints are raw. No logging anywhere, and no card
 * data ever appears in an exception message (only file
 * sizes/offsets, which carry no values).
 *
 * Behaviour contract, stated for QA:
 * - missing file -> empty list (first run), never an error.
 * - corrupt file (bad magic, truncation, trailing bytes) ->
 *   IllegalStateException. It is deliberately NOT silently
 *   treated as empty: silently dropping the store would let
 *   a later saveAll overwrite real combinations. The UI
 *   surfaces the error and does not proceed to save.
 * - saveAll writes a temp file in the same directory, fsyncs,
 *   then renames over the target, so a crash mid-write does
 *   not leave a half-written store behind.
 *
 * This file uses only java.io, so it is unit-testable on the
 * JVM; it has no Android dependency of its own (the caller
 * supplies filesDir, on-device from Context.filesDir).
 */
class FileProfileBackend(filesDir: File) : ProfileBackend {

    private val dir = File(filesDir, "profile_store")
    private val file = File(dir, "profiles.bin")
    private val tempFile = File(dir, "profiles.bin.tmp")

    private class Reader(private val bytes: ByteArray) {
        var pos = 0
        fun int(): Int {
            if (pos + 4 > bytes.size) corrupt("truncated int")
            val v = ((bytes[pos].toInt() and 0xFF) shl 24) or
                ((bytes[pos + 1].toInt() and 0xFF) shl 16) or
                ((bytes[pos + 2].toInt() and 0xFF) shl 8) or
                (bytes[pos + 3].toInt() and 0xFF)
            pos += 4
            return v
        }
        fun raw(n: Int): ByteArray {
            if (n < 0 || pos + n > bytes.size) corrupt("truncated bytes")
            val out = bytes.copyOfRange(pos, pos + n)
            pos += n
            return out
        }
        fun string(): String = String(raw(int()), Charsets.UTF_8)
        fun nullableString(): String? {
            val n = int()
            if (n == -1) return null
            if (n < 0 || pos + n > bytes.size) corrupt("truncated string")
            val out = String(bytes.copyOfRange(pos, pos + n), Charsets.UTF_8)
            pos += n
            return out
        }
        fun boolOrNull(): Boolean? = when (val b = raw(1)[0].toInt()) {
            -1 -> null
            0 -> false
            1 -> true
            else -> corrupt("bad boolean")
        }
        fun done() {
            if (pos != bytes.size) corrupt("trailing bytes")
        }
    }

    private class Writer {
        private val out = ByteArrayOutputStream()
        fun int(v: Int) {
            out.write((v ushr 24) and 0xFF)
            out.write((v ushr 16) and 0xFF)
            out.write((v ushr 8) and 0xFF)
            out.write(v and 0xFF)
        }
        fun raw(b: ByteArray) {
            int(b.size)
            out.write(b)
        }
        /** Magic header only: written with no length prefix. */
        fun plain(b: ByteArray) {
            out.write(b)
        }
        fun string(s: String) = raw(s.toByteArray(Charsets.UTF_8))
        fun nullableString(s: String?) {
            if (s == null) int(-1) else string(s)
        }
        fun boolOrNull(b: Boolean?) {
            out.write(when (b) { null -> -1; false -> 0; true -> 1 })
        }
        fun bytes(): ByteArray = out.toByteArray()
    }

    override fun loadAll(): List<StoredProfile> {
        if (!file.exists()) return emptyList()
        val bytes = file.readBytes()
        val r = Reader(bytes)
        if (r.raw(4).toString(Charsets.UTF_8) != MAGIC) corrupt("bad magic")
        val count = r.int()
        if (count < 0) corrupt("negative count")
        val out = ArrayList<StoredProfile>(count)
        repeat(count) {
            val id = r.string()
            val name = r.string()
            val product = ProductGroup(
                model = r.string(),
                colour = r.string(),
                capacity = r.string(),
                quantity = r.int(),
                appleCare = r.boolOrNull(),
                tradeIn = r.boolOrNull(),
            )
            val storeCount = r.int()
            if (storeCount < 0) corrupt("negative store count")
            val stores = ArrayList<String>(storeCount)
            repeat(storeCount) { stores += r.string() }
            val pickup = PickupGroup(
                method = r.string(),
                storePriority = stores,
                slotPreference = r.nullableString(),
                pickupName = r.nullableString(),
                pickupPhone = r.nullableString(),
                pickupEmail = r.nullableString(),
                deliveryAddress = r.nullableString(),
            )
            val encNumber = r.raw(r.int())
            val encExpiry = r.raw(r.int())
            val last4 = r.string()
            out += StoredProfile(id, name, product, pickup, encNumber, encExpiry, last4)
        }
        r.done()
        return out
    }

    override fun saveAll(profiles: List<StoredProfile>) {
        if (!dir.exists()) dir.mkdirs()
        val w = Writer()
        w.plain(MAGIC.toByteArray(Charsets.UTF_8))
        w.int(profiles.size)
        for (p in profiles) {
            w.string(p.id)
            w.string(p.name)
            w.string(p.product.model)
            w.string(p.product.colour)
            w.string(p.product.capacity)
            w.int(p.product.quantity)
            w.boolOrNull(p.product.appleCare)
            w.boolOrNull(p.product.tradeIn)
            w.int(p.pickup.storePriority.size)
            for (s in p.pickup.storePriority) w.string(s)
            w.string(p.pickup.method)
            w.nullableString(p.pickup.slotPreference)
            w.nullableString(p.pickup.pickupName)
            w.nullableString(p.pickup.pickupPhone)
            w.nullableString(p.pickup.pickupEmail)
            w.nullableString(p.pickup.deliveryAddress)
            w.raw(p.encryptedCardNumber)
            w.raw(p.encryptedExpiry)
            w.string(p.cardLast4)
        }
        tempFile.outputStream().use { stream ->
            stream.write(w.bytes())
            stream.fd.sync()
        }
        if (!tempFile.renameTo(file)) {
            file.delete()
            if (!tempFile.renameTo(file)) {
                throw java.io.IOException("profile store replace failed")
            }
        }
    }

    companion object {
        private const val MAGIC = "BPS1"
        private fun corrupt(detail: String): Nothing =
            throw IllegalStateException("profile store corrupt: $detail")
    }
}
