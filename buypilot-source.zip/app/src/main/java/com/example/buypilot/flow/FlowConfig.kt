package com.example.buypilot.flow

import com.example.buypilot.steps.SummaryData
import com.example.buypilot.storage.PickupGroup
import com.example.buypilot.storage.ProductGroup
import com.example.buypilot.storage.WorkingCopy

/**
 * Post-merge flow layer — run configuration and runtime state.
 *
 * FlowConfig is everything the S1–S9 handlers need that only
 * the run itself can supply (the handlers refuse blank
 * parameters at construction rather than guessing). It is
 * assembled by the host from the user's chosen combination /
 * run selection; the flow layer never invents any of it.
 *
 * selectedProfileId != null selects the STORED path: at S6
 * the user tops up only the CVV (D-46), the flow materializes
 * the stored combination, and S7 fills from the working copy.
 * Null selects the MANUAL path: full 3-field input at S6 and
 * S7 fills from the CardSession directly.
 */
data class FlowConfig(
    val productKey: String,
    val priorityStores: List<String>,
    val summary: SummaryData,
    val selectedProfileId: String? = null,
    /**
     * Optional run product/pickup groups, used ONLY for
     * the S6 save button (D-47): the host builds
     * S6SaveCallbacks from them. Null (either group) means
     * the host passes no save callbacks and the button
     * stays hidden — the host never invents groups. These
     * groups do not drive S2/S3/S5 (those use productKey /
     * priorityStores); the saved combination's quantity is
     * the group's quantity field, not a flow parameter.
     */
    val productGroup: ProductGroup? = null,
    val pickupGroup: PickupGroup? = null,
)

/** Logical element keys owned by the flow layer itself. */
object FlowElements {
    /**
     * The submit action on the submit-confirm page. Logical
     * key only, like every PageElements key: the real driver
     * maps it to the element it detects; no URL, no selector
     * is implied here.
     */
    const val SUBMIT_BUTTON = "SUBMIT_BUTTON"
}

/**
 * Mutable per-run state shared between the flow handlers.
 * Owned by the FlowRun; the host reads it to surface the
 * S8 unverified listing and to confirm codes.
 */
class FlowRuntimeState(
    val selectedProfileId: String?,
) {
    /** Field codes S7 could not read back (D-36), latest attempt. */
    var unverifiedFieldCodes: List<String> = emptyList()

    /** Codes the host has explicitly confirmed after listing. */
    var confirmedUnverifiedCodes: Set<String> = emptySet()

    /** Field codes S8 most recently listed item by item (D-36). */
    var lastUnverifiedListed: List<String> = emptyList()

    /** Stored-path working copy, materialized at S6 (stored path only). */
    var storedWorkingCopy: WorkingCopy? = null

    /** S6 clocks carried into the stored path (D-54). */
    var storedAbsoluteElapsedMs: Long = 0L
    var storedIdleElapsedMs: Long = 0L

    /**
     * S7 fill attempts dispatched in this run's S7 sequence
     * (D-63 / D-44: at most 3 — the first attempt plus 2
     * retries). Incremented only when a fill attempt actually
     * runs with data available; "no data" Pauses and limit
     * Pauses do not count. Held by the flow layer, never by
     * the state machine (which has no step-back API).
     */
    var s7Attempts: Int = 0

    /**
     * Host confirmation for listed unverified fields. Nothing
     * is ever confirmed implicitly: until the host calls this,
     * S8 keeps listing and does not dispatch (D-36).
     */
    fun confirmUnverified(codes: Collection<String>) {
        confirmedUnverifiedCodes = confirmedUnverifiedCodes + codes
    }
}

/** A built flow: the machine plus its runtime state. */
data class FlowRun(
    val machine: com.example.buypilot.state.StateMachine,
    val state: FlowRuntimeState,
)
