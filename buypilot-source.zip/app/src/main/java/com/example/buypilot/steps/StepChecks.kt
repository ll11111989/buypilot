package com.example.buypilot.steps

import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.StateMachine
import com.example.buypilot.state.StepOutcome

/**
 * Shared checks for the S1–S5 handlers. Every check returns an
 * outcome to return immediately, or null to continue. The order
 * is fixed: time deviation first, then the global page state
 * (queue / blocked / loading), then step-specific checks.
 * No check here invents an E-number: every errorId below is a
 * master-spec E-number, and the time-deviation reason carries
 * no E-number because the master list assigns it none.
 */
internal object StepChecks {

    /** S1 time-deviation: over limit halts as STOPPED (master). */
    fun timeCheck(snapshot: MachineSnapshot): StepOutcome? =
        if (snapshot.timeCheck is StateMachine.TimeCheck.OverLimit) {
            StepOutcome.Pause(
                reason = "S1_TIME_DEVIATION_OVER_LIMIT",
                errorId = null,
            )
        } else {
            null
        }

    /**
     * Global page states, identical for S1–S3:
     * queue/maintenance -> Wait (E02, machine records the step
     * and resumes there with re-validation); 541 -> Block (E03);
     * CAPTCHA -> Block (E04); loading -> Stay (re-check next
     * execute). ERROR and UNKNOWN are NOT mapped here: S1 maps
     * ERROR to E01, S2/S3 map ERROR/UNKNOWN to E08, because the
     * same page fact means a different step failure.
     */
    fun globalPageCheck(model: PageModel): StepOutcome? = when (model.pageState) {
        PageState.QUEUE_OR_MAINTENANCE ->
            StepOutcome.Wait(reason = "QUEUE_OR_MAINTENANCE", errorId = "E02")
        PageState.BLOCKED_541 ->
            StepOutcome.Block(reason = "HTTP_541", errorId = "E03")
        PageState.CAPTCHA ->
            StepOutcome.Block(reason = "CAPTCHA", errorId = "E04")
        PageState.LOADING -> StepOutcome.Stay
        else -> null
    }

    /** Element missing (E05) or not unique (E07). */
    fun requireUnique(elementId: String, model: PageModel): StepOutcome? {
        val count = model.elements[elementId]?.count ?: 0
        return when {
            count == 0 -> StepOutcome.Pause(
                reason = "ELEMENT_NOT_FOUND",
                errorId = "E05",
            )
            count != 1 -> StepOutcome.Pause(
                reason = "ELEMENT_NOT_UNIQUE",
                errorId = "E07",
            )
            else -> null
        }
    }

    /** Element present and unique but not clickable (E06). */
    fun requireClickable(elementId: String, model: PageModel): StepOutcome? {
        val clickable = model.elements[elementId]?.clickable ?: false
        return if (!clickable) {
            StepOutcome.Pause(reason = "ELEMENT_NOT_CLICKABLE", errorId = "E06")
        } else {
            null
        }
    }

    /**
     * After a click, re-check the GLOBAL page state before any
     * step-specific verification (QA S1–S3 exception (1) fix):
     * queue -> Wait (E02), 541 -> Block (E03), CAPTCHA -> Block
     * (E04), LOADING -> Stay. Previously this helper only
     * centralised the LOADING branch, so a page that turned
     * into queue / 541 / CAPTCHA right after a click was
     * misclassified as E08/E11 by the caller. Now the caller
     * receives the global outcome first and only verifies its
     * expected state when this helper returns null. The name
     * is kept so existing call sites need no change.
     */
    fun afterClickLoading(model: PageModel): StepOutcome? =
        globalPageCheck(model)
}
