package com.example.buypilot.storage

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Keystore 背書 AES-GCM 加密實作（Android 環境用）。
 * 密鑰不可匯出；卸載／重裝後密鑰失效，已儲存組合無法恢復（D-50，見 D-50 提示文案）。
 * 注意：本檔需 Android 環境編譯，本環境無 Android SDK，未能喺度編譯，列為保留項。
 */
class AndroidKeystoreCrypto(
    private val alias: String = "profile_vault_key"
) : Crypto {
    private val keyStore: KeyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    private fun getOrCreateKey(): SecretKey {
        val existing = keyStore.getEntry(alias, null) as? KeyStore.SecretKeyEntry
        if (existing != null) return existing.secretKey
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    override fun encrypt(plain: CharArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = cipher.iv
        val plainBytes = plain.joinToString("").toByteArray(Charsets.UTF_8)
        val cipherText = cipher.doFinal(plainBytes)
        plainBytes.fill(0)
        // 格式：IV 長度(1 byte) + IV + 密文。解密端按此格式拆解。
        return byteArrayOf(iv.size.toByte()) + iv + cipherText
    }

    override fun decrypt(cipher: ByteArray): CharArray {
        val ivSize = cipher[0].toInt()
        val iv = cipher.copyOfRange(1, 1 + ivSize)
        val cipherText = cipher.copyOfRange(1 + ivSize, cipher.size)
        val decipher = Cipher.getInstance("AES/GCM/NoPadding")
        decipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        val plainBytes = decipher.doFinal(cipherText)
        val result = String(plainBytes, Charsets.UTF_8).toCharArray()
        plainBytes.fill(0)
        return result
    }
}
