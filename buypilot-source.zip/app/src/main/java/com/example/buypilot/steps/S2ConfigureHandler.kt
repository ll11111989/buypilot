package com.example.buypilot.steps

import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.StepHandler
import com.example.buypilot.state.StepOutcome

/**
 * S2 CONFIGURE — navigate to the product page (if still on the
 * entry page) and configure the user's pre-set product, without
 * ever switching model or inferring data.
 *
 * Parameters are supplied by the flow layer (pre-validated
 * upstream; Water owns parameter validation). This handler
 * refuses a blank product key at construction rather than
 * guessing a product — a construction failure is a wiring
 * error, not a runtime outcome, and must be fixed before a
 * run starts. The handler never invents a product key or a
 * substitute model.
 *
 * D-27 alignment (D-64 handler alignment package): sold-out
 * (E09) and price (E10) are NOT checked, and the PRICE
 * element is not read at all — the flow advances directly on
 * the user's selected product, without option verification.
 * What remains is the step's own work: navigate, select the
 * configured product, and confirm the selection landed
 * (configuredProductKey == productKey, the completion
 * criterion, not an option verification).
 *
 * Outcome mapping (this package's mapping, for QA to check;
 * this is the mapping the P2 core deferred to the S2 package):
 * - element missing -> Pause (E05); duplicate -> Pause (E07);
 *   not clickable / click returns false -> Pause (E06).
 * - click with no effect (page not LOADING and product still
 *   not configured) -> Pause (E08). LOADING after a click ->
 *   Stay (re-check next execute; no second click in this call).
 * - ENTRY branch: one navigate click only, then Stay. The next
 *   execute handles the PRODUCT branch; navigation and
 *   configuration are never two clicks in one execute() call.
 * - PRODUCT branch, already configured -> Advance with no
 *   click (idempotent: resume after WAITING or STOPPED never
 *   re-selects an already-configured product).
 * - queue -> Wait (E02); 541 -> Block (E03); CAPTCHA -> Block
 *   (E04); ERROR/UNKNOWN/BAG/wrong state -> Pause (E08).
 */
class S2ConfigureHandler(
    private val driver: PageDriver,
    private val productKey: String,
    private val navigateElementId: String = PageElements.PRODUCT_NAVIGATE,
    private val selectElementId: String = PageElements.PRODUCT_SELECT,
) : StepHandler {

    init {
        require(productKey.isNotBlank()) { "S2 productKey must be supplied, not inferred" }
    }

    override fun execute(snapshot: MachineSnapshot): StepOutcome {
        StepChecks.timeCheck(snapshot)?.let { return it }
        var model = driver.snapshot()
        StepChecks.globalPageCheck(model)?.let { return it }

        // ENTRY branch: navigate once, then Stay for next execute.
        if (model.pageState == PageState.ENTRY) {
            StepChecks.requireUnique(navigateElementId, model)?.let { return it }
            StepChecks.requireClickable(navigateElementId, model)?.let { return it }
            if (!driver.click(navigateElementId)) {
                return StepOutcome.Pause(reason = "ELEMENT_NOT_CLICKABLE", errorId = "E06")
            }
            model = driver.snapshot()
            StepChecks.afterClickLoading(model)?.let { return it }
            return StepOutcome.Stay
        }

        if (model.pageState != PageState.PRODUCT) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }

        // D-27: sold-out and price are NOT checked here (see
        // class doc). The step proceeds on the selected item.

        // Already configured: advance without re-selecting.
        if (model.configuredProductKey == productKey) {
            return StepOutcome.Advance
        }

        StepChecks.requireUnique(selectElementId, model)?.let { return it }
        StepChecks.requireClickable(selectElementId, model)?.let { return it }
        if (!driver.click(selectElementId)) {
            return StepOutcome.Pause(reason = "ELEMENT_NOT_CLICKABLE", errorId = "E06")
        }
        model = driver.snapshot()
        StepChecks.afterClickLoading(model)?.let { return it }
        if (model.configuredProductKey != productKey) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        return StepOutcome.Advance
    }
}
