package com.example.buypilot.integration

import android.content.Intent
import com.example.buypilot.storage.PickupGroup
import com.example.buypilot.storage.ProductGroup

/**
 * Transport for the S6 host run configuration (Android-only).
 *
 * The flow layer launches PaymentHostActivity with the run's
 * product/pickup groups packed as Intent extras; the host
 * unpacks them and builds the S6 save callbacks from them.
 * Groups are plain data, so they travel as individual extras
 * (no Parcelable, no serialization library, no new format
 * to drift). A missing product model means "no run config":
 * the host then passes null callbacks and the save button
 * stays hidden, exactly as before — the host never invents
 * product/pickup groups to make the button appear.
 *
 * Nullable booleans travel as the strings "true"/"false"
 * and are absent when null; nullable strings are absent
 * when null (getStringExtra returns null either way, which
 * is the correct value for them).
 */
data class S6HostConfig(
    val product: ProductGroup,
    val pickup: PickupGroup,
)

private const val P = "buypilot.s6."

fun S6HostConfig.putInto(intent: Intent): Intent {
    intent.putExtra(P + "product_model", product.model)
    intent.putExtra(P + "product_colour", product.colour)
    intent.putExtra(P + "product_capacity", product.capacity)
    intent.putExtra(P + "product_quantity", product.quantity)
    product.appleCare?.let { intent.putExtra(P + "product_appleCare", it.toString()) }
    product.tradeIn?.let { intent.putExtra(P + "product_tradeIn", it.toString()) }
    intent.putExtra(P + "pickup_method", pickup.method)
    intent.putExtra(P + "pickup_storePriority", pickup.storePriority.toTypedArray())
    pickup.slotPreference?.let { intent.putExtra(P + "pickup_slot", it) }
    pickup.pickupName?.let { intent.putExtra(P + "pickup_name", it) }
    pickup.pickupPhone?.let { intent.putExtra(P + "pickup_phone", it) }
    pickup.pickupEmail?.let { intent.putExtra(P + "pickup_email", it) }
    pickup.deliveryAddress?.let { intent.putExtra(P + "pickup_address", it) }
    return intent
}

/**
 * Rebuilds the run configuration from Intent extras.
 * Defaults applied when individual extras are absent
 * (QA minor note — listed explicitly so no default is
 * invisible): product model / colour / capacity absent →
 * the whole config is null (no run configuration at all);
 * product quantity absent → 0 (a transport default only —
 * 0 is not a valid run quantity and hosts must treat it as
 * unsupplied); appleCare / tradeIn absent or unrecognized →
 * null (unset, per their STORED_NOT_USED semantics); pickup
 * method absent → "pickup"; storePriority absent → empty
 * list; the optional pickup fields absent → null.
 */
fun s6HostConfigFromIntent(intent: Intent): S6HostConfig? {
    val model = intent.getStringExtra(P + "product_model") ?: return null
    val colour = intent.getStringExtra(P + "product_colour") ?: return null
    val capacity = intent.getStringExtra(P + "product_capacity") ?: return null
    val quantity = intent.getIntExtra(P + "product_quantity", 0)
    fun bool(key: String): Boolean? = when (intent.getStringExtra(P + key)) {
        "true" -> true
        "false" -> false
        else -> null
    }
    val product = ProductGroup(
        model = model,
        colour = colour,
        capacity = capacity,
        quantity = quantity,
        appleCare = bool("product_appleCare"),
        tradeIn = bool("product_tradeIn"),
    )
    val pickup = PickupGroup(
        method = intent.getStringExtra(P + "pickup_method") ?: "pickup",
        storePriority = intent.getStringArrayExtra(P + "pickup_storePriority")?.toList()
            ?: emptyList(),
        slotPreference = intent.getStringExtra(P + "pickup_slot"),
        pickupName = intent.getStringExtra(P + "pickup_name"),
        pickupPhone = intent.getStringExtra(P + "pickup_phone"),
        pickupEmail = intent.getStringExtra(P + "pickup_email"),
        deliveryAddress = intent.getStringExtra(P + "pickup_address"),
    )
    return S6HostConfig(product, pickup)
}
