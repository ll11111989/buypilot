package com.example.buypilot.integration

import com.example.buypilot.payment.CardSession
import com.example.buypilot.storage.PickupGroup
import com.example.buypilot.storage.ProductGroup
import com.example.buypilot.storage.ProfileRepository
import com.example.buypilot.storage.WorkingCopy

/**
 * Host wiring for the S6 save button (D-54 follow-up (b)).
 *
 * The S6 screen's save button is hidden by default because its
 * onSaveProfile parameter defaults to null (QA reservation
 * (2) on the wiring package). This factory is the host-side
 * answer: given the repository, the run's product/pickup
 * groups, the live S6 session and the flow layer's saved
 * continuation, it returns the three callbacks the screen
 * needs, so the button is enabled end to end instead of
 * staying hidden. The host must supply real product/pickup
 * groups from the S1–S5 configuration — this factory never
 * invents them.
 *
 * The onSaved continuation receives the WorkingCopy plus
 * the S6 session's already-elapsed clocks (absolute + idle,
 * D-54): the flow layer passes all three to the S7 stored
 * path so the D-19 cap keeps running from the original S6
 * begin. The factory itself never closes the copy; the S7
 * stored path closes it in finally.
 *
 * This file is pure Kotlin (no Android dependency) so the
 * factory is unit-testable on the JVM; the Android-only
 * parts (repository construction with Keystore crypto,
 * Intent transport of the run config) live in the host
 * Activities, which are uncompiled reservations.
 */
data class S6SaveCallbacks(
    val onSaveProfile: (String) -> SaveS6Outcome,
    val isFirstSave: () -> Boolean,
    val onSavedWithWorkingCopy: (WorkingCopy, Long, Long) -> Unit,
)

fun createS6SaveCallbacks(
    repository: ProfileRepository,
    product: ProductGroup,
    pickup: PickupGroup,
    session: CardSession,
    onSaved: (WorkingCopy, Long, Long) -> Unit,
): S6SaveCallbacks = S6SaveCallbacks(
    onSaveProfile = { name ->
        saveS6InputAsProfile(repository, name, product, pickup, session)
    },
    // D-79: a failing first-save read must not throw raw
    // out of the tap handler either. Fail-safe: report
    // "first save" so the mandatory D-50 warning is shown;
    // the save itself then reaches the pre-check read,
    // which reports the read failure properly
    // (PrecheckReadFailed) and performs no save.
    isFirstSave = {
        try {
            repository.listProfiles().isEmpty()
        } catch (e: Exception) {
            true
        }
    },
    onSavedWithWorkingCopy = onSaved,
)
