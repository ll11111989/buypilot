package com.example.buypilot

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import com.example.buypilot.flow.FlowIntentConfig
import com.example.buypilot.flow.FlowRun
import com.example.buypilot.flow.WebViewPageDriver
import com.example.buypilot.flow.buildFlow
import com.example.buypilot.flow.runFlowUntilStop
import com.example.buypilot.flow.supplyStoredRetryCvv
import com.example.buypilot.integration.S6SaveCallbacks
import com.example.buypilot.integration.createS6SaveCallbacks
import com.example.buypilot.storage.PickupGroup
import com.example.buypilot.storage.ProductGroup
import com.example.buypilot.storage.WorkingCopy
import com.example.buypilot.integration.FileProfileBackend
import com.example.buypilot.integration.ProfileManagementActivity
import com.example.buypilot.payment.CardSession
import com.example.buypilot.payment.CvvTopUpScreen
import com.example.buypilot.payment.PaymentInputScreen
import com.example.buypilot.state.GlobalState
import com.example.buypilot.state.PurchaseStep
import com.example.buypilot.storage.AndroidKeystoreCrypto
import com.example.buypilot.storage.ProfileRepository
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Flow host (post-merge flow layer) — replaces the P1
 * skeleton's bare machine with the wired S1–S9 flow.
 *
 * What this Activity does:
 * - Builds the complete flow via buildFlow(): S1–S9 handlers
 *   registered into one StateMachine, driven through a
 *   WebViewPageDriver bound to the WebView below. Buttons map
 *   to flow operations: Start / Run / Pause / Resume / Cancel
 *   (the machine still owns every transition).
 * - The run configuration comes from Intent extras
 *   (FlowIntentConfig — supplied by the launcher). With no
 *   complete configuration the flow is not built and no run
 *   can start: this host invents no product, price or
 *   summary.
 * - The WebView loads NOTHING itself: no URL is preset and
 *   no navigation is performed by the app (D-01 route
 *   discipline). JavaScript is ENABLED because the page
 *   driver works by observing/acting on the live page's UI
 *   (this reverses the P1 placeholder's JS-off stance, which
 *   belonged to a shell with no driver). The driver's
 *   WebViewClient is installed so HTTP 541 is tracked.
 * - S6 execution: when the flow reaches S6, this window
 *   shows the S6 input UI in place of the WebView — the full
 *   PaymentInputScreen on the manual path, or the CVV-only
 *   CvvTopUpScreen on the stored path — writing into the
 *   same CardSession the flow handlers read. FLAG_SECURE is
 *   set on this window while S6 is shown and cleared after.
 *   The S6 screen's save-as-profile callbacks ARE passed
 *   here when the run config carries product/pickup groups
 *   (S6SaveCallbacks factory): the button appears only on
 *   the manual path, only on explicit tap + name confirm
 *   (D-47), with the D-50 warning shown first when the
 *   store is empty; on Saved the continuation stashes the
 *   WorkingCopy + S6 clocks in the flow state and resumes,
 *   so the run continues via the stored path. With no
 *   groups in the config the callbacks are null and the
 *   button stays hidden — this host never invents groups
 *   and never auto-saves.
 * - Flow execution runs on a background executor (the
 *   WebView driver blocks on page evaluation and must never
 *   run on the UI thread); UI state is refreshed afterwards.
 *
 * PRODUCT DEFAULT — S7 LOCKED: buildFlow is called with
 * s7Unlocked = PRODUCT_S7_UNLOCKED = false. The S7 handler
 * exists and is registered, but the machine gate stops the
 * run at S7 while locked. WHEN the product default opens is
 * Kenneth's decision (listed as a decision item in the flow
 * delivery); this host does not open it.
 *
 * NOT done here: no automatic deletion of anything (D-35 —
 * the state core has no clear callback at all); combination
 * management entry launches ProfileManagementActivity, as
 * before.
 *
 * This file is Android source, NOT compiled or run in this
 * environment (no Android SDK / device — the standing
 * uncompiled boundary).
 */
class MainActivity : ComponentActivity() {

    private val session = CardSession()

    private val repository: ProfileRepository by lazy {
        ProfileRepository(
            FileProfileBackend(filesDir),
            AndroidKeystoreCrypto(),
            { UUID.randomUUID().toString() },
        )
    }

    private var driver: WebViewPageDriver? = null
    private var flowRun: FlowRun? = null
    private val flowExecutor = Executors.newSingleThreadExecutor()

    private var snapshotText by mutableStateOf("未開始")
    private var atS6 by mutableStateOf(false)
    private var storedPath by mutableStateOf(false)

    /**
     * Run product/pickup groups for the S6 save button
     * (from the run config; null when the launcher did not
     * supply them, in which case the button stays hidden).
     */
    private var runProductGroup: ProductGroup? = null
    private var runPickupGroup: PickupGroup? = null

    /**
     * S6 save callbacks (D-47/D-54), or null when the run
     * config carries no groups. Built from the accepted
     * S6SaveCallbacks factory: the button appears only on
     * explicit user tap + name confirm (D-47), the D-50
     * Keystore warning is shown by the screen when the
     * store is empty (isFirstSave), and on Saved the
     * continuation stashes the WorkingCopy + S6 clocks in
     * the flow state and resumes, so the run continues
     * via the stored path (S6 Advance branch / S7 stored
     * branch keyed on the stashed copy). The factory never
     * invents groups and this host never auto-saves: run
     * input, filling, submit success/refusal never reach
     * saveProfile.
     */
    private fun s6SaveCallbacks(): S6SaveCallbacks? {
        val product = runProductGroup ?: return null
        val pickup = runPickupGroup ?: return null
        return createS6SaveCallbacks(
            repository, product, pickup, session,
        ) { copy, abs, idle ->
            val run = flowRun
            if (run != null) {
                run.state.storedWorkingCopy = copy
                run.state.storedAbsoluteElapsedMs = abs
                run.state.storedIdleElapsedMs = idle
                resumeFlow()
            }
        }
    }

    /**
     * S7 retry input is offered only for retryable stops
     * (D-63): never after an E16 read-back mismatch (hard
     * stop), never after the retry limit, and never for
     * page-state stops that re-input cannot fix.
     */
    private var atS7RetryInput by mutableStateOf(false)
    private var retryErrorText by mutableStateOf<String?>(null)

    private fun refresh() {
        val run = flowRun
        if (run == null) {
            snapshotText = if (FlowIntentConfig.fromIntent(intent) == null) {
                "未有執行設定（Intent 未帶齊 FlowConfig extras）— 未能建立流程"
            } else {
                "未開始"
            }
            atS6 = false
            return
        }
        val machine = run.machine
        val snap = machine.snapshot()
        snapshotText = "步驟 ${snap.step.code}｜全域 ${snap.global ?: "未開始"}" +
            "｜已提交 ${snap.submitted}｜需重驗 ${snap.needsRevalidation}" +
            "｜完成 ${snap.isComplete}｜S7 解鎖 ${snap.s7Unlocked}" +
            "\n最後原因 ${machine.lastReason ?: "—"}" +
            "\n事件 ${machine.eventLog.takeLast(5).joinToString("；")}"
        atS6 = snap.step == PurchaseStep.S6_PAYMENT_INPUT && !snap.isComplete
        storedPath = run.state.selectedProfileId != null
        // FLAG_SECURE covers every card-input window here (S6
        // input and S7 retry input alike); set below once
        // atS7RetryInput is computed.
        // D-63 retry input: offered at a STOPPED S7 with
        // attempts left, a retryable reason, and no usable
        // data left (stored copy consumed, or manual session
        // cleared). Data still present -> the 執行 button
        // resumes directly without re-input.
        val s7Retryable = snap.step == PurchaseStep.S7_PAYMENT_FILL &&
            snap.global == GlobalState.STOPPED &&
            run.state.s7Attempts < 3 &&
            machine.lastReason !in NON_RETRYABLE_S7_REASONS
        atS7RetryInput = s7Retryable && (
            (storedPath && run.state.storedWorkingCopy == null) ||
                (!storedPath && !(session.isActive && session.hasAllFields()))
            )
        if (s7Retryable) {
            snapshotText += if (atS7RetryInput) {
                "\n可重試（第 ${run.state.s7Attempts + 1} 次，上限 3 次）：請重新輸入後繼續"
            } else {
                "\n可重試（第 ${run.state.s7Attempts + 1} 次，上限 3 次）：按「繼續」直接重試"
            }
        }
        retryErrorText?.let { snapshotText += "\n$it" }
        if (atS6 || atS7RetryInput) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    private fun runFlowAsync() {
        val run = flowRun ?: return
        flowExecutor.execute {
            runFlowUntilStop(run)
            runOnUiThread { refresh() }
        }
    }

    private fun startFlow() {
        val config = FlowIntentConfig.fromIntent(intent) ?: run {
            refresh()
            return
        }
        val pageDriver = driver ?: run {
            refresh()
            return
        }
        flowRun?.state?.storedWorkingCopy?.close()
        runProductGroup = config.productGroup
        runPickupGroup = config.pickupGroup
        val run = buildFlow(
            driver = pageDriver,
            config = config,
            session = session,
            repository = repository,
            s7Unlocked = PRODUCT_S7_UNLOCKED,
        )
        flowRun = run
        run.machine.start()
        refresh()
        runFlowAsync()
    }

    private fun resumeFlow() {
        val machine = flowRun?.machine ?: return
        when (machine.globalState) {
            GlobalState.STOPPED -> machine.resumeFromStopped()
            GlobalState.WAITING -> machine.resumeFromWaiting()
            else -> Unit
        }
        refresh()
        runFlowAsync()
    }

    override fun onDestroy() {
        flowRun?.state?.storedWorkingCopy?.close()
        session.clear(CardSession.ClearTrigger.SESSION_ENDED)
        flowExecutor.shutdownNow()
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refresh()
        setContent {
            Column(Modifier.background(Color(0xFFFFF3E0))) {
                Text("BuyPilot 主畫面")
                Text(snapshotText)
                Row {
                    Button(onClick = { startFlow() }) { Text("開始") }
                    Button(onClick = { runFlowAsync() }) { Text("執行") }
                    Button(onClick = {
                        flowRun?.machine?.pause("USER_PAUSE")
                        refresh()
                    }) { Text("暫停") }
                    Button(onClick = { resumeFlow() }) { Text("繼續") }
                    Button(onClick = {
                        flowRun?.machine?.cancel()
                        refresh()
                    }) { Text("取消") }
                    Button(onClick = {
                        startActivity(
                            Intent(this@MainActivity, ProfileManagementActivity::class.java),
                        )
                    }) { Text("組合管理") }
                }
                // S6 save callbacks (null when the run config
                // carries no groups: the save button then
                // stays hidden, exactly as the screen's
                // default). Computed once per composition;
                // the continuation reads flowRun fresh.
                val saveCallbacks = s6SaveCallbacks()
                if (atS6) {
                    // S6 step execution in this window (FLAG_SECURE
                    // set by refresh()): manual path = full input;
                    // stored path = CVV top-up only (D-46).
                    if (storedPath) {
                        CvvTopUpScreen(
                            session = session,
                            onReady = { resumeFlow() },
                        )
                    } else {
                        PaymentInputScreen(
                            session = session,
                            onReady = { resumeFlow() },
                            onCancel = {
                                flowRun?.machine?.cancel()
                                refresh()
                            },
                            onSessionCleared = { refresh() },
                            onSaveProfile = saveCallbacks?.onSaveProfile,
                            isFirstSave = saveCallbacks?.isFirstSave ?: { false },
                            onSavedWithWorkingCopy =
                                saveCallbacks?.onSavedWithWorkingCopy,
                        )
                    }
                } else if (atS7RetryInput) {
                    // D-63 retry input in this window (FLAG_SECURE
                    // set by refresh()): stored path tops up the
                    // CVV only and re-materializes; manual path
                    // re-enters all 3 fields. A failed retry
                    // supply reports an error instead of
                    // executing with no data.
                    if (storedPath) {
                        CvvTopUpScreen(
                            session = session,
                            onReady = {
                                val run = flowRun
                                if (run != null &&
                                    supplyStoredRetryCvv(run, session, repository)
                                ) {
                                    retryErrorText = null
                                    resumeFlow()
                                } else {
                                    retryErrorText =
                                        "重試載入失敗：組合解密唔到或已被刪除，請取消後重新開始。"
                                    refresh()
                                }
                            },
                        )
                    } else {
                        PaymentInputScreen(
                            session = session,
                            onReady = { resumeFlow() },
                            onCancel = {
                                flowRun?.machine?.cancel()
                                refresh()
                            },
                            onSessionCleared = { refresh() },
                            onSaveProfile = saveCallbacks?.onSaveProfile,
                            isFirstSave = saveCallbacks?.isFirstSave ?: { false },
                            onSavedWithWorkingCopy =
                                saveCallbacks?.onSavedWithWorkingCopy,
                        )
                    }
                } else {
                    Text("WebView placeholder (diagnostic build: WebView disabled)")
                }
            }
        }
    }

    companion object {
        /**
         * Product default for the S7 gate: LOCKED. Opening it
         * is Kenneth's decision, not this host's (see class
         * doc). Test machines pass true to buildFlow directly.
         */
        const val PRODUCT_S7_UNLOCKED: Boolean = false

        private val NON_RETRYABLE_S7_REASONS = setOf(
            "READBACK_MISMATCH",
            "S7_RETRY_LIMIT_EXCEEDED",
            "SOLD_OUT",
            "PAGE_STATE_MISMATCH",
            "S7_LOCKED",
        )
    }
}
