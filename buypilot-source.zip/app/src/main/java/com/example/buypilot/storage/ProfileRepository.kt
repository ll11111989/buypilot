package com.example.buypilot.storage

/**
 * 資料組合儲存組件 — 儲存庫實作（D-45 設計、D-46 至 D-50）。
 *
 * 設計要點：
 * - 只存 App 本機私有儲存，加密由注入嘅 Crypto 負責（Android 實作見 AndroidKeystoreCrypto）。
 * - 備份排除、無網絡、無雲端同步，屬 App 層配置（見 README 備註），唔喺呢個類入面做網絡。
 * - 按 D-35 一律無自動刪除：本類無任何因成功、被拒、結果未明、逾時、取消、
 *   切背景或工作階段終止而刪除組合嘅方法。刪除只有 deleteProfile（用戶手動）。
 * - 姓名規則只限 D-48 定明嗰啲：trim 後非空、唯一性（lowercase()＋trim）、上限。
 *   唔可以擅加未核准嘅限制性姓名規則（D-51 保留項 4）。
 */

interface Crypto {
    fun encrypt(plain: CharArray): ByteArray
    fun decrypt(cipher: ByteArray): CharArray
}

interface ProfileBackend {
    fun loadAll(): List<StoredProfile>
    fun saveAll(profiles: List<StoredProfile>)
}

sealed class SaveOutcome {
    data class Saved(val id: String) : SaveOutcome()
    data class Blocked(val reason: SaveBlock) : SaveOutcome()
    // 加密／建鑰失敗（D-53 保留第 5 項補述）：加密喺寫入之前完成，失敗即無寫入、
    // 既有組合唔刪唔改；呼叫方按 STOPPED 對應處理（同解密失敗一致），
    // 唔係 FAILED／CANCELLED，亦唔係靜默成功。完整路徑見 docs/keystore-integration.md。
    object EncryptionFailed : SaveOutcome()
    // 寫入失敗（D-66 定案，D-68 實作）：backend.saveAll 本身 IO 失敗（而非加密失敗）
    // 回此結果，唔再例外原樣拋出。寫入狀態不明——唔可以假設舊檔不變或新組合
    // 已寫入；呼叫方按 STOPPED 對應處理，並必須按 D-67 重新列出（listProfiles）
    // 核實當前已儲存狀態，以列出結果為準；列出本身亦失敗時同樣按 STOPPED
    // 處理並報告核實唔到，唔可以靜靜繼續。儲存庫本身唔緩存列表，
    // 每次 listProfiles 都讀後端當刻狀態，令重新列出核實可行。
    object StorageWriteFailed : SaveOutcome()
}

enum class SaveBlock { EMPTY_NAME, DUPLICATE_NAME, LIMIT_REACHED, NOT_FOUND }

sealed class MaterializeOutcome {
    data class Ok(val copy: WorkingCopy) : MaterializeOutcome()
    // 解密失敗 → 呼叫方映射為 STOPPED（提交前停低），組合唔刪唔改，只以組合代號回報。
    // 如實作採用 STOPPED 以外映射，須在實作審時說明理由（D-51 保留項 5）。
    object DecryptionFailed : MaterializeOutcome()
    object NotFound : MaterializeOutcome()
}

sealed class DeleteOutcome {
    object Deleted : DeleteOutcome()
    // 刪除失敗（D-73 定案，D-75 實作）：loadAll 或 saveAll 失敗一併歸入；
    // 寫入狀態不明，呼叫方按 STOPPED 對應處理，並必須按 D-74 重新列出
    // （listProfiles）核實，以列出結果為準；列出本身亦失敗時同樣按 STOPPED
    // 處理並報告核實唔到。獨立結果類型，唔改已接納嘅 save／update 介面。
    object WriteFailed : DeleteOutcome()
}

sealed class EditLoadOutcome {
    data class Ok(val profile: EditableProfile) : EditLoadOutcome()
    // 解密失敗 → 呼叫方映射為 STOPPED，組合唔刪唔改（同 materializeForRun 一致）。
    object DecryptionFailed : EditLoadOutcome()
    object NotFound : EditLoadOutcome()
}

class ProfileRepository(
    private val backend: ProfileBackend,
    private val crypto: Crypto,
    private val idGenerator: () -> String
) {
    companion object {
        const val MAX_PROFILES = 10 // D-49
        // D-50 提示文案：首次儲存時彈出＋組合管理介面常駐，缺失即實作缺陷。
        const val KEYSTORE_WARNING_TEXT =
            "注意：卸載或重裝 App 後，Keystore 密鑰失效，已儲存嘅組合將無法恢復。"
    }

    private fun normalizedName(name: String): String = name.trim().lowercase()

    /**
     * 只限用戶明確儲存（D-47）：呼叫方必須只喺組合管理／S6 介面嘅明確
     * 「儲存為組合」＋確認組合名動作先呼叫本方法。執行輸入、S7 填表、
     * 提交完成／被拒全部唔可以呼叫本方法。
     * 校驗順序（D-48／D-49）：trim 後非空 → 唯一性 → 數量上限，任一唔過即阻擋，唔寫入、唔覆寫。
     */
    fun saveProfile(input: ProfileInput): SaveOutcome {
        val trimmedName = input.name.trim()
        if (trimmedName.isEmpty()) return SaveOutcome.Blocked(SaveBlock.EMPTY_NAME)
        val existing = backend.loadAll()
        val key = normalizedName(trimmedName)
        if (existing.any { normalizedName(it.name) == key }) {
            return SaveOutcome.Blocked(SaveBlock.DUPLICATE_NAME)
        }
        if (existing.size >= MAX_PROFILES) {
            return SaveOutcome.Blocked(SaveBlock.LIMIT_REACHED)
        }
        val cardNumberCopy = input.cardNumber.copyOf()
        val expiryCopy = input.expiry.copyOf()
        val last4 = last4Of(cardNumberCopy)
        // 加密（含首次建鑰）喺任何寫入之前完成：失敗即回 EncryptionFailed，
        // backend.saveAll 唔會被呼叫，無不完整組合、既有組合原封不動；
        // 明文副本喺成功同失敗路徑都填零（D-53 保留第 5 項補述）。
        val encryptedCardNumber: ByteArray
        val encryptedExpiry: ByteArray
        try {
            encryptedCardNumber = crypto.encrypt(cardNumberCopy)
            encryptedExpiry = crypto.encrypt(expiryCopy)
        } catch (e: Exception) {
            cardNumberCopy.fill('\u0000')
            expiryCopy.fill('\u0000')
            return SaveOutcome.EncryptionFailed
        }
        cardNumberCopy.fill('\u0000')
        expiryCopy.fill('\u0000')
        val stored = StoredProfile(
            id = idGenerator(),
            name = trimmedName,
            product = input.product,
            pickup = input.pickup,
            encryptedCardNumber = encryptedCardNumber,
            encryptedExpiry = encryptedExpiry,
            cardLast4 = last4
        )
        try {
            backend.saveAll(existing + stored)
        } catch (e: Exception) {
            return SaveOutcome.StorageWriteFailed
        }
        return SaveOutcome.Saved(stored.id)
    }

    /**
     * 只限用戶明確編輯（D-47）。改名同樣受 D-48 唯一性校驗；更新現有組合
     * 唔計入新增上限（D-49）。
     */
    fun updateProfile(id: String, input: ProfileInput): SaveOutcome {
        val trimmedName = input.name.trim()
        if (trimmedName.isEmpty()) return SaveOutcome.Blocked(SaveBlock.EMPTY_NAME)
        val existing = backend.loadAll()
        val target = existing.firstOrNull { it.id == id } ?: return SaveOutcome.Blocked(SaveBlock.NOT_FOUND)
        val key = normalizedName(trimmedName)
        if (existing.any { it.id != id && normalizedName(it.name) == key }) {
            return SaveOutcome.Blocked(SaveBlock.DUPLICATE_NAME)
        }
        val cardNumberCopy = input.cardNumber.copyOf()
        val expiryCopy = input.expiry.copyOf()
        val last4 = last4Of(cardNumberCopy)
        // 同 saveProfile：先加密、後寫入；失敗回 EncryptionFailed，原組合保持舊值。
        val encryptedCardNumber: ByteArray
        val encryptedExpiry: ByteArray
        try {
            encryptedCardNumber = crypto.encrypt(cardNumberCopy)
            encryptedExpiry = crypto.encrypt(expiryCopy)
        } catch (e: Exception) {
            cardNumberCopy.fill('\u0000')
            expiryCopy.fill('\u0000')
            return SaveOutcome.EncryptionFailed
        }
        cardNumberCopy.fill('\u0000')
        expiryCopy.fill('\u0000')
        val updated = target.copy(
            name = trimmedName,
            product = input.product,
            pickup = input.pickup,
            encryptedCardNumber = encryptedCardNumber,
            encryptedExpiry = encryptedExpiry,
            cardLast4 = last4
        )
        try {
            backend.saveAll(existing.map { if (it.id == id) updated else it })
        } catch (e: Exception) {
            return SaveOutcome.StorageWriteFailed
        }
        return SaveOutcome.Saved(id)
    }

    /** 唯一刪除途徑：用戶手動刪成個組合。無欄位級刪除。 */
    fun deleteProfile(id: String): DeleteOutcome {
        val existing = try {
            backend.loadAll()
        } catch (e: Exception) {
            // D-76：loadAll 失敗同 saveAll 失敗一併歸入 WriteFailed。
            return DeleteOutcome.WriteFailed
        }
        try {
            backend.saveAll(existing.filterNot { it.id == id })
        } catch (e: Exception) {
            return DeleteOutcome.WriteFailed
        }
        // 刪唔存在 id 維持靜默無操作（D-76）：filterNot 刪走零個、寫回同一列表，
        // 回 Deleted，唔改為錯誤或 NOT_FOUND。
        return DeleteOutcome.Deleted
    }

    /** 列表只回傳遮蔽摘要（組合名＋末 4），唔回傳完整卡號、到期日。 */
    fun listProfiles(): List<ProfileSummary> =
        backend.loadAll().map { ProfileSummary(it.id, it.name, it.cardLast4) }

    /**
     * 儲存層 → S6／S7 具體化（D-43 分層）：
     * 由儲存解密卡號／到期日，連同 S6 每次補輸入嘅 CVV（D-46，唔入庫），
     * 喺 RAM 具體化工作副本。工作副本 finally 清 ≠ 刪已儲存組合。
     * 解密失敗：組合唔刪唔改，呼叫方按 STOPPED 處理。
     */
    fun materializeForRun(id: String, cvvFromS6: CharArray): MaterializeOutcome {
        val stored = backend.loadAll().firstOrNull { it.id == id }
            ?: return MaterializeOutcome.NotFound
        val (cardNumber, expiry) = decryptPair(stored)
            ?: return MaterializeOutcome.DecryptionFailed
        return MaterializeOutcome.Ok(
            WorkingCopy(cardNumber, expiry, cvvFromS6.copyOf())
        )
    }

    /**
     * 管理畫面編輯用完整讀取（D-57 方案 A）：
     * 只限用戶喺組合管理畫面明確進入編輯時呼叫；解密卡號／到期日連同其餘已存欄位
     * 回傳 EditableProfile 填表，更新經 updateProfile 明確儲存。
     * 禁止呼叫點（同模組禁止清單一致，D-58／D-59 保留第 (4) 項補回）：
     * 執行輸入、S7 填表、提交完成、提交被拒、結果未明、逾時、取消、切背景、
     * 工作階段終止一律禁止呼叫 loadForEdit。
     * 同 materializeForRun 區分：嗰個係執行用（連 S6 補輸入 CVV 入 WorkingCopy），
     * 呢個係編輯用、無 CVV（D-46）。唔影響 listProfiles 遮蔽規則（仍只回名＋末 4）。
     * 解密失敗：組合唔刪唔改，呼叫方按 STOPPED 處理。
     */
    fun loadForEdit(id: String): EditLoadOutcome {
        val stored = backend.loadAll().firstOrNull { it.id == id }
            ?: return EditLoadOutcome.NotFound
        val (cardNumber, expiry) = decryptPair(stored)
            ?: return EditLoadOutcome.DecryptionFailed
        return EditLoadOutcome.Ok(
            EditableProfile(stored.id, stored.name, stored.product, stored.pickup, cardNumber, expiry)
        )
    }

    /**
     * 分步解密（materializeForRun 與 loadForEdit 共用）：
     * 卡號先行；到期日解密失敗時先填零已解密嘅卡號陣列再回 null，
     * 唔好留住明文卡號喺 RAM（D-56 跟進修正項 b）。
     */
    private fun decryptPair(stored: StoredProfile): Pair<CharArray, CharArray>? {
        val cardNumber = try {
            crypto.decrypt(stored.encryptedCardNumber)
        } catch (e: Exception) {
            return null
        }
        val expiry = try {
            crypto.decrypt(stored.encryptedExpiry)
        } catch (e: Exception) {
            cardNumber.fill('\u0000')
            return null
        }
        return cardNumber to expiry
    }

    private fun last4Of(cardNumber: CharArray): String {
        val digits = cardNumber.filter { it.isDigit() }
        return if (digits.size >= 4) digits.takeLast(4).joinToString("") else ""
    }
}
