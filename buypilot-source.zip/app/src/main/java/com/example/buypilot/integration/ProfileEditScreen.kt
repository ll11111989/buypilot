package com.example.buypilot.integration

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.buypilot.payment.CardValidator
import com.example.buypilot.storage.EditLoadOutcome
import com.example.buypilot.storage.EditableProfile
import com.example.buypilot.storage.PickupGroup
import com.example.buypilot.storage.ProductGroup
import com.example.buypilot.storage.ProfileInput
import com.example.buypilot.storage.ProfileRepository
import com.example.buypilot.storage.SaveBlock
import com.example.buypilot.storage.SaveOutcome
import java.util.Calendar

/**
 * Combination edit screen — D-57 Option A (full read).
 *
 * Opening a combination reads its stored data via
 * repository.loadForEdit and prefills the form; the
 * user edits whichever fields they want and saves through
 * repository.updateProfile. There is deliberately no
 * full-re-entry form (D-57 rejected that option).
 *
 * Full card data IS shown here (that is the point of the
 * full-read design): the host Activity
 * (ProfileManagementActivity) sets FLAG_SECURE for the
 * whole window, and this code writes no Log and uses no
 * clipboard. Buffer hygiene (QA first-review points):
 * - the decrypted profile returned by loadForEdit is
 *   clear()ed immediately after prefill, never kept;
 * - the arrays built for updateProfile are zeroed in a
 *   finally after the call (the repository copies its
 *   inputs but does not clear the caller's arrays);
 * - the form's text state itself is Strings, which cannot
 *   be zeroed — the same accepted limitation as the S6
 *   screen; the values live only in this FLAG_SECURE
 *   window's state and are dropped on exit.
 *
 * NOT_FOUND is handled explicitly in BOTH paths (D-57):
 * a missing combination on open shows the dedicated
 * not-found view, and a combination deleted between open
 * and save switches to the same view with a "nothing was
 * saved" note — never a generic block, never mislabelled
 * as another reason.
 *
 * Decryption failure on open shows the STOPPED view: the
 * combination is untouched, nothing is edited or saved
 * (D-51 mapping, same as materializeForRun).
 *
 * There is NO CVV field: CVV was never stored (D-46), so
 * there is nothing to read or show; the form says so
 * explicitly instead of inventing a field. Update is
 * constrained by the repository per D-48 (name uniqueness)
 * and D-49 (updates do not count toward the cap).
 */
@Composable
fun ProfileEditScreen(
    repository: ProfileRepository,
    profileId: String,
    onDone: (String?) -> Unit,
) {
    var uiState by remember(profileId) {
        mutableStateOf(loadEditState(repository, profileId))
    }

    when (val state = uiState) {
        is EditUiState.NotFound -> Column(Modifier.padding(16.dp)) {
            Text(state.message)
            Button(
                onClick = { onDone(null) },
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
            ) { Text("返回列表") }
        }
        EditUiState.DecryptionFailed -> Column(Modifier.padding(16.dp)) {
            Text("讀取失敗：組合資料解密唔到，已停止。組合本身無被修改或刪除。")
            Button(
                onClick = { onDone(null) },
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
            ) { Text("返回列表") }
        }
        is EditUiState.Editing -> EditForm(
            repository = repository,
            profileId = profileId,
            form = state.form,
            onSaved = { onDone("已儲存變更。") },
            onNotFoundOnSave = {
                uiState = EditUiState.NotFound(
                    "搵唔到呢個組合 — 可能已經被刪除，未有儲存任何變更。",
                )
            },
            onCancel = { onDone(null) },
        )
    }
}

private sealed class EditUiState {
    data class NotFound(val message: String) : EditUiState()
    object DecryptionFailed : EditUiState()
    data class Editing(val form: EditFormState) : EditUiState()
}

private fun loadEditState(
    repository: ProfileRepository,
    profileId: String,
): EditUiState = when (val outcome = repository.loadForEdit(profileId)) {
    is EditLoadOutcome.Ok -> {
        val form = EditFormState.from(outcome.profile)
        // QA point: the decrypted profile is clear()ed right
        // after prefill, never kept in form state as arrays.
        outcome.profile.clear()
        EditUiState.Editing(form)
    }
    EditLoadOutcome.NotFound ->
        EditUiState.NotFound("搵唔到呢個組合 — 可能已經被刪除。")
    EditLoadOutcome.DecryptionFailed -> EditUiState.DecryptionFailed
}

private class EditFormState(
    name: String,
    model: String,
    colour: String,
    capacity: String,
    quantityText: String,
    appleCare: Boolean?,
    tradeIn: Boolean?,
    method: String,
    storePriorityText: String,
    slotPreference: String,
    pickupName: String,
    pickupPhone: String,
    pickupEmail: String,
    deliveryAddress: String,
    cardNumberText: String,
    expiryText: String,
) {
    var name by mutableStateOf(name)
    var model by mutableStateOf(model)
    var colour by mutableStateOf(colour)
    var capacity by mutableStateOf(capacity)
    var quantityText by mutableStateOf(quantityText)
    var appleCare by mutableStateOf(appleCare)
    var tradeIn by mutableStateOf(tradeIn)
    var method by mutableStateOf(method)
    var storePriorityText by mutableStateOf(storePriorityText)
    var slotPreference by mutableStateOf(slotPreference)
    var pickupName by mutableStateOf(pickupName)
    var pickupPhone by mutableStateOf(pickupPhone)
    var pickupEmail by mutableStateOf(pickupEmail)
    var deliveryAddress by mutableStateOf(deliveryAddress)
    var cardNumberText by mutableStateOf(cardNumberText)
    var expiryText by mutableStateOf(expiryText)

    companion object {
        fun from(data: EditableProfile): EditFormState = EditFormState(
            name = data.name,
            model = data.product.model,
            colour = data.product.colour,
            capacity = data.product.capacity,
            quantityText = data.product.quantity.toString(),
            appleCare = data.product.appleCare,
            tradeIn = data.product.tradeIn,
            method = data.pickup.method,
            storePriorityText = data.pickup.storePriority.joinToString("\n"),
            slotPreference = data.pickup.slotPreference ?: "",
            pickupName = data.pickup.pickupName ?: "",
            pickupPhone = data.pickup.pickupPhone ?: "",
            pickupEmail = data.pickup.pickupEmail ?: "",
            deliveryAddress = data.pickup.deliveryAddress ?: "",
            cardNumberText = String(data.cardNumber),
            expiryText = String(data.expiry),
        )
    }
}

@Composable
private fun EditForm(
    repository: ProfileRepository,
    profileId: String,
    form: EditFormState,
    onSaved: () -> Unit,
    onNotFoundOnSave: () -> Unit,
    onCancel: () -> Unit,
) {
    var message by remember { mutableStateOf<String?>(null) }

    fun save() {
        if (form.name.isBlank()) {
            message = "組合名唔可以空白。"
            return
        }
        if (form.model.isBlank() || form.colour.isBlank() ||
            form.capacity.isBlank()
        ) {
            message = "型號／顏色／容量唔可以空白。"
            return
        }
        val quantity = form.quantityText.trim().toIntOrNull()
        if (quantity == null) {
            message = "數量須為整數。"
            return
        }
        if (quantity < 1) {
            message = "數量須為 1 或以上。"
            return
        }
        val numberArr = form.cardNumberText.toCharArray()
        val expiryArr = form.expiryText.toCharArray()
        try {
            if (!CardValidator.validateCardNumber(numberArr).ok) {
                message = "卡號格式唔正確。"
                return
            }
            val cal = Calendar.getInstance()
            val expiryResult = CardValidator.validateExpiry(
                expiryArr,
                cal.get(Calendar.YEAR) % 100,
                cal.get(Calendar.MONTH) + 1,
            )
            if (!expiryResult.ok) {
                message = "到期日格式唔正確（MMYY，須為將來日期）。"
                return
            }
            fun blankToNull(text: String): String? = text.trim().ifEmpty { null }
            val input = ProfileInput(
                name = form.name,
                product = ProductGroup(
                    model = form.model,
                    colour = form.colour,
                    capacity = form.capacity,
                    quantity = quantity,
                    appleCare = form.appleCare,
                    tradeIn = form.tradeIn,
                ),
                pickup = PickupGroup(
                    method = form.method,
                    storePriority = form.storePriorityText.lines()
                        .map { it.trim() }.filter { it.isNotEmpty() },
                    slotPreference = blankToNull(form.slotPreference),
                    pickupName = blankToNull(form.pickupName),
                    pickupPhone = blankToNull(form.pickupPhone),
                    pickupEmail = blankToNull(form.pickupEmail),
                    deliveryAddress = blankToNull(form.deliveryAddress),
                ),
                cardNumber = numberArr,
                expiry = expiryArr,
            )
            when (val outcome = repository.updateProfile(profileId, input)) {
                is SaveOutcome.Saved -> onSaved()
                SaveOutcome.EncryptionFailed ->
                    message = "儲存失敗：加密唔到，已停止。原組合無被修改。"
                SaveOutcome.StorageWriteFailed -> {
                    // D-67: re-list before reporting. The
                    // list shows name + last 4 only, so it
                    // proves presence, not field contents.
                    val listed = try {
                        repository.listProfiles()
                    } catch (e: Exception) {
                        null
                    }
                    message = when {
                        listed == null ->
                            "儲存寫入狀態未能核實（重新列出都失敗），請稍後去組合管理再核實，唔好假設已儲存或未儲存。"
                        listed.any { it.id == profileId } ->
                            "儲存寫入狀態不明，但重新列出見到呢個組合仍在，請去組合管理核對內容是否已更新。"
                        else ->
                            "儲存寫入狀態不明，重新列出見唔到呢個組合，請去組合管理核實。"
                    }
                }
                is SaveOutcome.Blocked -> when (outcome.reason) {
                    SaveBlock.EMPTY_NAME -> message = "組合名唔可以空白。"
                    SaveBlock.DUPLICATE_NAME -> message = "已有同名組合，請改名。"
                    SaveBlock.NOT_FOUND -> onNotFoundOnSave()
                    SaveBlock.LIMIT_REACHED ->
                        message = "已達組合上限，未有儲存任何變更。"
                }
            }
        } finally {
            // The repository copies its inputs but does not
            // clear the caller's arrays; these are ours to zero.
            numberArr.fill('\u0000')
            expiryArr.fill('\u0000')
        }
    }

    Column(Modifier.padding(16.dp)) {
        Text("編輯組合")
        message?.let { Text(it) }
        EditField("組合名", form.name) { form.name = it }
        Text("產品組")
        EditField("型號", form.model) { form.model = it }
        EditField("顏色", form.colour) { form.colour = it }
        EditField("容量", form.capacity) { form.capacity = it }
        EditField("數量", form.quantityText) { form.quantityText = it }
        TriStateRow("AppleCare", form.appleCare) { form.appleCare = it }
        TriStateRow("換購", form.tradeIn) { form.tradeIn = it }
        Text("取貨組")
        MethodRow(form.method) { form.method = it }
        EditField("門店優先次序（一行一間）", form.storePriorityText, singleLine = false) {
            form.storePriorityText = it
        }
        EditField("時段偏好", form.slotPreference) { form.slotPreference = it }
        EditField("取貨人姓名", form.pickupName) { form.pickupName = it }
        EditField("取貨人電話", form.pickupPhone) { form.pickupPhone = it }
        EditField("取貨人電郵", form.pickupEmail) { form.pickupEmail = it }
        EditField("送貨地址", form.deliveryAddress) { form.deliveryAddress = it }
        Text("付款組")
        EditField("卡號", form.cardNumberText) { form.cardNumberText = it }
        EditField("到期日（MMYY）", form.expiryText) { form.expiryText = it }
        Text("CVV 唔會儲存（D-46），表單無 CVV 欄；每次執行時喺付款輸入頁補入。")
        Button(
            onClick = { save() },
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
        ) { Text("儲存變更") }
        Button(
            onClick = onCancel,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        ) { Text("取消") }
    }
}

@Composable
private fun EditField(
    label: String,
    value: String,
    singleLine: Boolean = true,
    onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
    )
}

/**
 * Pickup method as a constrained selector, not free text
 * (QA minor validation note, seq 5040). A stored value
 * outside the two known methods is kept as its own option
 * so saving never silently rewrites it.
 */
@Composable
private fun MethodRow(value: String, onChange: (String) -> Unit) {
    val options = listOf("pickup", "delivery") +
        (if (value == "pickup" || value == "delivery") {
            emptyList()
        } else {
            listOf(value)
        })
    Column(Modifier.padding(top = 8.dp)) {
        Text("方式：$value")
        Row {
            options.forEach { option ->
                TextButton(onClick = { onChange(option) }) { Text(option) }
            }
        }
    }
}

@Composable
private fun TriStateRow(
    label: String,
    value: Boolean?,
    onChange: (Boolean?) -> Unit,
) {
    Column(Modifier.padding(top = 8.dp)) {
        Text(
            "$label：" + when (value) {
                null -> "未設定"
                true -> "有"
                false -> "無"
            },
        )
        Row {
            TextButton(onClick = { onChange(null) }) { Text("未設定") }
            TextButton(onClick = { onChange(true) }) { Text("有") }
            TextButton(onClick = { onChange(false) }) { Text("無") }
        }
    }
}
