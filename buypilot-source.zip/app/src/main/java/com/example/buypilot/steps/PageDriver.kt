package com.example.buypilot.steps

/**
 * S1–S5 page logic — page-driver abstraction (shared by the
 * S1–S3 handlers in this directory and the S4–S5 handlers in
 * app-s4s5; the S4–S5 package extends, never duplicates, it).
 *
 * Design basis (master spec v1.2, ruling D-01): the app advances
 * by page state and UI-element detection from the official entry,
 * NOT by preset URLs and NOT by a checkout API. This interface is
 * therefore expressed in page states and logical element keys,
 * never in URLs, DOM selectors, or API endpoints:
 * - [PageState] is what the page IS (entry / product / bag /
 *   queue / blocked / loading), as detected from its UI.
 * - Element keys such as "ENTRY_CONTINUE" are LOGICAL names.
 *   A future real WebView driver will map each key to the actual
 *   UI element it detects on the live page; this package invents
 *   no DOM selector and no Apple page structure. A fixture driver
 *   maps the same keys to its offline page model.
 * - [PageModel.configuredProductKey] is the product the page
 *   currently shows as configured (null if none), and
 *   [PageModel.bagQuantity] is the quantity the bag page reports
 *   (null if not on a bag page). Both are page facts, not
 *   parameters the handler guesses.
 *
 * A handler calls [snapshot] once per decision, performs at most
 * ONE click per execute() call, and re-reads the snapshot after
 * that click. It never loops, never auto-retries in a loop, and
 * never advances on a stale snapshot: after WAITING or STOPPED
 * the machine resumes with needsRevalidation = true, and the
 * handler re-reads the snapshot and re-checks every condition
 * (including already-configured / already-in-bag idempotence)
 * before advancing or clicking again.
 */
enum class PageState {
    LOADING,
    ENTRY,
    PRODUCT,
    BAG,
    CHECKOUT,
    FULFILLMENT,
    PAYMENT,
    SUBMIT_CONFIRM,
    RESULT,
    QUEUE_OR_MAINTENANCE,
    BLOCKED_541,
    CAPTCHA,
    ERROR,
    UNKNOWN,
}

/** Result as reported by the result page (S9). */
enum class ResultStatus {
    SUCCESS,
    DECLINED,
    UNKNOWN,
    PENDING,
}

/** One UI element as detected: how many, clickable, displayed text. */
data class ElementInfo(
    val count: Int,
    val clickable: Boolean,
    val text: String? = null,
)

/**
 * One payment field as detected on the payment page (S7):
 * how many matching fields, and whether the field lives in
 * the page's main frame (D-16/D-17: only main-frame fields
 * are fillable by WebView script). Field identity is a CODE
 * only (PaymentFields), never a value.
 */
data class PaymentFieldFact(
    val fieldCode: String,
    val count: Int,
    val inMainFrame: Boolean,
)

/** One store/slot option as reported by the page (S5). */
data class StoreOption(
    val storeKey: String,
    val slotAvailable: Boolean,
)

data class PageModel(
    val pageState: PageState,
    val elements: Map<String, ElementInfo> = emptyMap(),
    val soldOut: Boolean = false,
    val configuredProductKey: String? = null,
    val bagQuantity: Int? = null,
    /** Product the bag page reports (S3 exception (2) fix). */
    val bagProductKey: String? = null,
    /** Store/slot options as reported on the checkout page (S5). */
    val storeOptions: List<StoreOption> = emptyList(),
    /** Store currently selected on a fulfillment page (S5). */
    val selectedStoreKey: String? = null,
    /** Page reports the fulfillment data was rejected (S5, E14). */
    val fulfillmentDataRejected: Boolean = false,
    /** Summary facts as reported on a submit-confirm page (S8). */
    val summaryProductKey: String? = null,
    val summaryTotalText: String? = null,
    val summaryPickupText: String? = null,
    /** Result as reported on a result page (S9, null = not reported). */
    val resultStatus: ResultStatus? = null,
    /** Payment fields as detected on a payment page (S7). */
    val paymentFields: List<PaymentFieldFact> = emptyList(),
)

/**
 * Payment field CODES (the page fields' autocomplete codes,
 * master D-16 3-field scope). Codes only — a code identifies
 * a field, it is never a value.
 */
object PaymentFields {
    const val NUMBER = "cc-number"
    const val EXPIRY = "cc-exp"
    const val CVV = "cc-csc"
    val REQUIRED: List<String> = listOf(NUMBER, EXPIRY, CVV)
}

interface PageDriver {
    fun snapshot(): PageModel
    fun click(elementId: String): Boolean

    /**
     * S5 addition: select a fulfillment store by key. The default
     * is false (not selectable) so drivers written before S5
     * still compile; the fixture driver and any real driver
     * override it. The handler, not the driver, chooses which
     * store key to pass, from the user's priority list.
     */
    fun selectStore(storeKey: String): Boolean = false

    /**
     * S7 addition: fill one payment field, identified by its
     * field CODE, with the given value. The value is borrowed
     * for this call only — a driver must use it to fill the
     * field and must never store, log or return it. Returns
     * true only if the field was actually filled. The default
     * is false (not fillable) so drivers written before S7
     * still compile and fail safe.
     */
    fun fillPaymentField(fieldCode: String, value: CharArray): Boolean = false

    /**
     * S7 addition: read back the current text of one payment
     * field for the E16 comparison, or null if the field
     * cannot be read. The returned text is for comparison
     * inside the handler only; it must never be logged or
     * included in any evidence file.
     */
    fun paymentFieldReadBack(fieldCode: String): String? = null
}

/** Logical element keys (not DOM selectors, not URLs). */
object PageElements {
    const val ENTRY_CONTINUE = "ENTRY_CONTINUE"
    const val PRODUCT_NAVIGATE = "PRODUCT_NAVIGATE"
    const val PRODUCT_SELECT = "PRODUCT_SELECT"
    const val PRICE = "PRICE"
    const val ADD_TO_BAG = "ADD_TO_BAG"
    const val CHECKOUT_BUTTON = "CHECKOUT_BUTTON"
    const val STORE_SELECT = "STORE_SELECT"
}

/**
 * Offline fixture driver for JVM tests. It holds a page model
 * that tests can replace outright ([setModel]) to simulate a
 * page change (e.g. queue clearing, a click landing), and an
 * optional click-effect map: clicking a key replaces the model
 * with the mapped model. Clicks are counted so tests can prove
 * a handler did NOT click in a stop condition (E09/E10).
 * This driver never touches a real page and never loads a URL.
 */
class FakePageDriver(
    initial: PageModel,
    private val clickEffects: Map<String, PageModel> = emptyMap(),
    private val selectEffects: Map<String, PageModel> = emptyMap(),
    private val fillRefusals: Set<String> = emptySet(),
    private val readBackOverrides: Map<String, String?> = emptyMap(),
) : PageDriver {
    var current: PageModel = initial
        private set

    private val clicks = mutableMapOf<String, Int>()
    private val selects = mutableMapOf<String, Int>()
    private val fills = mutableMapOf<String, Int>()

    /**
     * Fixture-only store of what was "filled" into each field,
     * so a read-back returns it. Test values only, held in
     * memory for the test run, never printed or logged.
     */
    private val fieldStore = mutableMapOf<String, String>()

    fun setModel(model: PageModel) {
        current = model
    }

    fun clickCount(elementId: String): Int = clicks[elementId] ?: 0
    fun selectCount(storeKey: String): Int = selects[storeKey] ?: 0
    fun fillCount(fieldCode: String): Int = fills[fieldCode] ?: 0

    override fun fillPaymentField(fieldCode: String, value: CharArray): Boolean {
        fills[fieldCode] = fillCount(fieldCode) + 1
        if (fieldCode in fillRefusals) return false
        val fact = current.paymentFields.firstOrNull { it.fieldCode == fieldCode }
        if (fact == null || fact.count == 0 || !fact.inMainFrame) return false
        fieldStore[fieldCode] = String(value)
        return true
    }

    override fun paymentFieldReadBack(fieldCode: String): String? {
        if (readBackOverrides.containsKey(fieldCode)) return readBackOverrides[fieldCode]
        return fieldStore[fieldCode]
    }

    override fun snapshot(): PageModel = current

    override fun click(elementId: String): Boolean {
        clicks[elementId] = clickCount(elementId) + 1
        val effect = clickEffects[elementId]
        if (effect != null) {
            current = effect
            return true
        }
        // No scripted effect: report clickability, change nothing.
        // The handler then sees an unchanged page and must Pause
        // (E08) rather than click again in a loop.
        return current.elements[elementId]?.clickable ?: false
    }

    override fun selectStore(storeKey: String): Boolean {
        selects[storeKey] = selectCount(storeKey) + 1
        val effect = selectEffects[storeKey]
        if (effect != null) {
            current = effect
            return true
        }
        val available = current.storeOptions.any {
            it.storeKey == storeKey && it.slotAvailable
        }
        if (!available) return false
        current = current.copy(
            selectedStoreKey = storeKey,
            pageState = PageState.FULFILLMENT,
        )
        return true
    }
}
