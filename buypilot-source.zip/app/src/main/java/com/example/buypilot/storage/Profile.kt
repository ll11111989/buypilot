package com.example.buypilot.storage

/**
 * 資料組合儲存組件 — 資料模型（D-45 設計、D-46 至 D-50 已定明規則）。
 *
 * 付款組儲存欄位只有卡號／到期日，無 CVV 欄位（D-46）。
 * CVV 只喺每次執行由 S6 補輸入入 RAM 工作副本，唔存入庫。
 */

// 產品組。appleCare / tradeIn 屬提案欄位：現行 S1–S5 handler 資料模型未有對應，
// 實作只儲存，明文標為「存而未用」，唔可以引用為 handler 已支援。
data class ProductGroup(
    val model: String,
    val colour: String,
    val capacity: String,
    val quantity: Int,
    val appleCare: Boolean? = null, // STORED_NOT_USED
    val tradeIn: Boolean? = null    // STORED_NOT_USED
)

data class PickupGroup(
    val method: String, // "pickup" 或 "delivery"，由頁面實際選項決定
    val storePriority: List<String> = emptyList(),
    val slotPreference: String? = null,
    val pickupName: String? = null,
    val pickupPhone: String? = null,
    val pickupEmail: String? = null,
    val deliveryAddress: String? = null
)

// 用戶明確儲存時先會建立嘅輸入。注意：無 cvv 欄位（D-46）。
data class ProfileInput(
    val name: String,
    val product: ProductGroup,
    val pickup: PickupGroup,
    val cardNumber: CharArray, // 儲存前即加密，唔好長期持有
    val expiry: CharArray      // MMYY 字串，保留前導零
)

// 儲存層記錄：卡資料只以密文形式存在，另存末 4 位僅供遮蔽顯示（D-45）。
data class StoredProfile(
    val id: String,
    val name: String, // 已 trim 後嘅原名（顯示用）；唯一性比較用 lowercase()＋trim
    val product: ProductGroup,
    val pickup: PickupGroup,
    val encryptedCardNumber: ByteArray,
    val encryptedExpiry: ByteArray,
    val cardLast4: String
)

// 列表遮蔽摘要：只出組合名＋末 4（D-45）。
data class ProfileSummary(val id: String, val name: String, val cardLast4: String)

// RAM 工作副本：由儲存層＋S6 補輸入 CVV 具體化。finally／close 即清零。
// 清工作副本 ≠ 刪已儲存組合（D-43 分層）。
class WorkingCopy(
    val cardNumber: CharArray,
    val expiry: CharArray,
    val cvv: CharArray
) : AutoCloseable {
    fun clear() {
        cardNumber.fill('\u0000')
        expiry.fill('\u0000')
        cvv.fill('\u0000')
    }
    override fun close() = clear()
}

/**
 * 管理畫面編輯用完整讀取結果（D-57 方案 A）：
 * 同 WorkingCopy 區分 — 呢個係編輯填表用，唔係執行用；
 * 無 CVV（D-46：CVV 從未入庫，讀取介面唔會亦唔應該有 CVV）。
 * 卡號／到期日係 RAM 解密陣列：讀出後只可用喺編輯畫面填表，
 * 儲存／取消／離開編輯後要 clear() 清零，唔可以長留表單狀態。
 * 更新經 updateProfile 明確儲存，本物件唔會自動寫返。
 */
class EditableProfile(
    val id: String,
    val name: String,
    val product: ProductGroup,
    val pickup: PickupGroup,
    val cardNumber: CharArray,
    val expiry: CharArray
) : AutoCloseable {
    fun clear() {
        cardNumber.fill('\u0000')
        expiry.fill('\u0000')
    }
    override fun close() = clear()
}
