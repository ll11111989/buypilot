package com.example.buypilot.flow

import android.os.Looper
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.buypilot.steps.ElementInfo
import com.example.buypilot.steps.PageDriver
import com.example.buypilot.steps.PageElements
import com.example.buypilot.steps.PageModel
import com.example.buypilot.steps.PageState
import com.example.buypilot.steps.PaymentFieldFact
import com.example.buypilot.steps.PaymentFields
import com.example.buypilot.steps.ResultStatus
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import org.json.JSONArray
import org.json.JSONObject

/**
 * Real WebView page driver (Android only, UNCOMPILED here and
 * UNVERIFIED against any real page — the real-page probe is
 * parked and E15 is undecided; nothing in this file claims
 * the mappings below match a live store page).
 *
 * Route discipline (D-01): the driver NEVER navigates — it
 * loads no URL, presets no route, and calls no checkout API.
 * It only observes and acts on the page the WebView is
 * already showing, by page state and UI elements, exactly
 * the abstraction the handlers were written against.
 *
 * How facts are obtained:
 * - A JS probe reads the main document: visible clickable
 *   elements' texts, input fields' autocomplete attributes,
 *   iframe count, body text, CAPTCHA markers. Payment fields
 *   are identified by their standard autocomplete codes
 *   (cc-number / cc-exp / cc-csc, the D-16 codes) in the MAIN
 *   document only; fields living only inside iframes are
 *   reported as absent, which stops S7 safely (E05) rather
 *   than guessing.
 * - Logical element keys are matched against clickable
 *   element texts using [DriverLabels] — generic commerce
 *   labels, explicitly heuristic and unverified.
 * - Facts that cannot be derived generically (configured
 *   product key, bag contents, store option keys, summary
 *   product/pickup texts) are returned as null / empty, so
 *   handlers stop safely (Pause) instead of proceeding on
 *   invented data. Deriving them needs the real page's
 *   structure, which only a real-page verification may
 *   supply.
 * - HTTP 541 on the main frame is tracked via
 *   [webViewClient] (install it on the WebView) and maps to
 *   BLOCKED_541 (E03).
 *
 * Threading: PageDriver is synchronous; WebView evaluation
 * is not. eval() posts to the WebView's thread and waits on
 * a latch, so flow execution MUST run on a background
 * thread (the host does this). Called on the main thread,
 * eval() refuses to block and snapshot() returns the last
 * probed model (or LOADING before the first probe).
 *
 * Card values pass through fill/readBack only; nothing is
 * logged, stored, or included in any model or evidence.
 */
class WebViewPageDriver(
    private val webView: WebView,
    private val labels: DriverLabels = DriverLabels.defaults(),
) : PageDriver {

    @Volatile
    private var lastHttpErrorCode: Int? = null

    @Volatile
    private var lastModel: PageModel = PageModel(pageState = PageState.LOADING)

    /** Install on the WebView so 541 responses are tracked. */
    val webViewClient: WebViewClient = object : WebViewClient() {
        override fun onReceivedHttpError(
            view: WebView?,
            request: WebResourceRequest?,
            errorResponse: WebResourceResponse?,
        ) {
            if (request?.isForMainFrame == true) {
                lastHttpErrorCode = errorResponse?.statusCode
            }
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
            lastHttpErrorCode = null
        }
    }

    override fun snapshot(): PageModel {
        val raw = eval(PROBE_SCRIPT) ?: return lastModel
        val model = try {
            mapProbe(JSONObject(raw))
        } catch (e: Exception) {
            return lastModel
        }
        lastModel = model
        return model
    }

    override fun click(elementId: String): Boolean {
        val labelSet = labels.forKey(elementId) ?: return false
        val script = clickScript(labelSet, null)
        return eval(script) == "true"
    }

    override fun selectStore(storeKey: String): Boolean {
        // A store option is identified by its visible key
        // text; the option list itself is page-owned.
        val script = clickScript(emptyList(), storeKey)
        return eval(script) == "true"
    }

    override fun fillPaymentField(fieldCode: String, value: CharArray): Boolean {
        val literal = JSONObject.quote(String(value))
        val script = """
            (function(){
              var el = document.querySelector('input[autocomplete="$fieldCode"]');
              if (!el) return false;
              var setter = Object.getOwnPropertyDescriptor(
                window.HTMLInputElement.prototype, 'value').set;
              setter.call(el, $literal);
              el.dispatchEvent(new Event('input', {bubbles: true}));
              el.dispatchEvent(new Event('change', {bubbles: true}));
              return true;
            })()
        """.trimIndent()
        return eval(script) == "true"
    }

    override fun paymentFieldReadBack(fieldCode: String): String? {
        val script = """
            (function(){
              var el = document.querySelector('input[autocomplete="$fieldCode"]');
              return el ? el.value : null;
            })()
        """.trimIndent()
        val raw = eval(script) ?: return null
        if (raw == "null") return null
        return try {
            JSONObject("{v:$raw}").getString("v")
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- internals ----------------

    private fun eval(script: String): String? {
        if (Looper.myLooper() == Looper.getMainLooper()) return null
        val latch = CountDownLatch(1)
        var out: String? = null
        webView.post {
            try {
                webView.evaluateJavascript(script) { result ->
                    out = result
                    latch.countDown()
                }
            } catch (e: Exception) {
                latch.countDown()
            }
        }
        return if (latch.await(3, TimeUnit.SECONDS)) out else null
    }

    private fun clickScript(labelSet: List<String>, containsText: String?): String {
        val labelsJson = JSONArray(labelSet).toString()
        val containsJson = containsText?.let { JSONObject.quote(it) } ?: "null"
        return """
            (function(){
              var labels = $labelsJson;
              var contains = $containsJson;
              var els = document.querySelectorAll(
                'button, a, [role="button"], input[type="button"], input[type="submit"]');
              for (var i = 0; i < els.length; i++) {
                var e = els[i];
                if (!(e.offsetWidth || e.offsetHeight)) continue;
                var t = (e.innerText || e.value ||
                  e.getAttribute('aria-label') || '').trim();
                if (contains !== null) {
                  if (t.indexOf(contains) >= 0) { e.click(); return true; }
                } else if (labels.indexOf(t) >= 0) { e.click(); return true; }
              }
              return false;
            })()
        """.trimIndent()
    }

    private fun mapProbe(root: JSONObject): PageModel {
        if (lastHttpErrorCode == 541) {
            return PageModel(pageState = PageState.BLOCKED_541)
        }
        if (root.optBoolean("captcha")) {
            return PageModel(pageState = PageState.CAPTCHA)
        }
        val clickables = mutableListOf<String>()
        val arr = root.optJSONArray("clickables")
        if (arr != null) {
            for (i in 0 until arr.length()) clickables.add(arr.optString(i))
        }
        val elements = mutableMapOf<String, ElementInfo>()
        fun put(key: String, labelSet: Set<String>) {
            val count = clickables.count { it in labelSet }
            if (count > 0) elements[key] = ElementInfo(count, true)
        }
        put(PageElements.ENTRY_CONTINUE, labels.entryContinue)
        put(PageElements.PRODUCT_NAVIGATE, labels.productNavigate)
        put(PageElements.PRODUCT_SELECT, labels.productSelect)
        put(PageElements.ADD_TO_BAG, labels.addToBag)
        put(PageElements.CHECKOUT_BUTTON, labels.checkoutButton)
        put(PageElements.STORE_SELECT, labels.storeSelect)
        put(FlowElements.SUBMIT_BUTTON, labels.submitButton)

        val text = root.optString("text")
        val priceText = PRICE_PATTERN.find(text)?.value
        if (priceText != null) {
            elements[PageElements.PRICE] = ElementInfo(1, true, priceText)
        }

        val fieldsObj = root.optJSONObject("fields")
        val paymentFields = PaymentFields.REQUIRED.mapNotNull { code ->
            val count = fieldsObj?.optInt(code, 0) ?: 0
            if (count > 0) PaymentFieldFact(code, count, true) else null
        }

        val successMarker = SUCCESS_MARKERS.any { text.contains(it) }
        val declineMarker = DECLINE_MARKERS.any { text.contains(it) }
        val state: PageState
        val resultStatus: ResultStatus?
        when {
            paymentFields.isNotEmpty() -> {
                state = PageState.PAYMENT
                resultStatus = null
            }
            successMarker || declineMarker -> {
                state = PageState.RESULT
                resultStatus = if (declineMarker) {
                    ResultStatus.DECLINED
                } else {
                    ResultStatus.SUCCESS
                }
            }
            elements.containsKey(FlowElements.SUBMIT_BUTTON) -> {
                state = PageState.SUBMIT_CONFIRM
                resultStatus = null
            }
            elements.containsKey(PageElements.CHECKOUT_BUTTON) -> {
                state = PageState.BAG
                resultStatus = null
            }
            elements.containsKey(PageElements.ADD_TO_BAG) -> {
                state = PageState.PRODUCT
                resultStatus = null
            }
            elements.containsKey(PageElements.ENTRY_CONTINUE) -> {
                state = PageState.ENTRY
                resultStatus = null
            }
            else -> {
                state = PageState.UNKNOWN
                resultStatus = null
            }
        }
        return PageModel(
            pageState = state,
            elements = elements,
            paymentFields = paymentFields,
            resultStatus = resultStatus,
            summaryTotalText = if (state == PageState.SUBMIT_CONFIRM) priceText else null,
            // Not derivable generically — null so handlers stop
            // safely rather than proceed on invented data:
            // configuredProductKey, bagProductKey, bagQuantity,
            // storeOptions, selectedStoreKey, summaryProductKey,
            // summaryPickupText all stay at their defaults.
        )
    }

    companion object {
        private val PRICE_PATTERN = Regex("(HK\\$|\\$|¥|€)\\s?[0-9][0-9,]*")
        private val SUCCESS_MARKERS = listOf(
            "Thank you", "Order placed", "訂單已提交", "多謝你嘅訂單",
        )
        private val DECLINE_MARKERS = listOf(
            "was declined", "付款被拒", "交易被拒",
        )

        private const val PROBE_SCRIPT = """
            (function(){
              function vis(e){ return !!(e.offsetWidth || e.offsetHeight); }
              var clickables = [];
              document.querySelectorAll(
                'button, a, [role="button"], input[type="button"], input[type="submit"]'
              ).forEach(function(e){
                if (vis(e)) clickables.push(
                  (e.innerText || e.value || e.getAttribute('aria-label') || '').trim());
              });
              var fields = {};
              document.querySelectorAll('input').forEach(function(e){
                var ac = e.getAttribute('autocomplete');
                if (ac) fields[ac] = (fields[ac] || 0) + 1;
              });
              var html = document.documentElement.innerHTML;
              return {
                clickables: clickables,
                fields: fields,
                iframes: document.querySelectorAll('iframe').length,
                text: (document.body ? document.body.innerText : '').slice(0, 4000),
                captcha: /captcha/i.test(html.slice(0, 200000))
              };
            })()
        """
    }
}

/**
 * Label sets mapping logical element keys to clickable
 * element texts. Generic commerce wording only — heuristic
 * and UNVERIFIED against any real page.
 */
class DriverLabels(
    val entryContinue: Set<String>,
    val productNavigate: Set<String>,
    val productSelect: Set<String>,
    val addToBag: Set<String>,
    val checkoutButton: Set<String>,
    val storeSelect: Set<String>,
    val submitButton: Set<String>,
) {
    fun forKey(elementId: String): List<String>? = when (elementId) {
        PageElements.ENTRY_CONTINUE -> entryContinue.toList()
        PageElements.PRODUCT_NAVIGATE -> productNavigate.toList()
        PageElements.PRODUCT_SELECT -> productSelect.toList()
        PageElements.ADD_TO_BAG -> addToBag.toList()
        PageElements.CHECKOUT_BUTTON -> checkoutButton.toList()
        PageElements.STORE_SELECT -> storeSelect.toList()
        FlowElements.SUBMIT_BUTTON -> submitButton.toList()
        else -> null
    }

    companion object {
        fun defaults() = DriverLabels(
            entryContinue = setOf("Continue", "繼續"),
            productNavigate = setOf("Buy", "購買", "立即購買", "Pre-order", "預訂"),
            productSelect = setOf("Select", "選擇"),
            addToBag = setOf("Add to Bag", "加入購物袋", "加入購物籃"),
            checkoutButton = setOf("Check Out", "Checkout", "結帳", "結賬"),
            storeSelect = setOf("Select Store", "選擇門市", "選擇店舖"),
            submitButton = setOf("Place Order", "下訂單", "提交訂單"),
        )
    }
}
