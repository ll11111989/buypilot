package com.example.buypilot.steps

import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.StepHandler
import com.example.buypilot.state.StepOutcome

/**
 * S3 ADD_TO_BAG — add the S2-configured product to the bag,
 * never adding a different product.
 *
 * Safety check before any click: the page must show the same
 * product S2 configured ([productKey]). If the configured key
 * is missing or different, the handler Pauses (E08) instead of
 * adding whatever happens to be on the page. This configured
 * precondition is the step's own guard, not a bag check.
 *
 * D-27 alignment (D-64 handler alignment package): bag
 * identity (E08) and quantity (E11) are NOT verified —
 * already in bag advances directly, and after the click the
 * step advances once the page reports BAG, without checking
 * which product the bag reports or how many it reports.
 * The pre-click sold-out check (E09) is NOT in the D-64
 * void list and is retained, as are the page-state checks.
 *
 * Outcome mapping (this package's mapping, for QA to check):
 * - sold out -> Pause (E09), before any click.
 * - already in bag -> Advance, no click (idempotent: resume
 *   after WAITING/STOPPED never re-adds). Bag identity and
 *   quantity are not verified (D-27).
 * - page state not PRODUCT (and not already BAG) -> Pause (E08).
 * - add element missing -> Pause (E05); duplicate -> Pause
 *   (E07); not clickable / click false -> Pause (E06).
 * - after click: global page state is re-checked first
 *   (queue/blocked/loading, QA exception (1) fix); page not
 *   BAG -> Pause (E11, add failed). Bag product and quantity
 *   are not verified after the click either (D-27).
 * - queue -> Wait (E02); 541 -> Block (E03); CAPTCHA -> Block
 *   (E04); ERROR/UNKNOWN -> Pause (E08).
 */
class S3AddToBagHandler(
    private val driver: PageDriver,
    private val productKey: String,
    private val addElementId: String = PageElements.ADD_TO_BAG,
) : StepHandler {

    init {
        require(productKey.isNotBlank()) { "S3 productKey must be supplied, not inferred" }
    }

    override fun execute(snapshot: MachineSnapshot): StepOutcome {
        StepChecks.timeCheck(snapshot)?.let { return it }
        var model = driver.snapshot()
        StepChecks.globalPageCheck(model)?.let { return it }

        if (model.pageState == PageState.ERROR || model.pageState == PageState.UNKNOWN) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        if (model.soldOut) {
            return StepOutcome.Pause(reason = "SOLD_OUT", errorId = "E09")
        }

        // Already in bag: advance directly, never re-add.
        // D-27: bag identity and quantity are NOT verified.
        if (model.pageState == PageState.BAG) {
            return StepOutcome.Advance
        }
        if (model.pageState != PageState.PRODUCT) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }

        // Never add a product S2 did not configure.
        if (model.configuredProductKey != productKey) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }

        StepChecks.requireUnique(addElementId, model)?.let { return it }
        StepChecks.requireClickable(addElementId, model)?.let { return it }
        if (!driver.click(addElementId)) {
            return StepOutcome.Pause(reason = "ELEMENT_NOT_CLICKABLE", errorId = "E06")
        }
        model = driver.snapshot()
        StepChecks.afterClickLoading(model)?.let { return it }
        if (model.pageState != PageState.BAG) {
            return StepOutcome.Pause(reason = "ADD_TO_BAG_FAILED", errorId = "E11")
        }
        // D-27: bag product and quantity are NOT verified here.
        return StepOutcome.Advance
    }
}
