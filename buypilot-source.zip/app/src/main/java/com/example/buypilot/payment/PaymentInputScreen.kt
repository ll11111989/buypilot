package com.example.buypilot.payment

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.buypilot.integration.SaveS6Outcome
import com.example.buypilot.storage.ProfileRepository
import com.example.buypilot.storage.WorkingCopy
import kotlinx.coroutines.delay
import java.util.Calendar

/**
 * S6 PAYMENT_INPUT — formal input interface (ruling D-16 scope).
 *
 * Exactly 3 fields — card number / expiry (MM/YY) / CVV.
 * Cardholder name is NOT collected: D-16 fixed the real-page required
 * scope at these 3 fields, and a non-existent field must never be
 * treated as "unverified".
 *
 * Data handling:
 * - A field's text lives in Compose state only while it is being
 *   typed (unavoidable for a text field). On commit it is validated
 *   as a CharArray, copied into [CardSession] (the only holder),
 *   and the Compose state is cleared immediately; the row then shows
 *   only a masked status (number: last 4; expiry/CVV: "set"), never
 *   the value.
 * - Nothing is persisted, logged, screenshotted (host Activity sets
 *   FLAG_SECURE) or placed on the clipboard by this code.
 * - App background (ON_STOP) clears the session immediately
 *   (APP_BACKGROUND trigger); the flow layer maps a cleared S6
 *   session to CANCELLED per the v1.1 global rules.
 * - S7 PAYMENT_FILL is NOT implemented here. [onReady] only reports
 *   "input complete"; what may consume the session is decided by the
 *   flow layer under Kenneth's unlock ruling.
 *
 * Optional explicit-save wiring (D-47, app-integration package):
 * when [onSaveProfile] is supplied, a "儲存為組合" button appears.
 * It is the ONLY save call point: tapping it shows the D-50
 * Keystore warning first (only when [isFirstSave] reports the
 * store is empty), then a name-confirm dialog, and only the
 * confirm tap calls [onSaveProfile] with the confirmed name.
 * The host implements that callback with S6ProfileSave (which
 * pre-checks, borrows once, saves, and materializes the current
 * run's WorkingCopy); on Saved the host continues the run via
 * [onSavedWithWorkingCopy], which also receives the S6
 * session's already-elapsed clocks (absolute + idle, D-54)
 * so the S7 stored path keeps the D-19 cap running from
 * the original S6 begin. The screen never closes that copy
 * itself (the S7 stored path closes it in finally). A
 * pre-check failure leaves the session intact; the other
 * outcomes are reported as text, exactly as S6ProfileSave
 * documents them.
 */
@Composable
fun PaymentInputScreen(
    session: CardSession,
    onReady: () -> Unit,
    onCancel: () -> Unit,
    onSessionCleared: (CardSession.ClearTrigger) -> Unit,
    onSaveProfile: ((String) -> SaveS6Outcome)? = null,
    isFirstSave: () -> Boolean = { false },
    onSavedWithWorkingCopy: ((WorkingCopy, Long, Long) -> Unit)? = null,
) {
    var tick by remember { mutableStateOf(0) } // recomposition pulse
    var clearedNotice by remember { mutableStateOf<CardSession.ClearTrigger?>(null) }
    var showSaveWarning by remember { mutableStateOf(false) }
    var showSaveNameDialog by remember { mutableStateOf(false) }
    var saveName by remember { mutableStateOf("") }
    var saveMessage by remember { mutableStateOf<String?>(null) }

    // Timeout watcher: idle 120 s / absolute 5 min from S6 entry.
    LaunchedEffect(session) {
        session.begin()
        while (session.isActive) {
            delay(1_000)
            session.checkTimeout()?.let {
                clearedNotice = session.lastClearTrigger
                tick++
            }
            tick++
        }
    }

    // Background = clear immediately (master baseline trigger).
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, session) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && session.isActive) {
                session.clear(CardSession.ClearTrigger.APP_BACKGROUND)
                clearedNotice = CardSession.ClearTrigger.APP_BACKGROUND
                tick++
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(Modifier.padding(16.dp)) {
        Text("輸入付款資料")
        @Suppress("UNUSED_EXPRESSION") tick // state read to recompose on session change

        clearedNotice?.let {
            Text("資料已清除（原因：${it.name}），請重新輸入或取消。")
        }

        CardFieldRow(
            label = "信用卡/扣帳卡號碼",
            field = CardValidator.Field.CARD_NUMBER,
            session = session,
            keyboardType = KeyboardType.Number,
            mask = { "•••• ${it.takeLast(4)}" },
            validate = { CardValidator.validateCardNumber(it) },
            onSessionChanged = { tick++ },
        )
        CardFieldRow(
            label = "到期日 MM/YY",
            field = CardValidator.Field.EXPIRY,
            session = session,
            keyboardType = KeyboardType.Number,
            mask = { "••/••" },
            validate = {
                val cal = Calendar.getInstance()
                CardValidator.validateExpiry(
                    it,
                    nowYear2 = cal.get(Calendar.YEAR) % 100,
                    nowMonth = cal.get(Calendar.MONTH) + 1,
                )
            },
            onSessionChanged = { tick++ },
        )
        CardFieldRow(
            label = "CVV",
            field = CardValidator.Field.CVV,
            session = session,
            keyboardType = KeyboardType.NumberPassword,
            mask = { "•••" },
            visualMask = true,
            validate = { CardValidator.validateCvv(it) },
            onSessionChanged = { tick++ },
        )

        Button(
            onClick = onReady,
            enabled = session.isActive && session.hasAllFields(),
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
        ) { Text("完成輸入") }

        if (onSaveProfile != null) {
            Button(
                onClick = {
                    if (isFirstSave()) showSaveWarning = true
                    else showSaveNameDialog = true
                },
                enabled = session.isActive && session.hasAllFields(),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            ) { Text("儲存為組合") }
        }
        saveMessage?.let { Text(it) }

        Button(
            onClick = {
                session.clear(CardSession.ClearTrigger.CANCEL)
                onSessionCleared(CardSession.ClearTrigger.CANCEL)
                onCancel()
            },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        ) { Text("取消") }
    }

    if (showSaveWarning) {
        AlertDialog(
            onDismissRequest = { showSaveWarning = false },
            confirmButton = {
                TextButton(onClick = {
                    showSaveWarning = false
                    showSaveNameDialog = true
                }) { Text("我明白，繼續") }
            },
            dismissButton = {
                TextButton(onClick = { showSaveWarning = false }) { Text("取消") }
            },
            title = { Text("儲存前請注意") },
            text = { Text(ProfileRepository.KEYSTORE_WARNING_TEXT) },
        )
    }
    if (showSaveNameDialog && onSaveProfile != null) {
        AlertDialog(
            onDismissRequest = { showSaveNameDialog = false },
            confirmButton = {
                TextButton(onClick = {
                    val outcome = onSaveProfile(saveName)
                    saveMessage = when (outcome) {
                        is SaveS6Outcome.Saved -> {
                            onSavedWithWorkingCopy?.invoke(
                                outcome.copy,
                                outcome.absoluteElapsedMs,
                                outcome.idleElapsedMs,
                            )
                            "已儲存為組合。"
                        }
                        is SaveS6Outcome.PrecheckBlocked ->
                            "未能儲存：${outcome.reason.name}，可改名再試（原本輸入未受影響）。"
                        SaveS6Outcome.SessionNotReady -> "輸入未完成，請先完成 3 欄輸入。"
                        SaveS6Outcome.SaveBlockedAfterBorrow ->
                            "儲存未完成，今次輸入已結束，請重新輸入。"
                        SaveS6Outcome.MaterializeFailedAfterBorrow ->
                            "組合已儲存，但今次執行未能載入，請重新開始。"
                        SaveS6Outcome.EncryptionFailedAfterBorrow ->
                            "儲存失敗：加密唔到，未有儲存任何組合，今次輸入已結束，請重新輸入。"
                        SaveS6Outcome.StorageWriteFailedAfterBorrow ->
                            "儲存寫入失敗，經重新列出核實未有儲存呢個組合，今次輸入已結束，請重新輸入。"
                        SaveS6Outcome.StorageWriteUnverifiableAfterBorrow ->
                            "儲存寫入狀態未能核實，請去組合管理重新列出核實，唔好假設已儲存或未儲存。"
                        SaveS6Outcome.PrecheckReadFailed ->
                            "讀取已存組合失敗，未有進行儲存，可再試（原本輸入未受影響）。"
                        SaveS6Outcome.SaveReadFailedAfterBorrow ->
                            "讀取已存組合失敗，未有進行儲存，今次輸入已結束，請重新輸入。"
                    }
                    saveName = ""
                    showSaveNameDialog = false
                    tick++
                }) { Text("儲存") }
            },
            dismissButton = {
                TextButton(onClick = {
                    saveName = ""
                    showSaveNameDialog = false
                }) { Text("取消") }
            },
            title = { Text("儲存為組合") },
            text = {
                OutlinedTextField(
                    value = saveName,
                    onValueChange = { saveName = it },
                    label = { Text("組合名") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
        )
    }
}

@Composable
private fun CardFieldRow(
    label: String,
    field: CardValidator.Field,
    session: CardSession,
    keyboardType: KeyboardType,
    mask: (String) -> String,
    visualMask: Boolean = false,
    validate: (CharArray) -> CardValidator.Result,
    onSessionChanged: () -> Unit,
) {
    var text by remember(field) { mutableStateOf("") }
    var error by remember(field) { mutableStateOf<CardValidator.Error?>(null) }
    var committedMask by remember(field) { mutableStateOf<String?>(null) }

    Column(Modifier.padding(top = 12.dp)) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text(label) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            visualTransformation = if (visualMask) {
                PasswordVisualTransformation()
            } else {
                androidx.compose.ui.text.input.VisualTransformation.None
            },
            modifier = Modifier.fillMaxWidth(),
        )
        error?.let { Text("格式不正確：${it.name}") }
        committedMask?.let { Text("已輸入：$it") }
        Button(
            onClick = {
                val result = validate(text.toCharArray())
                if (result.ok) {
                    session.put(field, text.toCharArray())
                    committedMask = mask(text)
                    text = "" // UI copy dropped; CardSession is the only holder
                    error = null
                } else {
                    error = result.error
                }
                onSessionChanged()
            },
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
        ) { Text("確認此欄") }
    }
}
