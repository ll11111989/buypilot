package com.example.buypilot.state

/**
 * P2 state-machine core — global states, master spec v1.2.
 *
 * Meanings (from the master spec, not redefined here):
 * - RUNNING: a step handler may run.
 * - WAITING (E02 queue/maintenance): halted; resume returns to the
 *   step it left and re-validates that step. If a submit was already
 *   dispatched, WAITING never applies — the outcome is UNKNOWN.
 * - BLOCKED (E03 541 / E04 CAPTCHA): halted, never bypassed. P2
 *   provides NO resume API for BLOCKED; only a fresh run
 *   (resetForNewRun) may start again after human intervention
 *   outside the machine.
 * - STOPPED: paused by a human or by a step pause; resumable to the
 *   same step with re-validation.
 * - CANCELLED: final, before submit dispatch (includes E23
 *   cancel / app background before dispatch).
 * - DECLINED: final, E19 explicit refusal, no retry.
 * - FAILED: terminated, not resumable.
 * - UNKNOWN: final for this run, submit dispatched but result
 *   unknown; never auto-resubmitted.
 *
 * Terminal states are CANCELLED, DECLINED, FAILED and UNKNOWN.
 * Before the first start() the machine has no global state yet
 * (null), which is displayed as "not started" — it is not a new
 * global state and must not be reported as one.
 */
enum class GlobalState {
    RUNNING, WAITING, BLOCKED, STOPPED, CANCELLED, DECLINED, FAILED, UNKNOWN;

    val isTerminal: Boolean
        get() = this == CANCELLED || this == DECLINED ||
            this == FAILED || this == UNKNOWN
}
