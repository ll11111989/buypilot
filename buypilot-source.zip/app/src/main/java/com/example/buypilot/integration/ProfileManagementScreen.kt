package com.example.buypilot.integration

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.buypilot.storage.DeleteOutcome
import com.example.buypilot.storage.ProfileRepository
import com.example.buypilot.storage.ProfileSummary

/**
 * Combination management screen (D-45 / D-47 / D-50 wiring).
 *
 * What this screen does:
 * - Lists stored combinations as name + last 4 only, from
 *   repository.listProfiles(). The LIST never displays full
 *   card data; full data appears only inside the edit
 *   screen (D-57, see below), under the same FLAG_SECURE
 *   host window. Nothing here is logged or placed on the
 *   clipboard.
 * - Deletes a WHOLE combination only, on the user's explicit
 *   confirm tap (deleteProfile). There is no field-level
 *   delete (D-45 reservation) and no automatic delete of
 *   any kind (D-35).
 * - Delete result handling (D-73/D-74/D-76): the confirm
 *   tap branches explicitly on DeleteOutcome — Deleted
 *   refreshes the list and reports success; WriteFailed
 *   maps to STOPPED-style handling and MUST re-list
 *   (listProfiles) before anything is reported, with the
 *   report decided by verifyDeleteAfterWriteFailure
 *   (clean delete vs still present vs store file loss vs
 *   unverifiable). No exception propagates raw from the
 *   onClick: an unexpected throw from the delete call is
 *   treated as WriteFailed, and a throwing re-list is
 *   reported as unverifiable. The dialog state
 *   (pendingDelete) is cleared in EVERY branch, and the
 *   success message appears only after verification — the
 *   list refreshes from the re-list result, never from an
 *   assumption. Deleting a nonexistent id stays a silent
 *   no-op (D-76): it reports Deleted from the repository
 *   and VerifiedDeleted here, never NOT_FOUND.
 * - Shows the D-50 Keystore warning text PERMANENTLY at the
 *   top, using the single constant from the repository
 *   (KEYSTORE_WARNING_TEXT) so the first-save popup and
 *   this permanent text can never drift apart.
 *
 * Edit (D-57 Option A, full read): each row also offers an
 * explicit 編輯 button opening ProfileEditScreen, which
 * reads the stored data via loadForEdit, prefills a
 * form, and saves through updateProfile. The list itself
 * still shows masked summaries only — the full read happens
 * only inside the edit screen, under this host's
 * FLAG_SECURE window. See ProfileEditScreen for the
 * NOT_FOUND, decryption-failure and buffer-clearing rules.
 * This screen itself still never calls saveProfile.
 */
@Composable
fun ProfileManagementScreen(
    repository: ProfileRepository,
    onClose: () -> Unit,
) {
    var profiles by remember { mutableStateOf(repository.listProfiles()) }
    var pendingDelete by remember { mutableStateOf<ProfileSummary?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var editingId by remember { mutableStateOf<String?>(null) }

    editingId?.let { id ->
        ProfileEditScreen(
            repository = repository,
            profileId = id,
            onDone = { resultMessage ->
                if (resultMessage != null) message = resultMessage
                profiles = repository.listProfiles()
                editingId = null
            },
        )
        return
    }

    Column(Modifier.padding(16.dp)) {
        Text("已儲存組合")
        Text(ProfileRepository.KEYSTORE_WARNING_TEXT)
        message?.let { Text(it) }
        for (profile in profiles) {
            Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                Text("${profile.name} •••• ${profile.cardLast4}")
                Button(
                    onClick = { editingId = profile.id },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                ) { Text("編輯") }
                Button(
                    onClick = { pendingDelete = profile },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                ) { Text("刪除成個組合") }
            }
        }
        if (profiles.isEmpty()) {
            Text("未有已儲存組合。")
        }
        Button(
            onClick = onClose,
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
        ) { Text("返回") }
    }

    pendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            confirmButton = {
                TextButton(onClick = {
                    val beforeCount = profiles.size
                    // The repository call itself no longer
                    // throws for IO failures (WriteFailed),
                    // but an unexpected throw must still not
                    // escape the onClick with no defined
                    // result: treat it as WriteFailed.
                    val outcome = try {
                        repository.deleteProfile(target.id)
                    } catch (e: Exception) {
                        DeleteOutcome.WriteFailed
                    }
                    when (outcome) {
                        DeleteOutcome.Deleted -> {
                            // The delete succeeded (saveAll
                            // returned OK); refresh the list
                            // for display. A throwing refresh
                            // does not un-delete anything,
                            // but it must be reported, not
                            // swallowed into a success claim
                            // about the list.
                            try {
                                profiles = repository.listProfiles()
                                message = "已刪除組合。"
                            } catch (e: Exception) {
                                message =
                                    "已刪除組合，但列表未能重新載入，請返回後再入。"
                            }
                            pendingDelete = null
                        }
                        DeleteOutcome.WriteFailed -> {
                            // D-74: re-list before reporting
                            // anything. The listing result —
                            // not the failed outcome — decides
                            // the message, and the list
                            // refreshes from it (except on
                            // loss / unverifiable, where the
                            // stale list must NOT be replaced
                            // by an empty or assumed state).
                            val listed = try {
                                repository.listProfiles()
                            } catch (e: Exception) {
                                null
                            }
                            when (
                                verifyDeleteAfterWriteFailure(
                                    target.id,
                                    beforeCount,
                                    listed,
                                )
                            ) {
                                DeleteVerification.VerifiedDeleted -> {
                                    profiles = listed!!
                                    message =
                                        "組合已不存在（刪除寫入曾失敗，但重新列出核實目標已無）。"
                                }
                                DeleteVerification.StillPresent -> {
                                    profiles = listed!!
                                    message = "刪除失敗，組合仍在，請再試。"
                                }
                                DeleteVerification.StoreFileLost -> {
                                    message =
                                        "刪除寫入失敗，重新列出發現成個儲存檔已遺失，唔可以確認刪除結果，請停止並檢查儲存狀態。"
                                }
                                DeleteVerification.Unverifiable -> {
                                    message =
                                        "刪除寫入失敗，重新列出都失敗，未能核實刪除結果，唔好假設已刪除或未刪除。"
                                }
                            }
                            pendingDelete = null
                        }
                    }
                }) { Text("確認刪除") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("取消") }
            },
            title = { Text("刪除成個組合？") },
            text = { Text("將刪除「${target.name}」成個組合，此操作無法復原。") },
        )
    }
}
