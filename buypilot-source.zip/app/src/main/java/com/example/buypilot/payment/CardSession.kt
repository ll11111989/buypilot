package com.example.buypilot.payment

/**
 * S6 PAYMENT_INPUT — card data lifecycle (master spec v1.2 baseline).
 *
 * Rules implemented here:
 * - Card data lives ONLY in this object's RAM buffers (CharArray).
 *   Never persisted, never logged, never copied to the clipboard,
 *   never included in screenshots (the hosting Activity sets
 *   FLAG_SECURE) and never converted to long-lived Strings.
 * - Timeout is counted from entering S6 (session begin):
 *   idle 120 s (reset ONLY by input activity) / absolute cap 5 min
 *   (never reset). Both are adjustable constants (Config).
 * - Clear (zero-fill + reference drop) triggers follow the master
 *   baseline; the list is NOT exhaustive (ruling D-12), so the enum
 *   is extendable and [clear] accepts any trigger:
 *   cancel, timeout, app background, fill failure, submit completed /
 *   declined / result unknown, session end.
 * - A fill attempt consumes the session: [withCardData] clears the
 *   buffers when the attempt ends, success or failure (S7 rule —
 *   card data is zeroed at the end of the S7 fill attempt, not held
 *   until S8; see E16 final, Water correction 3).
 * - Stored-path clock carry-over (D-54 follow-up): a session
 *   created for the stored path must NOT restart the D-19
 *   clocks. [absoluteElapsedMs] / [idleElapsedMs] report how
 *   much of each clock the S6 session has already consumed,
 *   and [beginWithElapsed] starts a new session with those
 *   amounts already elapsed, so the absolute 5-minute cap
 *   keeps running from the original S6 begin. A fresh clock
 *   on the stored path does NOT comply with D-19 (D-54
 *   supplementary ruling) and must not be used.
 *
 * This class has no Android dependencies so its lifecycle and timeout
 * logic can be unit-tested on the JVM. It performs NO page filling —
 * S7 PAYMENT_FILL is not implemented and remains locked until
 * Kenneth unlocks it after the S6 real-page test passes.
 */
class CardSession(
    private val clock: () -> Long = System::currentTimeMillis,
    private val config: Config = Config(),
) {
    data class Config(
        val idleTimeoutMs: Long = 120_000L,      // adjustable constant
        val absoluteTimeoutMs: Long = 300_000L,  // adjustable constant
    )

    enum class ClearTrigger {
        CANCEL, TIMEOUT_IDLE, TIMEOUT_ABSOLUTE, APP_BACKGROUND,
        FILL_FAILURE, SUBMIT_COMPLETED, SUBMIT_DECLINED, SUBMIT_UNKNOWN,
        SESSION_ENDED, OTHER // D-12: trigger list is not exhaustive
    }

    enum class TimeoutKind { IDLE, ABSOLUTE }

    private val buffers = mutableMapOf<CardValidator.Field, CharArray>()
    private var beganAtMs: Long = 0L
    private var lastActivityMs: Long = 0L

    var isActive: Boolean = false
        private set
    var lastClearTrigger: ClearTrigger? = null
        private set

    /** Entering S6 starts both timeout clocks. No data exists before this. */
    fun begin() {
        clearInternal(ClearTrigger.SESSION_ENDED) // drop any stale buffers
        val now = clock()
        beganAtMs = now
        lastActivityMs = now
        isActive = true
        lastClearTrigger = null
    }

    /**
     * Milliseconds of the absolute clock already consumed.
     * Zero before begin. NOTE (QA minor note): after the
     * session ends, the begin timestamps are retained, so
     * these two readers keep reporting time since the
     * ORIGINAL begin — stale values, not a live reading.
     * Callers needing the elapsed amounts (the D-54
     * carry-over) must read them while the session is still
     * active, before the borrow that ends it; S6ProfileSave
     * does exactly this.
     */
    fun absoluteElapsedMs(): Long =
        if (beganAtMs == 0L) 0L else maxOf(0L, clock() - beganAtMs)

    /** Milliseconds of the idle clock already consumed. See [absoluteElapsedMs] for the after-end staleness note. */
    fun idleElapsedMs(): Long =
        if (beganAtMs == 0L) 0L else maxOf(0L, clock() - lastActivityMs)

    /**
     * Begin with already-elapsed time carried over (D-54):
     * the new session's clocks start as if begin() had
     * happened [absoluteElapsedMs] / [idleElapsedMs] ago, so
     * the D-19 absolute cap keeps running from the original
     * S6 entry instead of restarting. Both values must be
     * non-negative. Stale buffers are dropped first, exactly
     * as begin() does.
     */
    fun beginWithElapsed(absoluteElapsedMs: Long, idleElapsedMs: Long) {
        require(absoluteElapsedMs >= 0 && idleElapsedMs >= 0) {
            "elapsed time must be non-negative"
        }
        clearInternal(ClearTrigger.SESSION_ENDED)
        val now = clock()
        beganAtMs = now - absoluteElapsedMs
        lastActivityMs = now - idleElapsedMs
        isActive = true
        lastClearTrigger = null
    }

    /** Store a field value (copied into a fresh zeroable buffer). */
    fun put(field: CardValidator.Field, value: CharArray) {
        check(isActive) { "CardSession not active" }
        if (checkTimeout() != null) return // timed out: session already cleared
        buffers.remove(field)?.fill('\u0000')
        buffers[field] = value.copyOf()
        lastActivityMs = clock() // input activity resets idle only
    }

    /**
     * Seed one buffer for stored-path construction (D-54).
     * Unlike put(), this does NOT check the timeout and does
     * NOT move the idle clock: the carried clocks set by
     * beginWithElapsed must stay exactly as set, so the S7
     * handler — not construction — reports a carried
     * timeout, and the idle carry-over is not silently
     * reset by the seeding puts. Only the stored-path
     * wiring uses this; user input always goes through
     * put(), which checks the timeout and moves the clock.
     */
    fun seed(field: CardValidator.Field, value: CharArray) {
        check(isActive) { "CardSession not active" }
        buffers.remove(field)?.fill('\u0000')
        buffers[field] = value.copyOf()
    }

    fun hasAllFields(): Boolean =
        isActive && CardValidator.Field.entries.all { buffers.containsKey(it) }

    /**
     * Copy out ONE buffered field, or null if absent / inactive.
     * The caller owns the copy and must zero it after use.
     * This exists for the stored-path S6 step (flow layer):
     * the session holds only the CVV top-up there, so
     * withCardData (which requires all three fields, being a
     * fill-attempt contract) cannot lend it. It is not a
     * general read API for card data.
     */
    fun copyField(field: CardValidator.Field): CharArray? =
        if (isActive) buffers[field]?.copyOf() else null

    /**
     * Returns the timeout kind if the session has expired, clearing the
     * buffers as a side effect; null while still within both limits.
     */
    fun checkTimeout(): TimeoutKind? {
        if (!isActive) return null
        val now = clock()
        return when {
            now - beganAtMs > config.absoluteTimeoutMs -> {
                clearInternal(ClearTrigger.TIMEOUT_ABSOLUTE); TimeoutKind.ABSOLUTE
            }
            now - lastActivityMs > config.idleTimeoutMs -> {
                clearInternal(ClearTrigger.TIMEOUT_IDLE); TimeoutKind.IDLE
            }
            else -> null
        }
    }

    /**
     * Lends the buffers to ONE fill attempt and guarantees clearing
     * when the attempt ends (S7 lifecycle rule). This is the contract
     * S7 will consume; S7 itself is not implemented here.
     */
    fun <T> withCardData(block: (Map<CardValidator.Field, CharArray>) -> T): T {
        check(isActive && hasAllFields()) { "CardSession not ready" }
        try {
            return block(buffers)
        } finally {
            clearInternal(ClearTrigger.SESSION_ENDED)
        }
    }

    /** Zero every buffer and end the session. Idempotent. */
    fun clear(trigger: ClearTrigger) = clearInternal(trigger)

    private fun clearInternal(trigger: ClearTrigger) {
        buffers.values.forEach { it.fill('\u0000') }
        buffers.clear()
        isActive = false
        lastClearTrigger = trigger
    }

    /** Redacted by construction: never expose buffer contents. */
    override fun toString(): String =
        "CardSession(active=$isActive, fields=${buffers.keys.map { it.name }})"
}
