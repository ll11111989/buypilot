package com.example.buypilot.integration

import com.example.buypilot.storage.ProfileSummary

/**
 * Delete verification after a failed delete (D-74, D-67
 * analogy) — pure logic, no Android dependency, so it is
 * unit-testable on the JVM; the management screen calls it
 * from the delete confirmation dialog.
 *
 * The caller MUST re-list (listProfiles) after a
 * DeleteOutcome.WriteFailed and report only per the
 * listing result — never from the failed outcome alone,
 * and never from an assumption:
 *
 * - [VerifiedDeleted]: the target is absent from the
 *   re-list. This covers both "actually deleted" and
 *   "was not there" (D-76 keeps deleting a nonexistent id
 *   a silent no-op, so the two are indistinguishable and
 *   both are clean). It also covers the last-combination
 *   case: an empty re-list with beforeCount == 1 means
 *   the only combination is gone, which is the expected
 *   result, not a loss.
 * - [StillPresent]: the target is still listed — the
 *   delete did not take (the usual WriteFailed outcome:
 *   the old file is intact). Report failure, never success.
 * - [StoreFileLost]: the re-list is EMPTY although other
 *   combinations should still exist (beforeCount > 1).
 *   This is the backend's rename-failure shape: the first
 *   rename fails, the old file is deleted, the retry
 *   fails, and the whole store file is gone — a missing
 *   file reads back as an empty list. It must NEVER be
 *   reported as a successful delete; it is STOPPED.
 * - [Unverifiable]: the re-list itself failed (the caller
 *   passes null). Also STOPPED: report that the result
 *   cannot be verified, and do not assume deleted or not.
 *
 * beforeCount is the combination count BEFORE the delete
 * attempt (the list the dialog was opened from, target
 * included). The single-threaded UI flow is assumed: no
 * concurrent deleter changes the count between the dialog
 * and the re-list.
 */
sealed class DeleteVerification {
    object VerifiedDeleted : DeleteVerification()
    object StillPresent : DeleteVerification()
    object StoreFileLost : DeleteVerification()
    object Unverifiable : DeleteVerification()
}

fun verifyDeleteAfterWriteFailure(
    targetId: String,
    beforeCount: Int,
    listed: List<ProfileSummary>?,
): DeleteVerification {
    if (listed == null) return DeleteVerification.Unverifiable
    if (listed.any { it.id == targetId }) {
        return DeleteVerification.StillPresent
    }
    if (listed.isEmpty() && beforeCount > 1) {
        return DeleteVerification.StoreFileLost
    }
    return DeleteVerification.VerifiedDeleted
}
