package com.example.buypilot.payment

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * S6 CVV top-up screen (stored path only, D-46).
 *
 * The stored path never persisted the CVV, so each run the
 * user re-enters ONLY the CVV here, into the same CardSession
 * the flow's FlowS6Handler reads. No card number / expiry
 * fields exist on this screen — the stored combination
 * supplies them at materialize time. The full 3-field
 * PaymentInputScreen is the manual path and is unchanged.
 *
 * Same hygiene as PaymentInputScreen: FLAG_SECURE is the
 * host window's job; the entered text lives only in this
 * composable's state and the session's RAM buffer; nothing
 * is logged. The session clocks (D-19) start at begin() when
 * the screen first appears, exactly as the manual path.
 *
 * onReady is called after the CVV has been put into the
 * session and locally validated; the host then resumes the
 * flow.
 */
@Composable
fun CvvTopUpScreen(
    session: CardSession,
    onReady: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var cvvText by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }
    var timedOut by remember { mutableStateOf<CardSession.TimeoutKind?>(null) }

    LaunchedEffect(session) {
        if (!session.isActive) session.begin()
        while (true) {
            delay(500)
            val kind = session.checkTimeout()
            if (kind != null) {
                timedOut = kind
                break
            }
            if (!session.isActive) break
        }
    }

    Column(modifier = modifier.padding(16.dp)) {
        Text(
            text = "輸入 CVV（已選組合）",
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "CVV 從未儲存（安全規則），每次執行要重新輸入一次。" +
                "卡號同到期日會由已選組合載入，唔使再入。",
        )
        Spacer(modifier = Modifier.height(16.dp))

        val timeout = timedOut
        if (timeout != null) {
            Text(
                text = if (timeout == CardSession.TimeoutKind.IDLE) {
                    "已閒置太耐，輸入已清除，請重新開始。"
                } else {
                    "已超過時限，輸入已清除，請重新開始。"
                },
                color = MaterialTheme.colorScheme.error,
            )
            return@Column
        }

        OutlinedTextField(
            value = cvvText,
            onValueChange = { new ->
                cvvText = new.filter { it.isDigit() }.take(4)
                errorText = null
            },
            label = { Text("CVV") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        )
        errorText?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                val kind = session.checkTimeout()
                if (kind != null) {
                    timedOut = kind
                    return@Button
                }
                val value = cvvText.toCharArray()
                val result = CardValidator.validateCvv(value)
                if (!result.ok) {
                    value.fill('\u0000')
                    errorText = "CVV 格式唔啱，請檢查後再試。"
                    return@Button
                }
                try {
                    session.put(CardValidator.Field.CVV, value)
                } finally {
                    value.fill('\u0000')
                }
                cvvText = ""
                onReady()
            },
            enabled = cvvText.isNotEmpty(),
        ) {
            Text("完成")
        }
    }
}
