package com.example.buypilot.flow

import com.example.buypilot.integration.executeS7WithStoredCopy
import com.example.buypilot.payment.CardSession
import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.StepHandler
import com.example.buypilot.state.StepOutcome
import com.example.buypilot.steps.PageDriver
import com.example.buypilot.steps.S7PaymentFillHandler

/**
 * S7 PAYMENT_FILL dispatcher (flow layer) — the two paths,
 * plus the D-63 / D-44 retry counting.
 *
 * MANUAL path: delegates to the accepted S7 handler with
 * the S6 CardSession.
 *
 * STORED path: delegates to executeS7WithStoredCopy with
 * the working copy + S6 elapsed clocks kept in the flow
 * state (D-54). That helper closes the copy in finally on
 * EVERY outcome, so one materialization fuels exactly one
 * fill attempt.
 *
 * Retry counting (D-63): the flow layer counts fill
 * attempts — at most 3 in one S7 sequence (first + 2
 * retries). The counter increments only when an attempt
 * actually runs with data available. When no data is
 * available (a previous attempt consumed it), the handler
 * returns Pause(S7_DATA_CONSUMED) — retained as the
 * single-attempt end state — and the host supplies fresh
 * data (stored: re-materialize + CVV top-up via
 * supplyStoredRetryCvv; manual: S6 re-input) before
 * triggering the next execute, which counts as the next
 * attempt. When the counter is already at 3, a further
 * execute with data returns Pause(S7_RETRY_LIMIT_EXCEEDED)
 * WITHOUT consuming the data (the run ends; the host
 * cleans up). E16 read-back mismatch is a hard stop in
 * the S7 handler itself and is never retried — this
 * counter does not override it.
 *
 * Both paths report E16-unreadable fields into the flow
 * state for the S8 provider (D-36).
 */
class FlowS7Handler(
    private val driver: PageDriver,
    private val session: CardSession,
    private val state: FlowRuntimeState,
) : StepHandler {

    private val manualHandler = S7PaymentFillHandler(driver, session) { codes ->
        state.unverifiedFieldCodes = codes
    }

    override fun execute(snapshot: MachineSnapshot): StepOutcome {
        // Stored path is taken when a combination was
        // selected for the run OR when the host stashed a
        // button-saved copy (D-54 continuation: the save
        // button's onSavedWithWorkingCopy carries copy +
        // clocks but no id, so copy presence is the signal
        // for that case).
        val storedPath = state.selectedProfileId != null ||
            state.storedWorkingCopy != null
        if (!storedPath) {
            if (!session.isActive || !session.hasAllFields()) {
                return StepOutcome.Pause(reason = "S7_DATA_CONSUMED")
            }
            if (state.s7Attempts >= 3) {
                return StepOutcome.Pause(reason = "S7_RETRY_LIMIT_EXCEEDED")
            }
            state.s7Attempts++
            return manualHandler.execute(snapshot)
        }
        val copy = state.storedWorkingCopy
            ?: return StepOutcome.Pause(reason = "S7_DATA_CONSUMED")
        if (state.s7Attempts >= 3) {
            // Limit reached: the copy is NOT consumed here —
            // it stays in state for host cleanup.
            return StepOutcome.Pause(reason = "S7_RETRY_LIMIT_EXCEEDED")
        }
        state.storedWorkingCopy = null
        state.s7Attempts++
        return executeS7WithStoredCopy(
            driver = driver,
            copy = copy,
            snapshot = snapshot,
            absoluteElapsedMs = state.storedAbsoluteElapsedMs,
            idleElapsedMs = state.storedIdleElapsedMs,
            onUnverifiedFields = { codes -> state.unverifiedFieldCodes = codes },
        )
    }
}
