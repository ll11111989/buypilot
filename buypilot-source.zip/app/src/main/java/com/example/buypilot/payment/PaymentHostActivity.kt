package com.example.buypilot.payment

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.buypilot.integration.FileProfileBackend
import com.example.buypilot.integration.createS6SaveCallbacks
import com.example.buypilot.integration.s6HostConfigFromIntent
import com.example.buypilot.storage.AndroidKeystoreCrypto
import com.example.buypilot.storage.ProfileRepository
import com.example.buypilot.storage.WorkingCopy
import java.util.UUID

/**
 * Host for the S6 PAYMENT_INPUT screen.
 *
 * FLAG_SECURE is set for the whole window while card input is shown:
 * blocks screenshots and blanks the recents preview, per the master
 * baseline (card data is never screenshotted or left in task previews).
 * Background clearing itself is handled inside PaymentInputScreen via
 * the lifecycle observer (ON_STOP -> CardSession.clear(APP_BACKGROUND)).
 *
 * S6 save host wiring (D-54 follow-up (b)): the repository is
 * built here, in the App module, and the run configuration
 * (product/pickup groups) arrives as Intent extras from the flow
 * layer that launches this Activity (see S6HostIntent). When a
 * run config is present, the three save callbacks are built by
 * the S6SaveCallbacks factory and passed to the screen, so the
 * "儲存為組合" button is enabled end to end instead of staying
 * hidden behind a null callback. When no run config is present,
 * the callbacks stay null and the button stays hidden — the
 * host never invents product/pickup groups to make it appear.
 *
 * On Saved, the WorkingCopy plus the S6 elapsed clocks are kept
 * in [savedForFlow] until the flow layer takes them with
 * [consumeSavedCopy] for the S7 stored path (single consumer).
 * If the Activity is destroyed before they are consumed, the
 * copy is closed here so no buffers are left uncleared.
 */
class PaymentHostActivity : ComponentActivity() {

    private val session = CardSession()
    private lateinit var repository: ProfileRepository
    private var savedCopy: WorkingCopy? = null
    private var savedAbsoluteElapsedMs: Long = 0L
    private var savedIdleElapsedMs: Long = 0L

    /**
     * Takes the saved WorkingCopy (plus S6 elapsed clocks) for
     * the S7 stored path. Single consumer: returns null on a
     * second call, and null when no save happened.
     */
    fun consumeSavedCopy(): Triple<WorkingCopy, Long, Long>? {
        val copy = savedCopy ?: return null
        savedCopy = null
        return Triple(copy, savedAbsoluteElapsedMs, savedIdleElapsedMs)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE,
        )
        repository = ProfileRepository(
            backend = FileProfileBackend(filesDir),
            crypto = AndroidKeystoreCrypto(),
            idGenerator = { UUID.randomUUID().toString() },
        )
        val config = s6HostConfigFromIntent(intent)
        val callbacks = config?.let {
            createS6SaveCallbacks(repository, it.product, it.pickup, session) { copy, abs, idle ->
                savedCopy = copy
                savedAbsoluteElapsedMs = abs
                savedIdleElapsedMs = idle
            }
        }
        setContent {
            PaymentInputScreen(
                session = session,
                onReady = {
                    // Input complete. This standalone S6 host owns
                    // no flow machine, so nothing further happens
                    // here; in the merged app the flow host
                    // (MainActivity) consumes the session at its
                    // S6 step via FlowS6Handler / FlowS7Handler,
                    // gated by the product S7 lock. A working copy
                    // saved during input, if any, is held for
                    // consumeSavedCopy().
                },
                onCancel = { finish() },
                onSessionCleared = { /* flow layer maps to CANCELLED */ },
                onSaveProfile = callbacks?.onSaveProfile,
                isFirstSave = callbacks?.isFirstSave ?: { false },
                onSavedWithWorkingCopy = callbacks?.onSavedWithWorkingCopy,
            )
        }
    }

    override fun onDestroy() {
        session.clear(CardSession.ClearTrigger.SESSION_ENDED)
        savedCopy?.close()
        savedCopy = null
        super.onDestroy()
    }
}
