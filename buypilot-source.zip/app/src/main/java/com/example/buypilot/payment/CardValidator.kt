package com.example.buypilot.payment

/**
 * S6 PAYMENT_INPUT — format validation for the 3 real-page required
 * fields fixed by ruling D-16: card number / expiry (MM/YY) / CVV.
 * Cardholder name is NOT a required field and is deliberately absent.
 *
 * Validation is format-only (never verifies the card is real).
 * Functions take CharArray so callers never need to create immutable
 * Strings of card data that would linger in the heap.
 */
object CardValidator {

    enum class Field { CARD_NUMBER, EXPIRY, CVV }
    enum class Error {
        EMPTY, NON_DIGIT, NUMBER_LENGTH, LUHN,
        EXPIRY_FORMAT, EXPIRY_MONTH, EXPIRY_PAST, CVV_LENGTH
    }

    data class Result(val field: Field, val error: Error?) {
        val ok: Boolean get() = error == null
    }

    /** Card number: digits only after stripping spaces/hyphens, 13–19, Luhn. */
    fun validateCardNumber(raw: CharArray): Result {
        if (raw.isEmpty()) return Result(Field.CARD_NUMBER, Error.EMPTY)
        var digits = 0
        var luhnSum = 0
        var doubleDigit = false
        // Walk from the end for Luhn; count digits and reject anything else.
        for (i in raw.indices.reversed()) {
            val c = raw[i]
            if (c == ' ' || c == '-') continue
            if (c !in '0'..'9') return Result(Field.CARD_NUMBER, Error.NON_DIGIT)
            var d = c - '0'
            if (doubleDigit) {
                d *= 2
                if (d > 9) d -= 9
            }
            luhnSum += d
            doubleDigit = !doubleDigit
            digits++
        }
        if (digits == 0) return Result(Field.CARD_NUMBER, Error.EMPTY)
        if (digits !in 13..19) return Result(Field.CARD_NUMBER, Error.NUMBER_LENGTH)
        if (luhnSum % 10 != 0) return Result(Field.CARD_NUMBER, Error.LUHN)
        return Result(Field.CARD_NUMBER, null)
    }

    /**
     * Expiry: MM/YY kept as a string/digits, never parsed into an Int
     * (leading zero is significant, Water correction 2 / E16).
     * [nowYear2] and [nowMonth] are injected so tests are deterministic.
     */
    fun validateExpiry(raw: CharArray, nowYear2: Int, nowMonth: Int): Result {
        // Accept "MM/YY" or "MMYY"; compare as digit strings.
        val digits = raw.filter { it in '0'..'9' }
        if (digits.isEmpty()) return Result(Field.EXPIRY, Error.EMPTY)
        if (digits.size != 4) return Result(Field.EXPIRY, Error.EXPIRY_FORMAT)
        val month = (digits[0] - '0') * 10 + (digits[1] - '0')
        val year2 = (digits[2] - '0') * 10 + (digits[3] - '0')
        if (month !in 1..12) return Result(Field.EXPIRY, Error.EXPIRY_MONTH)
        if (year2 < nowYear2 || (year2 == nowYear2 && month < nowMonth)) {
            return Result(Field.EXPIRY, Error.EXPIRY_PAST)
        }
        return Result(Field.EXPIRY, null)
    }

    /** CVV: 3–4 digits, nothing else. Never read back by value (E16). */
    fun validateCvv(raw: CharArray): Result {
        if (raw.isEmpty()) return Result(Field.CVV, Error.EMPTY)
        if (raw.any { it !in '0'..'9' }) return Result(Field.CVV, Error.NON_DIGIT)
        if (raw.size !in 3..4) return Result(Field.CVV, Error.CVV_LENGTH)
        return Result(Field.CVV, null)
    }
}
