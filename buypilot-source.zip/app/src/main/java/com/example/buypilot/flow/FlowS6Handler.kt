package com.example.buypilot.flow

import com.example.buypilot.payment.CardSession
import com.example.buypilot.payment.CardValidator
import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.StepHandler
import com.example.buypilot.state.StepOutcome
import com.example.buypilot.storage.MaterializeOutcome
import com.example.buypilot.storage.ProfileRepository

/**
 * S6 PAYMENT_INPUT step bridge (flow layer).
 *
 * S6 has no page handler — it is the user-input step. This
 * handler connects the CardSession the S6 UI writes to with
 * the machine:
 *
 * MANUAL path (no selected combination): Advance only when
 * the session is active and holds all 3 fields; the data
 * stays in the session for the S7 handler. Otherwise Pause
 * (the host shows the S6 screen; the user completes input
 * and the host resumes).
 *
 * STORED path (a combination was selected): the session
 * holds only the CVV top-up (D-46). When a CVV is present,
 * the handler reads the S6 elapsed clocks (D-54 carry-over),
 * materializes the stored combination with that CVV, keeps
 * the working copy + clocks in the flow state for S7, ends
 * the S6 session, and Advances. Decryption failure Pauses
 * as PROFILE_DECRYPTION_FAILED (the STOPPED mapping of
 * D-51: combination untouched); a combination deleted
 * after selection Pauses as PROFILE_NOT_FOUND — both are
 * explicit reasons, never a generic stop. On either failure
 * the session is left active (the user may retry or
 * cancel); on success the session is ended and the CVV
 * copy taken here is zeroed in finally (materializeForRun
 * copies the CVV into the working copy itself).
 *
 * BUTTON-SAVED path (host save button, D-47/D-54): when
 * the user saves the live input as a combination mid-S6,
 * the host's onSaved continuation already stashed the
 * materialized copy + clocks in state; this handler then
 * Advances on the stashed copy without touching the
 * (already ended) session. The same copy-presence signal
 * drives the S7 stored branch (see FlowS7Handler).
 */
class FlowS6Handler(
    private val session: CardSession,
    private val repository: ProfileRepository?,
    private val state: FlowRuntimeState,
) : StepHandler {

    override fun execute(snapshot: MachineSnapshot): StepOutcome {
        if (session.checkTimeout() != null) {
            return StepOutcome.Pause(reason = "CARD_SESSION_TIMEOUT")
        }
        // Button-saved during this S6 visit (D-54
        // continuation): the host already stashed the
        // materialized copy + S6 clocks in state when the
        // user tapped "儲存為組合" and the save succeeded.
        // S6 is satisfied — advance so S7 runs the stored
        // path from that copy. (The config-stored path
        // below materializes inside this same execute and
        // advances immediately, so a stashed copy at S6
        // entry can only come from the button.)
        if (state.storedWorkingCopy != null) {
            return StepOutcome.Advance
        }
        val profileId = state.selectedProfileId
        return if (profileId == null) {
            manual()
        } else {
            stored(profileId)
        }
    }

    private fun manual(): StepOutcome {
        return if (session.isActive && session.hasAllFields()) {
            StepOutcome.Advance
        } else {
            StepOutcome.Pause(reason = "S6_INPUT_INCOMPLETE")
        }
    }

    private fun stored(profileId: String): StepOutcome {
        val repo = repository
            ?: return StepOutcome.Pause(reason = "PROFILE_STORE_UNAVAILABLE")
        if (!session.isActive) {
            return StepOutcome.Pause(reason = "S6_INPUT_INCOMPLETE")
        }
        val cvv = session.copyField(CardValidator.Field.CVV)
            ?: return StepOutcome.Pause(reason = "S6_INPUT_INCOMPLETE")
        val absoluteElapsedMs = session.absoluteElapsedMs()
        val idleElapsedMs = session.idleElapsedMs()
        try {
            return when (val outcome = repo.materializeForRun(profileId, cvv)) {
                is MaterializeOutcome.Ok -> {
                    state.storedWorkingCopy = outcome.copy
                    state.storedAbsoluteElapsedMs = absoluteElapsedMs
                    state.storedIdleElapsedMs = idleElapsedMs
                    session.clear(CardSession.ClearTrigger.SESSION_ENDED)
                    StepOutcome.Advance
                }
                MaterializeOutcome.DecryptionFailed ->
                    StepOutcome.Pause(reason = "PROFILE_DECRYPTION_FAILED")
                MaterializeOutcome.NotFound ->
                    StepOutcome.Pause(reason = "PROFILE_NOT_FOUND")
            }
        } finally {
            cvv.fill('\u0000')
        }
    }
}
