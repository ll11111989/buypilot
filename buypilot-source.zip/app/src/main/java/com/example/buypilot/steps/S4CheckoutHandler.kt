package com.example.buypilot.steps

import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.StepHandler
import com.example.buypilot.state.StepOutcome

/**
 * S4 CHECKOUT — move from the bag page to the checkout page.
 *
 * Preconditions are re-checked on every execute, including
 * after WAITING/STOPPED resume (needsRevalidation): the bag
 * must still be the bag page, and if an expected bag product
 * was supplied it must still match the bag product the page
 * reports. A BAG page that does not report a bag product key
 * cannot be verified when a product was supplied, and Pauses
 * (E08) rather than checking out an unverified bag.
 *
 * Outcome mapping (this package's mapping, for QA to check;
 * no new E-number is invented):
 * - time over limit -> Pause (S1 time rule, via StepChecks).
 * - queue -> Wait (E02); 541 -> Block (E03); CAPTCHA -> Block
 *   (E04); loading -> Stay.
 * - sold out -> Pause (E09), before any click.
 * - already on CHECKOUT or FULFILLMENT -> Advance, no click
 *   (idempotent: resume never re-clicks checkout).
 * - page state not BAG (and not already past checkout) ->
 *   Pause (E08); ERROR/UNKNOWN -> Pause (E08).
 * - checkout button: duplicate -> Pause (E07); missing, not
 *   clickable, or click returns false -> Pause (E12,
 *   checkout button unavailable — E12 takes precedence over
 *   the generic E05/E06 for this specific button, per the
 *   work package; E07 uniqueness is kept distinct).
 * - after click: global page state is re-checked first
 *   (queue/blocked/loading, S1–S3 exception (1) fix);
 *   page not CHECKOUT/FULFILLMENT -> Pause (E08, click had
 *   no effect); otherwise Advance.
 *
 * S4 performs no fulfillment selection and no payment work:
 * store/slot handling is S5's package, S7 remains locked.
 */
class S4CheckoutHandler(
    private val driver: PageDriver,
    private val expectedBagProductKey: String? = null,
    private val checkoutElementId: String = PageElements.CHECKOUT_BUTTON,
) : StepHandler {

    override fun execute(snapshot: MachineSnapshot): StepOutcome {
        StepChecks.timeCheck(snapshot)?.let { return it }
        var model = driver.snapshot()
        StepChecks.globalPageCheck(model)?.let { return it }
        if (model.pageState == PageState.ERROR || model.pageState == PageState.UNKNOWN) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        if (model.soldOut) {
            return StepOutcome.Pause(reason = "SOLD_OUT", errorId = "E09")
        }

        // Already past checkout: advance, never re-click.
        if (model.pageState == PageState.CHECKOUT ||
            model.pageState == PageState.FULFILLMENT
        ) {
            return StepOutcome.Advance
        }
        if (model.pageState != PageState.BAG) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }

        // Bag identity, only when the caller supplied one.
        if (expectedBagProductKey != null &&
            model.bagProductKey != expectedBagProductKey
        ) {
            return StepOutcome.Pause(reason = "BAG_PRODUCT_MISMATCH", errorId = "E08")
        }

        val count = model.elements[checkoutElementId]?.count ?: 0
        if (count > 1) {
            return StepOutcome.Pause(reason = "ELEMENT_NOT_UNIQUE", errorId = "E07")
        }
        if (count == 0) {
            return StepOutcome.Pause(reason = "CHECKOUT_BUTTON_UNAVAILABLE", errorId = "E12")
        }
        if (model.elements[checkoutElementId]?.clickable != true) {
            return StepOutcome.Pause(reason = "CHECKOUT_BUTTON_UNAVAILABLE", errorId = "E12")
        }
        if (!driver.click(checkoutElementId)) {
            return StepOutcome.Pause(reason = "CHECKOUT_BUTTON_UNAVAILABLE", errorId = "E12")
        }
        model = driver.snapshot()
        StepChecks.afterClickLoading(model)?.let { return it }
        if (model.pageState != PageState.CHECKOUT &&
            model.pageState != PageState.FULFILLMENT
        ) {
            return StepOutcome.Pause(reason = "PAGE_STATE_MISMATCH", errorId = "E08")
        }
        return StepOutcome.Advance
    }
}
