package com.example.buypilot.steps

import com.example.buypilot.state.GlobalState
import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.PurchaseStep
import com.example.buypilot.state.StateMachine
import com.example.buypilot.state.StepOutcome

/**
 * JVM unit tests for the S4–S5 page handlers.
 *
 * Offline fixture only: every page state is scripted through
 * FakePageDriver, no real page is loaded, no URL is used, and
 * no card data of any kind appears in this file or its output
 * (S4–S5 handle no card data at all).
 * Run: kotlinc the P2 state core + the steps sources (S1–S3
 * and S4–S5) + this file, execute S4S5TestKt. Output prints
 * test names only.
 */
private var failures = 0
private fun check(name: String, cond: Boolean) {
    println((if (cond) "PASS " else "FAIL ") + name)
    if (!cond) failures++
}

private fun snap(
    step: PurchaseStep,
    needsRevalidation: Boolean = false,
): MachineSnapshot = MachineSnapshot(
    step = step,
    global = GlobalState.RUNNING,
    submitted = false,
    needsRevalidation = needsRevalidation,
    isComplete = false,
    s7Unlocked = false,
    timeCheck = null,
)

private fun el(count: Int, clickable: Boolean, text: String? = null) =
    ElementInfo(count = count, clickable = clickable, text = text)

private fun bagPage(
    productKey: String? = "TEST-PRODUCT",
    quantity: Int? = 1,
    checkoutCount: Int = 1,
    checkoutClickable: Boolean = true,
) = PageModel(
    pageState = PageState.BAG,
    elements = mapOf(PageElements.CHECKOUT_BUTTON to el(checkoutCount, checkoutClickable)),
    bagQuantity = quantity,
    bagProductKey = productKey,
)

private fun checkoutPage(
    options: List<StoreOption>,
    selectCount: Int = 1,
    selectClickable: Boolean = true,
) = PageModel(
    pageState = PageState.CHECKOUT,
    elements = mapOf(PageElements.STORE_SELECT to el(selectCount, selectClickable)),
    storeOptions = options,
)

private fun fulfillmentPage(selected: String?) = PageModel(
    pageState = PageState.FULFILLMENT,
    selectedStoreKey = selected,
)

private fun stateModel(state: PageState) = PageModel(pageState = state)

/** Driver whose selectStore always refuses, for the E13 test. */
private class RejectingSelectDriver(private val model: PageModel) : PageDriver {
    override fun snapshot(): PageModel = model
    override fun click(elementId: String): Boolean = true
    override fun selectStore(storeKey: String): Boolean = false
}

fun main() {
    // ---------- S4 ----------
    run {
        val driver = FakePageDriver(
            bagPage(),
            clickEffects = mapOf(PageElements.CHECKOUT_BUTTON to checkoutPage(emptyList())),
        )
        val out = S4CheckoutHandler(driver).execute(snap(PurchaseStep.S4_CHECKOUT))
        check("s4/bag-to-checkout-advance",
            out is StepOutcome.Advance &&
                driver.clickCount(PageElements.CHECKOUT_BUTTON) == 1)
    }
    run {
        val driver = FakePageDriver(checkoutPage(emptyList()))
        val out = S4CheckoutHandler(driver).execute(snap(PurchaseStep.S4_CHECKOUT, true))
        check("s4/already-checkout-advance-no-click",
            out is StepOutcome.Advance &&
                driver.clickCount(PageElements.CHECKOUT_BUTTON) == 0)
    }
    run {
        val driver = FakePageDriver(fulfillmentPage("STORE-B"))
        check("s4/already-fulfillment-advance",
            S4CheckoutHandler(driver).execute(snap(PurchaseStep.S4_CHECKOUT)) is StepOutcome.Advance)
    }
    run {
        val driver = FakePageDriver(bagPage(checkoutCount = 0))
        val out = S4CheckoutHandler(driver).execute(snap(PurchaseStep.S4_CHECKOUT))
        check("s4/button-missing-E12-no-click",
            out is StepOutcome.Pause && out.errorId == "E12" &&
                driver.clickCount(PageElements.CHECKOUT_BUTTON) == 0)
    }
    run {
        val driver = FakePageDriver(bagPage(checkoutClickable = false))
        val out = S4CheckoutHandler(driver).execute(snap(PurchaseStep.S4_CHECKOUT))
        check("s4/button-not-clickable-E12",
            out is StepOutcome.Pause && out.errorId == "E12")
    }
    run {
        val driver = FakePageDriver(bagPage(checkoutCount = 2))
        val out = S4CheckoutHandler(driver).execute(snap(PurchaseStep.S4_CHECKOUT))
        check("s4/button-duplicate-E07",
            out is StepOutcome.Pause && out.errorId == "E07")
    }
    run {
        // Click returns true with no effect: page stays BAG.
        val driver = FakePageDriver(bagPage())
        val out = S4CheckoutHandler(driver).execute(snap(PurchaseStep.S4_CHECKOUT))
        check("s4/click-no-effect-E08",
            out is StepOutcome.Pause && out.errorId == "E08")
    }
    run {
        val driver = FakePageDriver(
            bagPage(),
            clickEffects = mapOf(
                PageElements.CHECKOUT_BUTTON to stateModel(PageState.QUEUE_OR_MAINTENANCE),
            ),
        )
        val out = S4CheckoutHandler(driver).execute(snap(PurchaseStep.S4_CHECKOUT))
        check("s4/after-click-queue-wait-not-E08",
            out is StepOutcome.Wait && out.errorId == "E02")
    }
    run {
        val driver = FakePageDriver(bagPage(productKey = "OTHER-PRODUCT"))
        val out = S4CheckoutHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S4_CHECKOUT))
        check("s4/bag-wrong-product-E08-no-click",
            out is StepOutcome.Pause && out.errorId == "E08" &&
                driver.clickCount(PageElements.CHECKOUT_BUTTON) == 0)
    }
    run {
        val driver = FakePageDriver(bagPage(productKey = null))
        val out = S4CheckoutHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S4_CHECKOUT))
        check("s4/bag-product-unknown-E08",
            out is StepOutcome.Pause && out.errorId == "E08")
    }
    run {
        val driver = FakePageDriver(
            bagPage().copy(soldOut = true),
        )
        val out = S4CheckoutHandler(driver).execute(snap(PurchaseStep.S4_CHECKOUT))
        check("s4/sold-out-E09",
            out is StepOutcome.Pause && out.errorId == "E09")
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.PRODUCT))
        val out = S4CheckoutHandler(driver).execute(snap(PurchaseStep.S4_CHECKOUT))
        check("s4/wrong-state-E08",
            out is StepOutcome.Pause && out.errorId == "E08")
    }

    // ---------- S5 ----------
    val options = listOf(
        StoreOption("STORE-A", slotAvailable = false),
        StoreOption("STORE-B", slotAvailable = true),
        StoreOption("STORE-C", slotAvailable = true),
    )
    run {
        val driver = FakePageDriver(checkoutPage(options))
        val out = S5FulfillmentHandler(driver, listOf("STORE-A", "STORE-B", "STORE-C"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT))
        check("s5/first-available-second-priority-advance",
            out is StepOutcome.Advance &&
                driver.selectCount("STORE-B") == 1 &&
                driver.selectCount("STORE-A") == 0)
    }
    run {
        val allFull = listOf(
            StoreOption("STORE-A", slotAvailable = false),
            StoreOption("STORE-B", slotAvailable = false),
        )
        val driver = FakePageDriver(checkoutPage(allFull))
        val out = S5FulfillmentHandler(driver, listOf("STORE-A", "STORE-B"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT))
        check("s5/all-full-E13-no-select",
            out is StepOutcome.Pause && out.errorId == "E13" &&
                driver.selectCount("STORE-A") == 0 &&
                driver.selectCount("STORE-B") == 0)
    }
    run {
        val driver = FakePageDriver(checkoutPage(emptyList()))
        val out = S5FulfillmentHandler(driver, listOf("STORE-A"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT))
        check("s5/no-options-E13",
            out is StepOutcome.Pause && out.errorId == "E13")
    }
    run {
        val driver = FakePageDriver(fulfillmentPage("STORE-B"))
        val out = S5FulfillmentHandler(driver, listOf("STORE-A", "STORE-B"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT, true))
        check("s5/already-fulfilled-advance-no-select",
            out is StepOutcome.Advance && driver.selectCount("STORE-B") == 0)
    }
    run {
        val driver = FakePageDriver(fulfillmentPage("STORE-X"))
        val out = S5FulfillmentHandler(driver, listOf("STORE-A", "STORE-B"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT))
        check("s5/fulfilled-outside-list-E08",
            out is StepOutcome.Pause && out.errorId == "E08")
    }
    run {
        val driver = FakePageDriver(
            checkoutPage(options).copy(fulfillmentDataRejected = true),
        )
        val out = S5FulfillmentHandler(driver, listOf("STORE-A", "STORE-B"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT))
        check("s5/data-rejected-E14-no-select",
            out is StepOutcome.Pause && out.errorId == "E14" &&
                driver.selectCount("STORE-B") == 0)
    }
    run {
        val driver = FakePageDriver(
            checkoutPage(options),
            selectEffects = mapOf(
                "STORE-B" to fulfillmentPage("STORE-B").copy(fulfillmentDataRejected = true),
            ),
        )
        val out = S5FulfillmentHandler(driver, listOf("STORE-A", "STORE-B"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT))
        check("s5/rejected-after-selection-E14-not-advance",
            out is StepOutcome.Pause && out.errorId == "E14")
    }
    run {
        val driver = FakePageDriver(checkoutPage(options, selectCount = 0))
        val out = S5FulfillmentHandler(driver, listOf("STORE-A", "STORE-B"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT))
        check("s5/select-element-missing-E05",
            out is StepOutcome.Pause && out.errorId == "E05")
    }
    run {
        val driver = FakePageDriver(checkoutPage(options, selectClickable = false))
        val out = S5FulfillmentHandler(driver, listOf("STORE-A", "STORE-B"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT))
        check("s5/select-not-clickable-E06",
            out is StepOutcome.Pause && out.errorId == "E06")
    }
    run {
        val driver = RejectingSelectDriver(checkoutPage(options))
        val out = S5FulfillmentHandler(driver, listOf("STORE-A", "STORE-B"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT))
        check("s5/select-refused-E13",
            out is StepOutcome.Pause && out.errorId == "E13")
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.BAG))
        val out = S5FulfillmentHandler(driver, listOf("STORE-A"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT))
        check("s5/wrong-state-E08",
            out is StepOutcome.Pause && out.errorId == "E08")
    }
    run {
        var threw = false
        try {
            S5FulfillmentHandler(FakePageDriver(checkoutPage(options)), emptyList())
        } catch (e: IllegalArgumentException) {
            threw = true
        }
        check("s5/empty-priority-refused-not-inferred", threw)
    }
    run {
        var threw = false
        try {
            S5FulfillmentHandler(
                FakePageDriver(checkoutPage(options)),
                listOf("STORE-A", "STORE-A"),
            )
        } catch (e: IllegalArgumentException) {
            threw = true
        }
        check("s5/duplicate-priority-refused", threw)
    }

    // ---------- machine integration: S1 -> S5 -> S6 placeholder ----------
    run {
        val entry = PageModel(
            pageState = PageState.ENTRY,
            elements = mapOf(
                PageElements.ENTRY_CONTINUE to el(1, true),
                PageElements.PRODUCT_NAVIGATE to el(1, true),
            ),
        )
        val productUnconfigured = PageModel(
            pageState = PageState.PRODUCT,
            elements = mapOf(
                PageElements.PRODUCT_NAVIGATE to el(1, true),
                PageElements.PRODUCT_SELECT to el(1, true),
                PageElements.PRICE to el(1, true, "TEST-PRICE"),
                PageElements.ADD_TO_BAG to el(1, true),
            ),
        )
        val productConfigured = productUnconfigured.copy(
            configuredProductKey = "TEST-PRODUCT",
        )
        val bag = PageModel(
            pageState = PageState.BAG,
            elements = mapOf(
                PageElements.ADD_TO_BAG to el(1, true),
                PageElements.CHECKOUT_BUTTON to el(1, true),
            ),
            bagQuantity = 1,
            bagProductKey = "TEST-PRODUCT",
        )
        val checkout = PageModel(
            pageState = PageState.CHECKOUT,
            elements = mapOf(PageElements.STORE_SELECT to el(1, true)),
            storeOptions = options,
        )
        val fulfilled = PageModel(
            pageState = PageState.FULFILLMENT,
            selectedStoreKey = "STORE-B",
        )
        val driver = FakePageDriver(
            entry,
            clickEffects = mapOf(
                PageElements.PRODUCT_NAVIGATE to productUnconfigured,
                PageElements.PRODUCT_SELECT to productConfigured,
                PageElements.ADD_TO_BAG to bag,
                PageElements.CHECKOUT_BUTTON to checkout,
            ),
            selectEffects = mapOf("STORE-B" to fulfilled),
        )
        val machine = StateMachine()
        machine.registerHandler(PurchaseStep.S1_ENTRY, S1EntryHandler(driver))
        machine.registerHandler(
            PurchaseStep.S2_CONFIGURE,
            S2ConfigureHandler(driver, "TEST-PRODUCT"),
        )
        machine.registerHandler(
            PurchaseStep.S3_ADD_TO_BAG,
            S3AddToBagHandler(driver, "TEST-PRODUCT"),
        )
        machine.registerHandler(PurchaseStep.S4_CHECKOUT, S4CheckoutHandler(driver, "TEST-PRODUCT"))
        machine.registerHandler(
            PurchaseStep.S5_FULFILLMENT,
            S5FulfillmentHandler(driver, listOf("STORE-A", "STORE-B", "STORE-C")),
        )
        machine.start()
        machine.executeCurrentStep()
        check("machine/S1-to-S2", machine.currentStep == PurchaseStep.S2_CONFIGURE)
        machine.executeCurrentStep()
        machine.executeCurrentStep()
        check("machine/S2-to-S3", machine.currentStep == PurchaseStep.S3_ADD_TO_BAG)
        machine.executeCurrentStep()
        check("machine/S3-to-S4", machine.currentStep == PurchaseStep.S4_CHECKOUT)
        machine.executeCurrentStep()
        check("machine/S4-to-S5", machine.currentStep == PurchaseStep.S5_FULFILLMENT)
        machine.executeCurrentStep()
        check("machine/S5-to-S6", machine.currentStep == PurchaseStep.S6_PAYMENT_INPUT)
        machine.executeCurrentStep()
        check("machine/S6-placeholder-stops-not-S7",
            machine.currentStep == PurchaseStep.S6_PAYMENT_INPUT &&
                machine.globalState == GlobalState.STOPPED)
    }

    // ---------- WAITING resume for S5 (handler level) ----------
    // The full machine WAITING cycle for S5 is already covered
    // by the S1–S3 WAITING tests and by the S1–S5 machine
    // chain above; here the handler-level contract is tested:
    // queue -> Wait, then a revalidated execute (as the machine
    // supplies after resumeFromWaiting) advances on the new
    // page state instead of trusting the old one.
    run {
        val driver = FakePageDriver(stateModel(PageState.QUEUE_OR_MAINTENANCE))
        val out = S5FulfillmentHandler(driver, listOf("STORE-B"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT))
        check("waiting/s5-queue-wait-E02",
            out is StepOutcome.Wait && out.errorId == "E02")
        driver.setModel(checkoutPage(listOf(StoreOption("STORE-B", true))))
        val out2 = S5FulfillmentHandler(driver, listOf("STORE-B"))
            .execute(snap(PurchaseStep.S5_FULFILLMENT, true))
        check("waiting/s5-resumed-revalidated-advance",
            out2 is StepOutcome.Advance)
    }

    println(if (failures == 0) "ALL TESTS PASSED" else "$failures TEST(S) FAILED")
    if (failures > 0) kotlin.system.exitProcess(1)
}
