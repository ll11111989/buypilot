package com.example.buypilot.steps

import com.example.buypilot.state.GlobalState
import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.PurchaseStep
import com.example.buypilot.state.StateMachine
import com.example.buypilot.state.StepOutcome

/**
 * JVM unit tests for the S1–S3 page handlers.
 *
 * Offline fixture only: every page state is scripted through
 * FakePageDriver, no real page is loaded, no URL is used, and
 * no card data of any kind appears in this file or its output
 * (S1–S3 handle no card data at all).
 * Run: kotlinc the P2 state core + the steps sources + this
 * file, execute StepsTestKt. Output prints test names only.
 */
private var failures = 0
private fun check(name: String, cond: Boolean) {
    println((if (cond) "PASS " else "FAIL ") + name)
    if (!cond) failures++
}

private fun snap(
    step: PurchaseStep = PurchaseStep.S1_ENTRY,
    needsRevalidation: Boolean = false,
    timeCheck: StateMachine.TimeCheck? = null,
): MachineSnapshot = MachineSnapshot(
    step = step,
    global = GlobalState.RUNNING,
    submitted = false,
    needsRevalidation = needsRevalidation,
    isComplete = false,
    s7Unlocked = false,
    timeCheck = timeCheck,
)

private fun el(count: Int, clickable: Boolean, text: String? = null) =
    ElementInfo(count = count, clickable = clickable, text = text)

private fun entryModel(
    count: Int = 1,
    clickable: Boolean = true,
) = PageModel(
    pageState = PageState.ENTRY,
    elements = mapOf(
        PageElements.ENTRY_CONTINUE to el(count, clickable),
        // The entry page also carries the S2 navigate control;
        // S1 only checks ENTRY_CONTINUE and ignores the rest.
        PageElements.PRODUCT_NAVIGATE to el(1, true),
    ),
)

private fun productModel(
    configured: String? = null,
    price: String? = "TEST-PRICE",
    priceCount: Int = 1,
    soldOut: Boolean = false,
    navigateCount: Int = 1,
    navigateClickable: Boolean = true,
    selectCount: Int = 1,
    selectClickable: Boolean = true,
) = PageModel(
    pageState = PageState.PRODUCT,
    elements = mapOf(
        PageElements.PRODUCT_NAVIGATE to el(navigateCount, navigateClickable),
        PageElements.PRODUCT_SELECT to el(selectCount, selectClickable),
        PageElements.PRICE to el(priceCount, true, price),
    ),
    soldOut = soldOut,
    configuredProductKey = configured,
)

private fun bagModel(quantity: Int?, productKey: String? = "TEST-PRODUCT") = PageModel(
    pageState = PageState.BAG,
    elements = mapOf(PageElements.ADD_TO_BAG to el(1, true)),
    bagQuantity = quantity,
    bagProductKey = productKey,
)

private fun stateModel(state: PageState) = PageModel(pageState = state)

fun main() {
    // ---------- S1 ----------
    run {
        val driver = FakePageDriver(entryModel())
        val out = S1EntryHandler(driver).execute(snap(PurchaseStep.S1_ENTRY))
        check("s1/entry-advance", out is StepOutcome.Advance)
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.LOADING))
        check("s1/loading-stay",
            S1EntryHandler(driver).execute(snap()) is StepOutcome.Stay)
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.QUEUE_OR_MAINTENANCE))
        val out = S1EntryHandler(driver).execute(snap())
        check("s1/queue-wait-E02",
            out is StepOutcome.Wait && out.errorId == "E02")
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.CAPTCHA))
        val out = S1EntryHandler(driver).execute(snap())
        check("s1/captcha-block-E04",
            out is StepOutcome.Block && out.errorId == "E04")
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.BLOCKED_541))
        val out = S1EntryHandler(driver).execute(snap())
        check("s1/541-block-E03",
            out is StepOutcome.Block && out.errorId == "E03")
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.ERROR))
        val out = S1EntryHandler(driver).execute(snap())
        check("s1/error-E01",
            out is StepOutcome.Pause && out.errorId == "E01")
    }
    run {
        val driver = FakePageDriver(entryModel(count = 0))
        val out = S1EntryHandler(driver).execute(snap())
        check("s1/element-missing-E05",
            out is StepOutcome.Pause && out.errorId == "E05")
    }
    run {
        val driver = FakePageDriver(entryModel(count = 2))
        val out = S1EntryHandler(driver).execute(snap())
        check("s1/element-duplicate-E07",
            out is StepOutcome.Pause && out.errorId == "E07")
    }
    run {
        val driver = FakePageDriver(productModel())
        val out = S1EntryHandler(driver).execute(snap())
        check("s1/wrong-state-E08",
            out is StepOutcome.Pause && out.errorId == "E08")
    }
    run {
        val driver = FakePageDriver(entryModel())
        val out = S1EntryHandler(driver).execute(
            snap(timeCheck = StateMachine.TimeCheck.OverLimit(999_999L)),
        )
        check("s1/time-overlimit-pause",
            out is StepOutcome.Pause && out.reason == "S1_TIME_DEVIATION_OVER_LIMIT")
    }

    // ---------- S2 ----------
    run {
        val driver = FakePageDriver(productModel(configured = "TEST-PRODUCT"))
        val out = S2ConfigureHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S2_CONFIGURE, needsRevalidation = true))
        check("s2/already-configured-advance-no-click",
            out is StepOutcome.Advance && driver.clickCount(PageElements.PRODUCT_SELECT) == 0)
    }
    run {
        // D-27: price is no longer verified — already configured advances.
        val driver = FakePageDriver(productModel(configured = "TEST-PRODUCT", price = "OTHER-PRICE"))
        val out = S2ConfigureHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S2_CONFIGURE))
        check("s2/configured-price-ignored-D27",
            out is StepOutcome.Advance &&
                driver.clickCount(PageElements.PRODUCT_SELECT) == 0)
    }
    run {
        // D-27: sold-out is no longer a stop — selection proceeds.
        val configured = productModel(configured = "TEST-PRODUCT", soldOut = true)
        val driver = FakePageDriver(
            productModel(soldOut = true),
            clickEffects = mapOf(PageElements.PRODUCT_SELECT to configured),
        )
        val out = S2ConfigureHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S2_CONFIGURE))
        check("s2/sold-out-ignored-D27",
            out is StepOutcome.Advance &&
                driver.clickCount(PageElements.PRODUCT_SELECT) == 1)
    }
    run {
        // D-27: price mismatch no longer stops — selection proceeds.
        val configured = productModel(configured = "TEST-PRODUCT", price = "OTHER-PRICE")
        val driver = FakePageDriver(
            productModel(price = "OTHER-PRICE"),
            clickEffects = mapOf(PageElements.PRODUCT_SELECT to configured),
        )
        val out = S2ConfigureHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S2_CONFIGURE))
        check("s2/price-ignored-D27",
            out is StepOutcome.Advance &&
                driver.clickCount(PageElements.PRODUCT_SELECT) == 1)
    }
    run {
        // D-27: the PRICE element is not read at all anymore.
        val configured = productModel(configured = "TEST-PRODUCT")
        val driver = FakePageDriver(
            productModel(price = null, priceCount = 0),
            clickEffects = mapOf(PageElements.PRODUCT_SELECT to configured),
        )
        val out = S2ConfigureHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S2_CONFIGURE))
        check("s2/price-missing-ignored-D27",
            out is StepOutcome.Advance &&
                driver.clickCount(PageElements.PRODUCT_SELECT) == 1)
    }
    run {
        val driver = FakePageDriver(productModel(selectCount = 2))
        val out = S2ConfigureHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S2_CONFIGURE))
        check("s2/select-duplicate-E07",
            out is StepOutcome.Pause && out.errorId == "E07")
    }
    run {
        val driver = FakePageDriver(productModel(selectClickable = false))
        val out = S2ConfigureHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S2_CONFIGURE))
        check("s2/select-not-clickable-E06",
            out is StepOutcome.Pause && out.errorId == "E06" &&
                driver.clickCount(PageElements.PRODUCT_SELECT) == 0)
    }
    run {
        val configured = productModel(configured = "TEST-PRODUCT")
        val driver = FakePageDriver(
            productModel(),
            clickEffects = mapOf(PageElements.PRODUCT_SELECT to configured),
        )
        val out = S2ConfigureHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S2_CONFIGURE))
        check("s2/click-configure-advance",
            out is StepOutcome.Advance &&
                driver.clickCount(PageElements.PRODUCT_SELECT) == 1)
    }
    run {
        val wrong = productModel(configured = "OTHER-PRODUCT")
        val driver = FakePageDriver(
            productModel(),
            clickEffects = mapOf(PageElements.PRODUCT_SELECT to wrong),
        )
        val out = S2ConfigureHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S2_CONFIGURE))
        check("s2/click-wrong-product-E08",
            out is StepOutcome.Pause && out.errorId == "E08")
    }
    run {
        val driver = FakePageDriver(
            entryModel(),
            clickEffects = mapOf(
                PageElements.PRODUCT_NAVIGATE to productModel(),
            ),
        )
        val handler = S2ConfigureHandler(driver, "TEST-PRODUCT")
        val out = handler.execute(snap(PurchaseStep.S2_CONFIGURE))
        check("s2/entry-navigate-one-click-then-stay",
            out is StepOutcome.Stay &&
                driver.clickCount(PageElements.PRODUCT_NAVIGATE) == 1 &&
                driver.clickCount(PageElements.PRODUCT_SELECT) == 0)
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.QUEUE_OR_MAINTENANCE))
        val out = S2ConfigureHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S2_CONFIGURE))
        check("s2/queue-wait-E02",
            out is StepOutcome.Wait && out.errorId == "E02")
    }
    run {
        var threw = false
        try {
            S2ConfigureHandler(FakePageDriver(entryModel()), "")
        } catch (e: IllegalArgumentException) {
            threw = true
        }
        check("s2/blank-product-refused-not-inferred", threw)
    }

    // ---------- S3 ----------
    run {
        val driver = FakePageDriver(bagModel(1))
        val out = S3AddToBagHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S3_ADD_TO_BAG, needsRevalidation = true))
        check("s3/already-in-bag-advance-no-click",
            out is StepOutcome.Advance &&
                driver.clickCount(PageElements.ADD_TO_BAG) == 0)
    }
    run {
        // D-27: bag quantity is no longer verified — in bag advances.
        val driver = FakePageDriver(bagModel(2))
        val out = S3AddToBagHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S3_ADD_TO_BAG))
        check("s3/bag-quantity-ignored-D27",
            out is StepOutcome.Advance &&
                driver.clickCount(PageElements.ADD_TO_BAG) == 0)
    }
    run {
        val bag = bagModel(1)
        val driver = FakePageDriver(
            productModel(configured = "TEST-PRODUCT"),
            clickEffects = mapOf(PageElements.ADD_TO_BAG to bag),
        )
        // Add element must exist on the product page for this test.
        driver.setModel(
            productModel(configured = "TEST-PRODUCT").copy(
                elements = productModel(configured = "TEST-PRODUCT").elements +
                    (PageElements.ADD_TO_BAG to el(1, true)),
            ),
        )
        val out = S3AddToBagHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S3_ADD_TO_BAG))
        check("s3/click-add-advance",
            out is StepOutcome.Advance &&
                driver.clickCount(PageElements.ADD_TO_BAG) == 1)
    }
    run {
        val driver = FakePageDriver(productModel(configured = "TEST-PRODUCT"))
        val out = S3AddToBagHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S3_ADD_TO_BAG))
        check("s3/add-element-missing-E05",
            out is StepOutcome.Pause && out.errorId == "E05")
    }
    run {
        val model = productModel(configured = "TEST-PRODUCT").copy(
            elements = productModel(configured = "TEST-PRODUCT").elements +
                (PageElements.ADD_TO_BAG to el(2, true)),
        )
        val driver = FakePageDriver(model)
        val out = S3AddToBagHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S3_ADD_TO_BAG))
        check("s3/add-element-duplicate-E07",
            out is StepOutcome.Pause && out.errorId == "E07")
    }
    run {
        val driver = FakePageDriver(productModel(configured = "TEST-PRODUCT", soldOut = true))
        val out = S3AddToBagHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S3_ADD_TO_BAG))
        check("s3/sold-out-E09-no-click",
            out is StepOutcome.Pause && out.errorId == "E09" &&
                driver.clickCount(PageElements.ADD_TO_BAG) == 0)
    }
    run {
        val driver = FakePageDriver(productModel(configured = "OTHER-PRODUCT"))
        val out = S3AddToBagHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S3_ADD_TO_BAG))
        check("s3/wrong-product-not-added-E08",
            out is StepOutcome.Pause && out.errorId == "E08" &&
                driver.clickCount(PageElements.ADD_TO_BAG) == 0)
    }
    run {
        val driver = FakePageDriver(entryModel())
        val out = S3AddToBagHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S3_ADD_TO_BAG))
        check("s3/wrong-state-E08",
            out is StepOutcome.Pause && out.errorId == "E08")
    }
    // NOTE (D-27 alignment): the quantity parameter no longer
    // exists — S3 adds the configured product once and verifies
    // neither bag identity nor quantity, so the old
    // "quantity-not-defaulted" construction test is removed,
    // not rewritten.

    // ---------- QA S1–S3 exceptions (1) and (2), patched ----------
    run {
        // D-27: bag product identity is no longer verified.
        val driver = FakePageDriver(bagModel(1, "OTHER-PRODUCT"))
        val out = S3AddToBagHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S3_ADD_TO_BAG))
        check("s3/bag-product-ignored-D27",
            out is StepOutcome.Advance &&
                driver.clickCount(PageElements.ADD_TO_BAG) == 0)
    }
    run {
        // D-27: an unreported bag product no longer stops the flow.
        val driver = FakePageDriver(bagModel(1, null))
        val out = S3AddToBagHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S3_ADD_TO_BAG))
        check("s3/bag-product-unknown-ignored-D27",
            out is StepOutcome.Advance &&
                driver.clickCount(PageElements.ADD_TO_BAG) == 0)
    }
    run {
        val driver = FakePageDriver(
            productModel(),
            clickEffects = mapOf(
                PageElements.PRODUCT_SELECT to stateModel(PageState.QUEUE_OR_MAINTENANCE),
            ),
        )
        val out = S2ConfigureHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S2_CONFIGURE))
        check("s2/after-click-queue-wait-not-E08",
            out is StepOutcome.Wait && out.errorId == "E02")
    }
    run {
        val base = productModel(configured = "TEST-PRODUCT").copy(
            elements = productModel(configured = "TEST-PRODUCT").elements +
                (PageElements.ADD_TO_BAG to el(1, true)),
        )
        val driver = FakePageDriver(
            base,
            clickEffects = mapOf(
                PageElements.ADD_TO_BAG to stateModel(PageState.CAPTCHA),
            ),
        )
        val out = S3AddToBagHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S3_ADD_TO_BAG))
        check("s3/after-click-captcha-block-not-E11",
            out is StepOutcome.Block && out.errorId == "E04")
    }
    run {
        val base = productModel(configured = "TEST-PRODUCT").copy(
            elements = productModel(configured = "TEST-PRODUCT").elements +
                (PageElements.ADD_TO_BAG to el(1, true)),
        )
        val driver = FakePageDriver(
            base,
            clickEffects = mapOf(
                PageElements.ADD_TO_BAG to bagModel(1, "OTHER-PRODUCT"),
            ),
        )
        val out = S3AddToBagHandler(driver, "TEST-PRODUCT")
            .execute(snap(PurchaseStep.S3_ADD_TO_BAG))
        check("s3/after-click-bag-product-ignored-D27",
            out is StepOutcome.Advance)
    }

    // ---------- machine integration: S1 -> S2 -> S3 -> S4 placeholder ----------
    run {
        // The configured product model must already carry the
        // add-to-bag element, because FakePageDriver click effects
        // replace the whole page model on each click.
        val configuredWithAdd = productModel(configured = "TEST-PRODUCT").copy(
            elements = productModel(configured = "TEST-PRODUCT").elements +
                (PageElements.ADD_TO_BAG to el(1, true)),
        )
        val driver2 = FakePageDriver(
            entryModel(),
            clickEffects = mapOf(
                PageElements.PRODUCT_NAVIGATE to productModel().copy(
                    elements = productModel().elements +
                        (PageElements.ADD_TO_BAG to el(1, true)),
                ),
                PageElements.PRODUCT_SELECT to configuredWithAdd,
                PageElements.ADD_TO_BAG to bagModel(1),
            ),
        )
        val machine = StateMachine()
        machine.registerHandler(PurchaseStep.S1_ENTRY, S1EntryHandler(driver2))
        machine.registerHandler(
            PurchaseStep.S2_CONFIGURE,
            S2ConfigureHandler(driver2, "TEST-PRODUCT"),
        )
        machine.registerHandler(
            PurchaseStep.S3_ADD_TO_BAG,
            S3AddToBagHandler(driver2, "TEST-PRODUCT"),
        )
        machine.start()
        machine.executeCurrentStep() // S1 -> S2
        check("machine/S1-to-S2", machine.currentStep == PurchaseStep.S2_CONFIGURE)
        machine.executeCurrentStep() // S2 navigate -> Stay
        check("machine/S2-navigate-stay", machine.currentStep == PurchaseStep.S2_CONFIGURE)
        machine.executeCurrentStep() // S2 configure -> S3
        check("machine/S2-to-S3", machine.currentStep == PurchaseStep.S3_ADD_TO_BAG)
        machine.executeCurrentStep() // S3 add -> S4
        check("machine/S3-to-S4", machine.currentStep == PurchaseStep.S4_CHECKOUT)
        machine.executeCurrentStep() // S4 placeholder -> STOPPED, not beyond
        check("machine/S4-placeholder-stops-not-delivered",
            machine.currentStep == PurchaseStep.S4_CHECKOUT &&
                machine.globalState == GlobalState.STOPPED)
    }

    // ---------- WAITING resume re-validates, never stale-advances ----------
    run {
        val driver = FakePageDriver(stateModel(PageState.QUEUE_OR_MAINTENANCE))
        val machine = StateMachine()
        machine.registerHandler(PurchaseStep.S1_ENTRY, S1EntryHandler(driver))
        machine.start()
        machine.executeCurrentStep()
        check("waiting/machine-waiting", machine.globalState == GlobalState.WAITING)
        driver.setModel(entryModel())
        check("waiting/resume-back-to-S1",
            machine.resumeFromWaiting() &&
                machine.currentStep == PurchaseStep.S1_ENTRY &&
                machine.needsRevalidation)
        machine.executeCurrentStep()
        check("waiting/revalidated-advance",
            machine.currentStep == PurchaseStep.S2_CONFIGURE)
    }

    // ---------- BLOCKED has no resume (core unchanged) ----------
    run {
        val driver = FakePageDriver(stateModel(PageState.CAPTCHA))
        val machine = StateMachine()
        machine.registerHandler(PurchaseStep.S1_ENTRY, S1EntryHandler(driver))
        machine.start()
        machine.executeCurrentStep()
        check("blocked/machine-blocked",
            machine.globalState == GlobalState.BLOCKED &&
                !machine.resumeFromStopped() && !machine.resumeFromWaiting())
    }

    println(if (failures == 0) "ALL TESTS PASSED" else "$failures TEST(S) FAILED")
    if (failures > 0) kotlin.system.exitProcess(1)
}
