package com.example.buypilot.payment

/**
 * JVM unit tests for the S6 core (validator + session lifecycle).
 * FAKE test data only. Output prints test names and results only —
 * never card values (E16 logging rule).
 * Run: kotlinc the payment core + this file, execute CardCoreTestKt.
 */
private var failures = 0
private fun check(name: String, cond: Boolean) {
    println((if (cond) "PASS " else "FAIL ") + name)
    if (!cond) failures++
}

fun main() {
    val num = "4111 1111 1111 1111".toCharArray() // standard fake test number
    val exp = "12/34".toCharArray()
    val cvv = "123".toCharArray()

    // ---- CardValidator: number ----
    check("number/base-ok", CardValidator.validateCardNumber(num).ok)
    check("number/luhn-fails",
        CardValidator.validateCardNumber("4111 1111 1111 1112".toCharArray()).error ==
            CardValidator.Error.LUHN)
    check("number/too-short",
        CardValidator.validateCardNumber("411111111111".toCharArray()).error ==
            CardValidator.Error.NUMBER_LENGTH)
    check("number/non-digit",
        CardValidator.validateCardNumber("4111x11111111111".toCharArray()).error ==
            CardValidator.Error.NON_DIGIT)

    // ---- CardValidator: expiry (now = Oct 2026) ----
    check("expiry/base-ok", CardValidator.validateExpiry(exp, 26, 10).ok)
    check("expiry/leading-zero-ok",
        CardValidator.validateExpiry("05/34".toCharArray(), 26, 10).ok)
    check("expiry/month-13",
        CardValidator.validateExpiry("13/34".toCharArray(), 26, 10).error ==
            CardValidator.Error.EXPIRY_MONTH)
    check("expiry/past",
        CardValidator.validateExpiry("01/20".toCharArray(), 26, 10).error ==
            CardValidator.Error.EXPIRY_PAST)
    check("expiry/format-3-digits",
        CardValidator.validateExpiry("5/34".toCharArray(), 26, 10).error ==
            CardValidator.Error.EXPIRY_FORMAT)

    // ---- CardValidator: CVV ----
    check("cvv/3-ok", CardValidator.validateCvv(cvv).ok)
    check("cvv/4-ok", CardValidator.validateCvv("1234".toCharArray()).ok)
    check("cvv/too-short",
        CardValidator.validateCvv("12".toCharArray()).error == CardValidator.Error.CVV_LENGTH)
    check("cvv/non-digit",
        CardValidator.validateCvv("12a".toCharArray()).error == CardValidator.Error.NON_DIGIT)

    // ---- CardSession: lifecycle with fake clock ----
    var now = 0L
    val session = CardSession(clock = { now })
    session.begin()
    now = 1_000
    session.put(CardValidator.Field.CARD_NUMBER, num)
    session.put(CardValidator.Field.EXPIRY, exp)
    session.put(CardValidator.Field.CVV, cvv)
    check("session/all-fields", session.hasAllFields())

    // Fill-attempt consumption: withCardData clears at attempt end.
    var fieldsSeen = 0
    session.withCardData { fieldsSeen = it.size }
    check("session/withCardData-fields", fieldsSeen == 3)
    check("session/cleared-after-fill-attempt", !session.isActive && !session.hasAllFields())

    // Idle timeout (120 s, no activity).
    now = 0L
    session.begin()
    session.put(CardValidator.Field.CARD_NUMBER, num)
    now = 121_000
    check("session/idle-timeout",
        session.checkTimeout() == CardSession.TimeoutKind.IDLE && !session.isActive)
    check("session/idle-trigger",
        session.lastClearTrigger == CardSession.ClearTrigger.TIMEOUT_IDLE)

    // Activity resets idle, but never the absolute cap (300 s).
    // (Activity gaps are kept under the 120 s idle limit on purpose:
    // an idle expiry would legitimately end the session first.)
    now = 0L
    session.begin()
    now = 100_000
    session.put(CardValidator.Field.CARD_NUMBER, num) // activity at 100 s
    now = 200_000
    check("session/idle-reset-by-activity", session.checkTimeout() == null && session.isActive)
    session.put(CardValidator.Field.EXPIRY, exp) // activity at 200 s
    now = 290_000
    session.put(CardValidator.Field.CVV, cvv) // activity at 290 s
    now = 301_000
    check("session/absolute-cap-despite-activity",
        session.checkTimeout() == CardSession.TimeoutKind.ABSOLUTE)
    check("session/absolute-trigger",
        session.lastClearTrigger == CardSession.ClearTrigger.TIMEOUT_ABSOLUTE)

    // Explicit triggers.
    session.begin()
    session.put(CardValidator.Field.CVV, cvv)
    session.clear(CardSession.ClearTrigger.APP_BACKGROUND)
    check("session/background-clear",
        !session.isActive &&
            session.lastClearTrigger == CardSession.ClearTrigger.APP_BACKGROUND)
    session.begin()
    session.clear(CardSession.ClearTrigger.CANCEL)
    check("session/cancel-clear",
        session.lastClearTrigger == CardSession.ClearTrigger.CANCEL)

    // put() on an inactive session must refuse.
    val threw = try {
        session.put(CardValidator.Field.CVV, cvv); false
    } catch (e: IllegalStateException) {
        true
    }
    check("session/put-when-inactive-refused", threw)

    println(if (failures == 0) "ALL TESTS PASSED" else "$failures TEST(S) FAILED")
    if (failures > 0) kotlin.system.exitProcess(1)
}
