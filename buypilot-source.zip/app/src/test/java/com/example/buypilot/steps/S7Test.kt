package com.example.buypilot.steps

import com.example.buypilot.payment.CardSession
import com.example.buypilot.payment.CardValidator
import com.example.buypilot.state.GlobalState
import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.PurchaseStep
import com.example.buypilot.state.StateMachine
import com.example.buypilot.state.StepHandler
import com.example.buypilot.state.StepOutcome

/**
 * JVM unit tests for the S7 PAYMENT_FILL handler.
 *
 * Offline fixture only, FAKE test data only: the card values
 * in this file are the standard public fake test numbers
 * (same precedent as the accepted S6 tests), held only in
 * test memory. No real page is loaded, no URL is used, no
 * real fill or submit happens, and the printed output
 * contains test names only — never any card value, fake or
 * otherwise.
 * Run: kotlinc the P2 state core + the payment core
 * (CardSession/CardValidator) + the steps sources + this
 * file, execute S7TestKt.
 */
private var failures = 0
private fun check(name: String, cond: Boolean) {
    println((if (cond) "PASS " else "FAIL ") + name)
    if (!cond) failures++
}

private fun snap(
    step: PurchaseStep,
    submitted: Boolean = false,
    needsRevalidation: Boolean = false,
): MachineSnapshot = MachineSnapshot(
    step = step,
    global = GlobalState.RUNNING,
    submitted = submitted,
    needsRevalidation = needsRevalidation,
    isComplete = false,
    s7Unlocked = true,
    timeCheck = null,
)

private const val FAKE_NUMBER = "4111 1111 1111 1111" // standard fake test number
private const val FAKE_NUMBER_OTHER = "5500 0055 5555 5559" // standard fake test number
private const val FAKE_EXPIRY = "12/34"
private const val FAKE_CVV = "123"

private fun readySession(
    expiry: String = FAKE_EXPIRY,
    clock: () -> Long = { 0L },
): CardSession {
    val session = CardSession(clock = clock)
    session.begin()
    session.put(CardValidator.Field.CARD_NUMBER, FAKE_NUMBER.toCharArray())
    session.put(CardValidator.Field.EXPIRY, expiry.toCharArray())
    session.put(CardValidator.Field.CVV, FAKE_CVV.toCharArray())
    return session
}

private fun facts(
    number: PaymentFieldFact = PaymentFieldFact(PaymentFields.NUMBER, 1, true),
    expiry: PaymentFieldFact = PaymentFieldFact(PaymentFields.EXPIRY, 1, true),
    cvv: PaymentFieldFact? = PaymentFieldFact(PaymentFields.CVV, 1, true),
): List<PaymentFieldFact> = listOfNotNull(number, expiry, cvv)

private fun paymentModel(fieldFacts: List<PaymentFieldFact> = facts()) = PageModel(
    pageState = PageState.PAYMENT,
    paymentFields = fieldFacts,
)

private fun stateModel(state: PageState) = PageModel(pageState = state)

fun main() {
    // ---------- S7 direct ----------
    run {
        var unverified: List<String>? = null
        val driver = FakePageDriver(paymentModel())
        val session = readySession()
        val out = S7PaymentFillHandler(driver, session) { unverified = it }
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/fill-verify-advance-session-cleared",
            out is StepOutcome.Advance &&
                driver.fillCount(PaymentFields.NUMBER) == 1 &&
                driver.fillCount(PaymentFields.EXPIRY) == 1 &&
                driver.fillCount(PaymentFields.CVV) == 1 &&
                unverified == emptyList<String>() && !session.isActive)
    }
    run {
        val driver = FakePageDriver(paymentModel(facts(cvv = null)))
        val session = readySession()
        val out = S7PaymentFillHandler(driver, session)
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/field-missing-E05-no-fill-session-kept",
            out is StepOutcome.Pause && out.errorId == "E05" &&
                driver.fillCount(PaymentFields.NUMBER) == 0 && session.isActive)
    }
    run {
        val driver = FakePageDriver(
            paymentModel(facts(number = PaymentFieldFact(PaymentFields.NUMBER, 2, true))),
        )
        val session = readySession()
        val out = S7PaymentFillHandler(driver, session)
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/field-duplicate-E07-no-fill",
            out is StepOutcome.Pause && out.errorId == "E07" &&
                driver.fillCount(PaymentFields.NUMBER) == 0)
    }
    run {
        val driver = FakePageDriver(
            paymentModel(facts(expiry = PaymentFieldFact(PaymentFields.EXPIRY, 1, false))),
        )
        val session = readySession()
        val out = S7PaymentFillHandler(driver, session)
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/field-not-main-frame-E15-no-fill",
            out is StepOutcome.Pause && out.errorId == "E15" &&
                driver.fillCount(PaymentFields.NUMBER) == 0 &&
                driver.fillCount(PaymentFields.EXPIRY) == 0)
    }
    run {
        val driver = FakePageDriver(
            paymentModel(),
            fillRefusals = setOf(PaymentFields.EXPIRY),
        )
        val session = readySession()
        val out = S7PaymentFillHandler(driver, session)
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/fill-refused-E15-attempt-cleared",
            out is StepOutcome.Pause && out.errorId == "E15" &&
                driver.fillCount(PaymentFields.NUMBER) == 1 &&
                driver.fillCount(PaymentFields.CVV) == 0 && !session.isActive)
    }
    run {
        val driver = FakePageDriver(
            paymentModel(),
            readBackOverrides = mapOf(PaymentFields.NUMBER to FAKE_NUMBER_OTHER),
        )
        val session = readySession()
        val out = S7PaymentFillHandler(driver, session)
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/readback-number-mismatch-E16-cleared",
            out is StepOutcome.Pause && out.errorId == "E16" && !session.isActive)
    }
    run {
        // Leading zero preserved: filled 05/34 reads back
        // 05/34 (digits 0534) -> match, not a numeric compare.
        val driver = FakePageDriver(paymentModel())
        val session = readySession(expiry = "05/34")
        val out = S7PaymentFillHandler(driver, session)
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/readback-expiry-leading-zero-match", out is StepOutcome.Advance)
    }
    run {
        // Page dropped the leading zero: 5/34 (digits 534)
        // is a different MMYY string -> mismatch.
        val driver = FakePageDriver(
            paymentModel(),
            readBackOverrides = mapOf(PaymentFields.EXPIRY to "5/34"),
        )
        val session = readySession(expiry = "05/34")
        val out = S7PaymentFillHandler(driver, session)
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/readback-expiry-leading-zero-lost-E16",
            out is StepOutcome.Pause && out.errorId == "E16")
    }
    run {
        // Separator variant is not a mismatch: page returns
        // the expiry digits without a slash.
        val driver = FakePageDriver(
            paymentModel(),
            readBackOverrides = mapOf(PaymentFields.EXPIRY to "1234"),
        )
        val session = readySession()
        val out = S7PaymentFillHandler(driver, session)
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/readback-expiry-separator-variant-advance",
            out is StepOutcome.Advance)
    }
    run {
        var unverified: List<String>? = null
        val driver = FakePageDriver(
            paymentModel(),
            readBackOverrides = mapOf(PaymentFields.CVV to null),
        )
        val session = readySession()
        val out = S7PaymentFillHandler(driver, session) { unverified = it }
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/readback-cvv-unreadable-advance-unverified-reported",
            out is StepOutcome.Advance &&
                unverified == listOf(PaymentFields.CVV) && !session.isActive)
    }
    run {
        val session = CardSession(clock = { 0L })
        session.begin()
        session.put(CardValidator.Field.CARD_NUMBER, FAKE_NUMBER.toCharArray())
        session.put(CardValidator.Field.EXPIRY, FAKE_EXPIRY.toCharArray())
        // CVV deliberately missing.
        val driver = FakePageDriver(paymentModel())
        val out = S7PaymentFillHandler(driver, session)
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/card-data-unavailable-no-fill",
            out is StepOutcome.Pause && out.errorId == null &&
                driver.fillCount(PaymentFields.NUMBER) == 0 && session.isActive)
    }
    run {
        var now = 0L
        val session = readySession(clock = { now })
        now = 300_001L // beyond the absolute cap from begin()
        val driver = FakePageDriver(paymentModel())
        val out = S7PaymentFillHandler(driver, session)
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/session-timeout-no-fill-cleared",
            out is StepOutcome.Pause && out.errorId == null &&
                driver.fillCount(PaymentFields.NUMBER) == 0 && !session.isActive)
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.QUEUE_OR_MAINTENANCE))
        val out = S7PaymentFillHandler(driver, readySession())
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/queue-wait-E02",
            out is StepOutcome.Wait && out.errorId == "E02")
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.CAPTCHA))
        val out = S7PaymentFillHandler(driver, readySession())
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/captcha-block-E04",
            out is StepOutcome.Block && out.errorId == "E04")
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.FULFILLMENT))
        val out = S7PaymentFillHandler(driver, readySession())
            .execute(snap(PurchaseStep.S7_PAYMENT_FILL))
        check("s7/wrong-page-E08",
            out is StepOutcome.Pause && out.errorId == "E08")
    }

    // ---------- machine: locked gate unchanged ----------
    run {
        val driver = FakePageDriver(stateModel(PageState.ENTRY))
        val session = readySession()
        val machine = StateMachine() // production default: locked
        for (step in PurchaseStep.entries) {
            if (step == PurchaseStep.S7_PAYMENT_FILL) {
                machine.registerHandler(step, S7PaymentFillHandler(driver, session))
            } else {
                machine.registerHandler(step, StepHandler { StepOutcome.Advance })
            }
        }
        machine.start()
        repeat(6) { machine.executeCurrentStep() }
        check("machine/locked-at-S7", machine.currentStep == PurchaseStep.S7_PAYMENT_FILL)
        driver.setModel(paymentModel())
        machine.executeCurrentStep()
        check("machine/locked-S7-handler-not-called-session-kept",
            machine.globalState == GlobalState.STOPPED &&
                driver.fillCount(PaymentFields.NUMBER) == 0 && session.isActive)
    }

    // ---------- machine: unlocked chain through S7 ----------
    run {
        val driver = FakePageDriver(stateModel(PageState.ENTRY))
        val session = readySession()
        var unverified: List<String>? = null
        val machine = StateMachine(
            config = StateMachine.Config(s7Unlocked = true),
        )
        for (step in PurchaseStep.entries) {
            if (step == PurchaseStep.S7_PAYMENT_FILL) {
                machine.registerHandler(
                    step,
                    S7PaymentFillHandler(driver, session) { unverified = it },
                )
            } else {
                machine.registerHandler(step, StepHandler { StepOutcome.Advance })
            }
        }
        machine.start()
        repeat(6) { machine.executeCurrentStep() }
        check("machine/unlocked-at-S7", machine.currentStep == PurchaseStep.S7_PAYMENT_FILL)
        driver.setModel(paymentModel())
        machine.executeCurrentStep()
        check("machine/S7-fill-to-S8-not-submitted",
            machine.currentStep == PurchaseStep.S8_SUBMIT_CONFIRM &&
                !machine.submitted && !session.isActive &&
                unverified == emptyList<String>())
        machine.executeCurrentStep()
        machine.executeCurrentStep()
        check("machine/chain-completes-at-S9", machine.isComplete)
    }

    println(if (failures == 0) "ALL TESTS PASSED" else "$failures TEST(S) FAILED")
    if (failures > 0) kotlin.system.exitProcess(1)
}
