package com.example.buypilot.state

/**
 * JVM unit tests for the P2 state-machine core.
 *
 * This test file contains NO card values at all — not even fake
 * ones. Since D-35 the core performs no card clearing at all
 * (the clear callback no longer exists), so there is no
 * clearing behaviour left to test here; the machine never
 * holds card data by design.
 * Run: kotlinc the state core + this file, execute
 * StateMachineTestKt. Output prints test names only.
 */
private var failures = 0
private fun check(name: String, cond: Boolean) {
    println((if (cond) "PASS " else "FAIL ") + name)
    if (!cond) failures++
}

private fun advanceMachine(): StepHandler =
    StepHandler { StepOutcome.Advance }

private fun machineWith(): StateMachine =
    StateMachine()

fun main() {
    // ---- start / time check (O-01 undecided) ----
    run {
        val m = machineWith()
        check("start/not-started-global-null", m.globalState == null && !m.isStarted)
        check("start/ok", m.start())
        check("start/at-S1-running", m.currentStep == PurchaseStep.S1_ENTRY &&
            m.globalState == GlobalState.RUNNING)
        check("start/time-undecided-not-passed",
            m.timeCheck is StateMachine.TimeCheck.LimitUndecided)
        check("start/second-start-refused", !m.start())
    }

    // ---- start blocked by over-limit time deviation ----
    run {
        var deviation = 999_999L
        val m = StateMachine(
            config = StateMachine.Config(
                timeDeviationLimitMs = 60_000L,
                timeProvider = StateMachine.TimeDeviationProvider { deviation },
            ),
        )
        check("time/start-blocked-stopped", m.start() &&
            m.globalState == GlobalState.STOPPED &&
            m.currentStep == PurchaseStep.S1_ENTRY)
        var handlerCalls = 0
        m.registerHandler(PurchaseStep.S1_ENTRY, StepHandler {
            handlerCalls++; StepOutcome.Advance
        })
        check("time/blocked-handler-not-called",
            m.executeCurrentStep() == null && handlerCalls == 0)
        deviation = 1_000L
        check("time/resume-after-fix", m.resumeFromStopped() &&
            m.globalState == GlobalState.RUNNING)
        check("time/resume-runs-handler",
            m.executeCurrentStep() is StepOutcome.Advance && handlerCalls == 1)
    }

    // ---- advance chain S1 -> S2 -> S3 ----
    run {
        val m = machineWith()
        m.registerHandler(PurchaseStep.S1_ENTRY, advanceMachine())
        m.registerHandler(PurchaseStep.S2_CONFIGURE, advanceMachine())
        m.start()
        m.executeCurrentStep()
        check("advance/S1-to-S2", m.currentStep == PurchaseStep.S2_CONFIGURE)
        m.executeCurrentStep()
        check("advance/S2-to-S3", m.currentStep == PurchaseStep.S3_ADD_TO_BAG)
    }

    // ---- not-implemented placeholder pauses, never fails ----
    run {
        val m = machineWith()
        m.start()
        val out = m.executeCurrentStep()
        check("placeholder/pauses", out is StepOutcome.Pause &&
            m.globalState == GlobalState.STOPPED)
        check("placeholder/step-unchanged",
            m.currentStep == PurchaseStep.S1_ENTRY)
        check("placeholder/resume-needs-revalidation",
            m.resumeFromStopped() && m.needsRevalidation)
    }

    // ---- Stay = generic retry hook, step unchanged ----
    run {
        val m = machineWith()
        var calls = 0
        m.registerHandler(PurchaseStep.S5_FULFILLMENT, StepHandler {
            calls++
            if (calls < 3) StepOutcome.Stay else StepOutcome.Advance
        })
        m.start()
        // Drive to S5 with advance handlers for S1-S4.
        for (step in listOf(
            PurchaseStep.S1_ENTRY, PurchaseStep.S2_CONFIGURE,
            PurchaseStep.S3_ADD_TO_BAG, PurchaseStep.S4_CHECKOUT
        )) m.registerHandler(step, advanceMachine())
        repeat(4) { m.executeCurrentStep() }
        check("stay/at-S5", m.currentStep == PurchaseStep.S5_FULFILLMENT)
        m.executeCurrentStep()
        m.executeCurrentStep()
        check("stay/keeps-step", m.currentStep == PurchaseStep.S5_FULFILLMENT)
        m.executeCurrentStep()
        check("stay/then-advances", m.currentStep == PurchaseStep.S6_PAYMENT_INPUT)
    }

    // ---- Pause / resume ----
    run {
        val m = machineWith()
        m.registerHandler(PurchaseStep.S1_ENTRY, StepHandler {
            StepOutcome.Pause(reason = "USER_TEST_PAUSE")
        })
        m.start()
        m.executeCurrentStep()
        check("pause/stopped", m.globalState == GlobalState.STOPPED)
        check("pause/execute-noop", m.executeCurrentStep() == null)
        check("pause/resume", m.resumeFromStopped() &&
            m.globalState == GlobalState.RUNNING && m.needsRevalidation)
        check("pause/api-pause", m.pause("USER_PAUSE") &&
            m.globalState == GlobalState.STOPPED)
    }

    // ---- WAITING resume returns to same step, re-validates ----
    run {
        val m = machineWith()
        m.registerHandler(PurchaseStep.S1_ENTRY, advanceMachine())
        m.registerHandler(PurchaseStep.S2_CONFIGURE, advanceMachine())
        m.start()
        m.executeCurrentStep()
        m.executeCurrentStep()
        check("waiting/at-S3", m.currentStep == PurchaseStep.S3_ADD_TO_BAG)
        check("waiting/enter", m.enterWaiting("QUEUE", "E02") &&
            m.globalState == GlobalState.WAITING)
        check("waiting/execute-noop", m.executeCurrentStep() == null)
        check("waiting/resume-back-to-S3",
            m.resumeFromWaiting() && m.currentStep == PurchaseStep.S3_ADD_TO_BAG &&
                m.globalState == GlobalState.RUNNING && m.needsRevalidation)
    }

    // ---- BLOCKED: no resume, only fresh run ----
    run {
        val m = machineWith()
        m.registerHandler(PurchaseStep.S1_ENTRY, StepHandler {
            StepOutcome.Block(reason = "CAPTCHA", errorId = "E04")
        })
        m.start()
        m.executeCurrentStep()
        check("blocked/state", m.globalState == GlobalState.BLOCKED)
        check("blocked/execute-noop", m.executeCurrentStep() == null)
        check("blocked/resume-refused",
            !m.resumeFromStopped() && !m.resumeFromWaiting())
        m.resetForNewRun()
        check("blocked/fresh-run-after-reset",
            !m.isStarted && m.globalState == null && m.start())
    }

    // ---- cancel / decline / fail before submit ----
    run {
        val m = machineWith()
        m.start()
        check("cancel/before-submit", m.cancel() &&
            m.globalState == GlobalState.CANCELLED)
        check("cancel/terminal-no-repeat", !m.cancel())
    }
    run {
        val m = machineWith()
        m.start()
        check("decline/before-submit", m.decline() &&
            m.globalState == GlobalState.DECLINED)
    }
    run {
        val m = machineWith()
        m.start()
        check("fail/terminal", m.fail("TEST_FAIL") &&
            m.globalState == GlobalState.FAILED)
        check("fail/execute-noop", m.executeCurrentStep() == null)
    }

    // ---- interrupts before submit ----
    run {
        val m = machineWith()
        m.start()
        check("interrupt/background-to-cancelled",
            m.onInterrupt(StateMachine.InterruptKind.APP_BACKGROUND) &&
                m.globalState == GlobalState.CANCELLED)
    }
    run {
        val m = machineWith()
        m.start()
        check("interrupt/network-to-stopped",
            m.onInterrupt(StateMachine.InterruptKind.NETWORK_LOST) &&
                m.globalState == GlobalState.STOPPED)
        check("interrupt/network-resume",
            m.resumeFromStopped() && m.globalState == GlobalState.RUNNING)
    }

    // ---- submitted-priority: unknown outcomes after dispatch -> UNKNOWN
    // (D-34 exception: explicit decline after dispatch -> DECLINED) ----
    // A locked machine cannot reach S8 by design, so the submitted
    // cases below use an unlocked TEST-ONLY machine (production
    // stays locked; see StateMachine). The gate itself is tested
    // separately in the S7-lock section below.
    run {
        val m = StateMachine(
            config = StateMachine.Config(s7Unlocked = true),
        )
        for (step in PurchaseStep.entries) m.registerHandler(step, advanceMachine())
        m.start()
        repeat(7) { m.executeCurrentStep() }
        check("submitted/at-S8", m.currentStep == PurchaseStep.S8_SUBMIT_CONFIRM)
        m.markSubmitted()
        check("submitted/flag", m.submitted)
        check("submitted/background-to-unknown",
            m.onInterrupt(StateMachine.InterruptKind.APP_BACKGROUND) &&
                m.globalState == GlobalState.UNKNOWN)
    }
    run {
        val m = StateMachine(
            config = StateMachine.Config(s7Unlocked = true),
        )
        for (step in PurchaseStep.entries) m.registerHandler(step, advanceMachine())
        m.start()
        repeat(7) { m.executeCurrentStep() }
        m.markSubmitted()
        check("submitted/waiting-to-unknown",
            m.enterWaiting("QUEUE", "E02") &&
                m.globalState == GlobalState.UNKNOWN)
    }
    run {
        val m = StateMachine(
            config = StateMachine.Config(s7Unlocked = true),
        )
        for (step in PurchaseStep.entries) m.registerHandler(step, advanceMachine())
        m.start()
        repeat(7) { m.executeCurrentStep() }
        m.markSubmitted()
        check("submitted/cancel-to-unknown",
            m.cancel() && m.globalState == GlobalState.UNKNOWN)
        check("submitted/never-resubmit-execute-noop",
            m.executeCurrentStep() == null)
    }
    run {
        // D-34: an explicit decline after submit is a KNOWN
        // result — DECLINED, not UNKNOWN.
        val m = StateMachine(
            config = StateMachine.Config(s7Unlocked = true),
        )
        for (step in PurchaseStep.entries) m.registerHandler(step, advanceMachine())
        m.start()
        repeat(7) { m.executeCurrentStep() }
        m.markSubmitted()
        check("submitted/decline-to-declined-D34",
            m.decline() && m.globalState == GlobalState.DECLINED)
    }
    run {
        val m = StateMachine(config = StateMachine.Config(s7Unlocked = true))
        for (step in PurchaseStep.entries) m.registerHandler(step, advanceMachine())
        m.start()
        var threw = false
        try {
            m.markSubmitted()
        } catch (e: IllegalStateException) {
            threw = true
        }
        check("submitted/mark-only-at-S8-refused", threw)
    }

    // ---- S7 lock: handler never called, run pauses at S7 ----
    run {
        var s7Calls = 0
        val m = machineWith()
        for (step in PurchaseStep.entries) {
            m.registerHandler(step, if (step == PurchaseStep.S7_PAYMENT_FILL) {
                StepHandler { s7Calls++; StepOutcome.Advance }
            } else advanceMachine())
        }
        m.start()
        repeat(6) { m.executeCurrentStep() }
        check("s7/at-S7", m.currentStep == PurchaseStep.S7_PAYMENT_FILL)
        val out = m.executeCurrentStep()
        check("s7/locked-pauses", out is StepOutcome.Pause &&
            m.globalState == GlobalState.STOPPED && s7Calls == 0 &&
            m.lastReason == "S7_LOCKED")
    }
    run {
        // Test-only unlocked machine proves the gate, not a product
        // unlock: with the gate open, S7 runs and S8 is reached.
        var s7Calls = 0
        val m = StateMachine(config = StateMachine.Config(s7Unlocked = true))
        for (step in PurchaseStep.entries) {
            m.registerHandler(step, if (step == PurchaseStep.S7_PAYMENT_FILL) {
                StepHandler { s7Calls++; StepOutcome.Advance }
            } else advanceMachine())
        }
        m.start()
        repeat(7) { m.executeCurrentStep() }
        check("s7/test-only-unlocked-runs",
            s7Calls == 1 && m.currentStep == PurchaseStep.S8_SUBMIT_CONFIRM)
    }

    // ---- S9 completion ----
    run {
        val m = StateMachine(config = StateMachine.Config(s7Unlocked = true))
        for (step in PurchaseStep.entries) m.registerHandler(step, advanceMachine())
        m.start()
        repeat(9) { m.executeCurrentStep() }
        check("s9/complete", m.isComplete &&
            m.currentStep == PurchaseStep.S9_RESULT)
    }

    // ---- in-run time deviation -> STOPPED ----
    run {
        var deviation = 1_000L
        val m = StateMachine(
            config = StateMachine.Config(
                timeDeviationLimitMs = 60_000L,
                timeProvider = StateMachine.TimeDeviationProvider { deviation },
            ),
        )
        m.start()
        deviation = 999_999L
        val check = m.checkTimeDeviationDuringRun()
        check("time/in-run-over-stopped",
            check is StateMachine.TimeCheck.OverLimit &&
                m.globalState == GlobalState.STOPPED && m.needsRevalidation)
    }

    // ---- event log carries codes/reasons only ----
    run {
        val m = machineWith()
        m.registerHandler(PurchaseStep.S1_ENTRY, advanceMachine())
        m.start()
        m.executeCurrentStep()
        check("log/has-start-and-advance",
            m.eventLog.any { it == "START" } &&
                m.eventLog.any { it == "ADVANCE S1->S2" })
    }

    println(if (failures == 0) "ALL TESTS PASSED" else "$failures TEST(S) FAILED")
    if (failures > 0) kotlin.system.exitProcess(1)
}
