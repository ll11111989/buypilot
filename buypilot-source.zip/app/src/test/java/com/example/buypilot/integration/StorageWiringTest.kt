package com.example.buypilot.integration

import com.example.buypilot.payment.CardSession
import com.example.buypilot.payment.CardValidator
import com.example.buypilot.state.GlobalState
import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.PurchaseStep
import com.example.buypilot.state.StepOutcome
import com.example.buypilot.steps.PageDriver
import com.example.buypilot.steps.PageModel
import com.example.buypilot.steps.PageState
import com.example.buypilot.steps.PaymentFieldFact
import com.example.buypilot.storage.Crypto
import com.example.buypilot.storage.ProfileBackend
import com.example.buypilot.storage.PickupGroup
import com.example.buypilot.storage.ProductGroup
import com.example.buypilot.storage.ProfileInput
import com.example.buypilot.storage.ProfileRepository
import com.example.buypilot.storage.SaveBlock
import com.example.buypilot.storage.SaveOutcome
import com.example.buypilot.storage.DeleteOutcome
import com.example.buypilot.storage.MaterializeOutcome
import com.example.buypilot.storage.EditLoadOutcome
import com.example.buypilot.storage.ProfileSummary
import com.example.buypilot.storage.StoredProfile
import com.example.buypilot.storage.WorkingCopy
import java.io.File

/**
 * JVM unit tests for the app-integration wiring (Fire package).
 *
 * This file contains NO card values at all — not even fake
 * ones. All card fields in tests are non-numeric dummy text
 * ("DUMMY-NUMBER" style); the backend and repository never
 * validate card format, so dummies exercise the real code
 * paths (serialization, validation order, close-to-zero)
 * without any card-like value ever appearing. The test
 * crypto is an identity transform, labelled test-only; the
 * real Keystore crypto is Android-only and stays an
 * uncompiled reservation (see README).
 * Run: kotlinc the state core + S1–S3 steps + S6 payment
 * (CardSession/CardValidator only) + S7 steps + storage
 * Profile/ProfileRepository + integration wiring files +
 * this file, execute StorageWiringTestKt. Output prints
 * test names only.
 */
private var failures = 0
private fun check(name: String, cond: Boolean) {
    println((if (cond) "PASS " else "FAIL ") + name)
    if (!cond) failures++
}

/** Test-only identity crypto: NEVER a real encryption. */
private object TestCrypto : Crypto {
    override fun encrypt(plain: CharArray): ByteArray =
        String(plain).toByteArray(Charsets.UTF_8)
    override fun decrypt(cipher: ByteArray): CharArray =
        String(cipher, Charsets.UTF_8).toCharArray()
}

private fun tmpDir(): File {
    val dir = File(
        System.getProperty("java.io.tmpdir"),
        "buypilot-wiring-test-" + System.nanoTime(),
    )
    dir.mkdirs()
    return dir
}

private fun product(): ProductGroup =
    ProductGroup("MODEL", "COLOUR", "CAP", 1, null, null)

private fun pickup(): PickupGroup =
    PickupGroup("pickup", listOf("STORE-A"), null, null, null, null, null)

private fun input(name: String): ProfileInput =
    ProfileInput(
        name, product(), pickup(),
        "DUMMY-NUMBER".toCharArray(), "DUMMY-EXPIRY".toCharArray(),
    )

private fun stored(
    id: String,
    name: String,
    cipher: ByteArray = ("CIPHER-" + id).toByteArray(Charsets.UTF_8),
): StoredProfile = StoredProfile(
    id = id,
    name = name,
    product = product(),
    pickup = pickup(),
    encryptedCardNumber = cipher,
    encryptedExpiry = "CIPHER-EXP".toByteArray(Charsets.UTF_8),
    cardLast4 = "",
)

private fun profilesEqual(a: StoredProfile, b: StoredProfile): Boolean =
    a.id == b.id && a.name == b.name && a.product == b.product &&
        a.pickup == b.pickup &&
        a.encryptedCardNumber.contentEquals(b.encryptedCardNumber) &&
        a.encryptedExpiry.contentEquals(b.encryptedExpiry) &&
        a.cardLast4 == b.cardLast4

private fun allZero(chars: CharArray): Boolean = chars.all { it == '\u0000' }

private class FakePaymentDriver(
    private val fillOk: Boolean,
    private val readbacks: Map<String, String>,
) : PageDriver {
    override fun snapshot(): PageModel = PageModel(
        pageState = PageState.PAYMENT,
        paymentFields = listOf(
            PaymentFieldFact("cc-number", 1, true),
            PaymentFieldFact("cc-exp", 1, true),
            PaymentFieldFact("cc-csc", 1, true),
        ),
    )
    override fun click(elementId: String): Boolean = false
    override fun fillPaymentField(fieldCode: String, value: CharArray): Boolean = fillOk
    override fun paymentFieldReadBack(fieldCode: String): String? = readbacks[fieldCode]
}

fun main() {
    // ---------- FileProfileBackend ----------
    run {
        val backend = FileProfileBackend(tmpDir())
        check("backend/missing-file-empty", backend.loadAll().isEmpty())
    }
    run {
        val backend = FileProfileBackend(tmpDir())
        val first = stored("id-1", "名\n稱 Test")
        val second = StoredProfile(
            id = "id-2",
            name = "  padded  ",
            product = ProductGroup("M", "C", "K", 2, true, false),
            pickup = PickupGroup(
                "delivery", listOf("A", "B"), "slot",
                "NAME", "PHONE", "MAIL", "ADDR",
            ),
            encryptedCardNumber = byteArrayOf(0, 1, 2, -1),
            encryptedExpiry = byteArrayOf(9, 8),
            cardLast4 = "LAST",
        )
        backend.saveAll(listOf(first, second))
        val loaded = backend.loadAll()
        check("backend/round-trip-count", loaded.size == 2)
        check("backend/round-trip-first",
            loaded.size == 2 && profilesEqual(loaded[0], first))
        check("backend/round-trip-second",
            loaded.size == 2 && profilesEqual(loaded[1], second))
        backend.saveAll(listOf(second))
        val overwritten = backend.loadAll()
        check("backend/overwrite-replaces",
            overwritten.size == 1 && profilesEqual(overwritten[0], second))
    }
    run {
        val dir = tmpDir()
        val backend = FileProfileBackend(dir)
        val storeDir = File(dir, "profile_store")
        storeDir.mkdirs()
        File(storeDir, "profiles.bin").writeBytes(byteArrayOf(9, 9, 9))
        var threw = false
        try {
            backend.loadAll()
        } catch (e: IllegalStateException) {
            threw = true
        }
        check("backend/corrupt-throws-not-silent-empty", threw)
    }

    // ---------- ProfileRepository validation order ----------
    run {
        var nextId = 0
        val repo = ProfileRepository(
            FileProfileBackend(tmpDir()), TestCrypto, { "id-${++nextId}" },
        )
        val input = { name: String ->
            ProfileInput(name, product(), pickup(), "DUMMY-NUMBER".toCharArray(), "DUMMY-EXPIRY".toCharArray())
        }
        check("repo/empty-name-blocked",
            repo.saveProfile(input("   ")) ==
                SaveOutcome.Blocked(SaveBlock.EMPTY_NAME))
        check("repo/first-save-ok",
            repo.saveProfile(input("TestName")) is SaveOutcome.Saved)
        check("repo/duplicate-case-space-blocked",
            repo.saveProfile(input(" testname ")) ==
                SaveOutcome.Blocked(SaveBlock.DUPLICATE_NAME))
        for (i in 1..9) {
            repo.saveProfile(input("P$i"))
        }
        check("repo/limit-11th-blocked",
            repo.saveProfile(input("P10")) ==
                SaveOutcome.Blocked(SaveBlock.LIMIT_REACHED))
        val savedId = (repo.listProfiles().first { it.name == "P1" }).id
        check("repo/update-under-cap-ok",
            repo.updateProfile(savedId, input("P1-new")) is SaveOutcome.Saved)
        check("repo/update-rename-duplicate-blocked",
            repo.updateProfile(savedId, input("P2")) ==
                SaveOutcome.Blocked(SaveBlock.DUPLICATE_NAME))
        check("repo/update-missing-id-notfound",
            repo.updateProfile("no-such-id", input("Ghost")) ==
                SaveOutcome.Blocked(SaveBlock.NOT_FOUND))
        check("repo/delete-removes-only-target", run {
            repo.deleteProfile(savedId)
            val names = repo.listProfiles().map { it.name }
            !names.contains("P1-new") && names.contains("P2")
        })
        check("repo/list-masked-only", run {
            val summaries = repo.listProfiles()
            summaries.isNotEmpty() &&
                summaries.all { it.name.isNotEmpty() && it.cardLast4 == "" }
        })
    }

    // ---------- materialize + close ----------
    run {
        var nextId = 0
        val repo = ProfileRepository(
            FileProfileBackend(tmpDir()), TestCrypto, { "id-${++nextId}" },
        )
        val saved = repo.saveProfile(
            ProfileInput(
                "Mat", product(), pickup(),
                "DUMMY-NUMBER".toCharArray(), "DUMMY-EXPIRY".toCharArray(),
            ),
        ) as SaveOutcome.Saved
        val outcome = repo.materializeForRun(saved.id, "DUMMY-CVV".toCharArray())
        check("repo/materialize-ok", outcome is MaterializeOutcome.Ok)
        if (outcome is MaterializeOutcome.Ok) {
            val copy = outcome.copy
            check("repo/materialize-fields",
                String(copy.cardNumber) == "DUMMY-NUMBER" &&
                    String(copy.expiry) == "DUMMY-EXPIRY" &&
                    String(copy.cvv) == "DUMMY-CVV")
            copy.close()
            check("repo/working-copy-close-zeroes",
                allZero(copy.cardNumber) && allZero(copy.expiry) && allZero(copy.cvv))
        }
        check("repo/materialize-missing",
            repo.materializeForRun("no-such-id", "X".toCharArray()) ==
                MaterializeOutcome.NotFound)
    }

    // ---------- S6 save helper ----------
    run {
        var nextId = 0
        val repo = ProfileRepository(
            FileProfileBackend(tmpDir()), TestCrypto, { "id-${++nextId}" },
        )
        val session = CardSession()
        session.begin()
        session.put(CardValidator.Field.CARD_NUMBER, "DUMMY-NUMBER".toCharArray())
        session.put(CardValidator.Field.EXPIRY, "DUMMY-EXPIRY".toCharArray())
        session.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        val outcome = saveS6InputAsProfile(repo, "SaveMe", product(), pickup(), session)
        check("save-helper/saved-with-copy", outcome is SaveS6Outcome.Saved)
        if (outcome is SaveS6Outcome.Saved) {
            check("save-helper/copy-fields",
                String(outcome.copy.cardNumber) == "DUMMY-NUMBER" &&
                    String(outcome.copy.expiry) == "DUMMY-EXPIRY" &&
                    String(outcome.copy.cvv) == "DUMMY-CVV")
            outcome.copy.close()
        }
        check("save-helper/session-ended-after-borrow", !session.isActive)
        check("save-helper/stored-listed",
            repo.listProfiles().any { it.name == "SaveMe" })
        val session2 = CardSession()
        session2.begin()
        session2.put(CardValidator.Field.CARD_NUMBER, "DUMMY-NUMBER".toCharArray())
        session2.put(CardValidator.Field.EXPIRY, "DUMMY-EXPIRY".toCharArray())
        session2.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        val dup = saveS6InputAsProfile(repo, " saveme ", product(), pickup(), session2)
        check("save-helper/precheck-duplicate-session-intact",
            dup == SaveS6Outcome.PrecheckBlocked(SaveBlock.DUPLICATE_NAME) &&
                session2.isActive && session2.hasAllFields())
        val session3 = CardSession()
        session3.begin()
        check("save-helper/session-not-ready",
            saveS6InputAsProfile(repo, "X", product(), pickup(), session3) ==
                SaveS6Outcome.SessionNotReady)
    }

    // ---------- S7 stored-copy close guarantee ----------
    run {
        val snap = MachineSnapshot(
            step = PurchaseStep.S7_PAYMENT_FILL,
            global = GlobalState.RUNNING,
            submitted = false,
            needsRevalidation = false,
            isComplete = false,
            s7Unlocked = true,
            timeCheck = null,
        )
        val driver = FakePaymentDriver(
            fillOk = true,
            readbacks = mapOf("cc-number" to "", "cc-exp" to "", "cc-csc" to "•••"),
        )
        val copy = WorkingCopy(
            "NUM".toCharArray(), "EXP".toCharArray(), "CVC".toCharArray(),
        )
        val out = executeS7WithStoredCopy(driver, copy, snap, 60000, 30000)
        check("s7-stored/advance-on-success", out is StepOutcome.Advance)
        check("s7-stored/copy-closed-after-advance",
            allZero(copy.cardNumber) && allZero(copy.expiry) && allZero(copy.cvv))
        val failingDriver = FakePaymentDriver(fillOk = false, readbacks = emptyMap())
        val copy2 = WorkingCopy(
            "NUM".toCharArray(), "EXP".toCharArray(), "CVC".toCharArray(),
        )
        val out2 = executeS7WithStoredCopy(failingDriver, copy2, snap, 60000, 30000)
        check("s7-stored/fill-fail-pause-E15",
            out2 is StepOutcome.Pause && out2.errorId == "E15")
        check("s7-stored/copy-closed-after-failure",
            allZero(copy2.cardNumber) && allZero(copy2.expiry) && allZero(copy2.cvv))
    }

    // ---------- D-54 clock carry-over ----------
    run {
        var now = 1000L
        val s = CardSession(clock = { now })
        s.begin()
        now = 5000
        check("clock/absolute-elapsed", s.absoluteElapsedMs() == 4000L)
        check("clock/idle-elapsed", s.idleElapsedMs() == 4000L)
        s.put(CardValidator.Field.CARD_NUMBER, "X".toCharArray())
        now = 6000
        check("clock/idle-resets-on-put", s.idleElapsedMs() == 1000L)
        check("clock/absolute-not-reset-on-put", s.absoluteElapsedMs() == 5000L)
    }
    run {
        var now = 10000L
        val s = CardSession(clock = { now })
        s.beginWithElapsed(200000, 60000)
        check("clock/beginWithElapsed-within-caps", s.checkTimeout() == null)
        check("clock/beginWithElapsed-elapsed",
            s.absoluteElapsedMs() == 200000L && s.idleElapsedMs() == 60000L)
    }
    run {
        var now = 10000L
        val s = CardSession(clock = { now })
        s.beginWithElapsed(400000, 0)
        check("clock/beginWithElapsed-absolute-timeout",
            s.checkTimeout() == CardSession.TimeoutKind.ABSOLUTE)
    }
    run {
        var now = 10000L
        val s = CardSession(clock = { now })
        s.beginWithElapsed(0, 130000)
        check("clock/beginWithElapsed-idle-timeout",
            s.checkTimeout() == CardSession.TimeoutKind.IDLE)
    }
    run {
        var now = 20000L
        var nextId = 0
        val repo = ProfileRepository(
            FileProfileBackend(tmpDir()), TestCrypto, { "id-${++nextId}" },
        )
        val session = CardSession(clock = { now })
        session.begin()
        session.put(CardValidator.Field.CARD_NUMBER, "DUMMY-NUMBER".toCharArray())
        session.put(CardValidator.Field.EXPIRY, "DUMMY-EXPIRY".toCharArray())
        session.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        now = 56000
        val outcome = saveS6InputAsProfile(repo, "Timed", product(), pickup(), session)
        check("save-elapsed/carried",
            outcome is SaveS6Outcome.Saved &&
                outcome.absoluteElapsedMs == 36000L &&
                outcome.idleElapsedMs == 36000L)
    }
    run {
        val snap = MachineSnapshot(
            step = PurchaseStep.S7_PAYMENT_FILL,
            global = GlobalState.RUNNING,
            submitted = false,
            needsRevalidation = false,
            isComplete = false,
            s7Unlocked = true,
            timeCheck = null,
        )
        val driver = FakePaymentDriver(
            fillOk = true,
            readbacks = mapOf("cc-number" to "", "cc-exp" to "", "cc-csc" to "•••"),
        )
        val overAbs = WorkingCopy(
            "NUM".toCharArray(), "EXP".toCharArray(), "CVC".toCharArray(),
        )
        val outAbs = executeS7WithStoredCopy(driver, overAbs, snap, 400000, 0)
        check("s7-stored/absolute-cap-timeout",
            outAbs is StepOutcome.Pause && outAbs.reason == "CARD_SESSION_TIMEOUT")
        check("s7-stored/absolute-cap-copy-closed",
            allZero(overAbs.cardNumber) && allZero(overAbs.expiry) && allZero(overAbs.cvv))
        val overIdle = WorkingCopy(
            "NUM".toCharArray(), "EXP".toCharArray(), "CVC".toCharArray(),
        )
        val outIdle = executeS7WithStoredCopy(driver, overIdle, snap, 0, 130000)
        check("s7-stored/idle-cap-timeout",
            outIdle is StepOutcome.Pause && outIdle.reason == "CARD_SESSION_TIMEOUT")
        val within = WorkingCopy(
            "NUM".toCharArray(), "EXP".toCharArray(), "CVC".toCharArray(),
        )
        val outWithin = executeS7WithStoredCopy(driver, within, snap, 200000, 60000)
        check("s7-stored/within-cap-advance", outWithin is StepOutcome.Advance)
    }
    run {
        var nextId = 0
        val repo = ProfileRepository(
            FileProfileBackend(tmpDir()), TestCrypto, { "id-${++nextId}" },
        )
        val session = CardSession()
        session.begin()
        session.put(CardValidator.Field.CARD_NUMBER, "DUMMY-NUMBER".toCharArray())
        session.put(CardValidator.Field.EXPIRY, "DUMMY-EXPIRY".toCharArray())
        session.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        var captured: Triple<WorkingCopy, Long, Long>? = null
        val callbacks = createS6SaveCallbacks(
            repo, product(), pickup(), session,
        ) { copy, abs, idle -> captured = Triple(copy, abs, idle) }
        check("factory/is-first-save-true", callbacks.isFirstSave())
        val saved = callbacks.onSaveProfile("Fac")
        check("factory/save-delegates", saved is SaveS6Outcome.Saved)
        if (saved is SaveS6Outcome.Saved) {
            callbacks.onSavedWithWorkingCopy(
                saved.copy, saved.absoluteElapsedMs, saved.idleElapsedMs,
            )
        }
        check("factory/is-first-save-false-after", !callbacks.isFirstSave())
        check("factory/on-saved-passthrough",
            captured != null && String(captured!!.first.cardNumber) == "DUMMY-NUMBER" &&
                captured!!.second >= 0 && captured!!.third >= 0)
        captured?.first?.close()
    }

    // ---------- D-57 edit: full read + update ----------
    run {
        var nextId = 0
        val repo = ProfileRepository(
            FileProfileBackend(tmpDir()), TestCrypto, { "id-${++nextId}" },
        )
        val saved = repo.saveProfile(input("Editable")) as SaveOutcome.Saved
        val loaded = repo.loadForEdit(saved.id)
        check("edit/load-ok", loaded is EditLoadOutcome.Ok)
        if (loaded is EditLoadOutcome.Ok) {
            check("edit/load-fields",
                loaded.profile.name == "Editable" &&
                    loaded.profile.product.model == "MODEL" &&
                    loaded.profile.pickup.method == "pickup" &&
                    String(loaded.profile.cardNumber) == "DUMMY-NUMBER" &&
                    String(loaded.profile.expiry) == "DUMMY-EXPIRY")
            loaded.profile.clear()
            check("edit/load-clear-zeroes",
                loaded.profile.cardNumber.all { it == '\u0000' } &&
                    loaded.profile.expiry.all { it == '\u0000' })
            val updated = repo.updateProfile(saved.id, ProfileInput(
                "Edited", ProductGroup("ModelY", "Blue", "256GB", 3, appleCare = true),
                pickup(), "DUMMY-CARD-7777".toCharArray(), "DUMMY-EXPIRY".toCharArray(),
            ))
            check("edit/update-saved", updated is SaveOutcome.Saved)
        }
        val summaries = repo.listProfiles()
        check("edit/list-reflects-update",
            summaries.single().name == "Edited" && summaries.single().cardLast4 == "7777")
        val reloaded = repo.loadForEdit(saved.id)
        check("edit/reload-updated",
            reloaded is EditLoadOutcome.Ok &&
                reloaded.profile.product.model == "ModelY" &&
                reloaded.profile.product.quantity == 3 &&
                reloaded.profile.product.appleCare == true &&
                String(reloaded.profile.cardNumber) == "DUMMY-CARD-7777")
        if (reloaded is EditLoadOutcome.Ok) {
            reloaded.profile.clear()
        }
        check("edit/load-missing-notfound",
            repo.loadForEdit("no-such-id") is EditLoadOutcome.NotFound)
        repo.deleteProfile(saved.id)
        check("edit/update-after-delete-notfound",
            repo.updateProfile(saved.id, input("Edited")) ==
                SaveOutcome.Blocked(SaveBlock.NOT_FOUND))
        check("edit/load-after-delete-notfound",
            repo.loadForEdit(saved.id) is EditLoadOutcome.NotFound)
    }
    run {
        var nextId = 0
        val backend = FileProfileBackend(tmpDir())
        val repoOk = ProfileRepository(backend, TestCrypto, { "id-${++nextId}" })
        val saved = repoOk.saveProfile(input("CryptFail")) as SaveOutcome.Saved
        val failAll = object : Crypto {
            override fun encrypt(plain: CharArray): ByteArray =
                String(plain).toByteArray(Charsets.UTF_8)
            override fun decrypt(cipher: ByteArray): CharArray =
                throw RuntimeException("boom")
        }
        val repoFail = ProfileRepository(backend, failAll, { "id-x" })
        check("edit/load-decrypt-fail",
            repoFail.loadForEdit(saved.id) is EditLoadOutcome.DecryptionFailed)
        val failExpiry = object : Crypto {
            override fun encrypt(plain: CharArray): ByteArray =
                String(plain).toByteArray(Charsets.UTF_8)
            override fun decrypt(cipher: ByteArray): CharArray {
                val s = String(cipher, Charsets.UTF_8)
                if (s.contains("EXPIRY")) throw RuntimeException("boom")
                return s.toCharArray()
            }
        }
        val repoFailExpiry = ProfileRepository(backend, failExpiry, { "id-x" })
        check("edit/load-expiry-decrypt-fail",
            repoFailExpiry.loadForEdit(saved.id) is EditLoadOutcome.DecryptionFailed)
        check("edit/profile-untouched-after-fail",
            repoOk.listProfiles().single().name == "CryptFail")
    }

    // ---------- storage write failure (D-66/D-67/D-68) ----------
    run {
        var nextId = 0
        val dir = tmpDir()
        val real = FileProfileBackend(dir)
        val repoOk = ProfileRepository(real, TestCrypto, { "id-${++nextId}" })
        val saved = repoOk.saveProfile(input("WriteBase")) as SaveOutcome.Saved
        val failSave = object : ProfileBackend {
            override fun loadAll(): List<StoredProfile> = real.loadAll()
            override fun saveAll(profiles: List<StoredProfile>) {
                throw java.io.IOException("disk full (test)")
            }
        }
        val repoFail = ProfileRepository(failSave, TestCrypto, { "id-x" })
        check("writefail/save-returns-outcome-not-throw",
            repoFail.saveProfile(input("WriteNew")) ==
                SaveOutcome.StorageWriteFailed)
        check("writefail/update-returns-outcome-not-throw",
            repoFail.updateProfile(saved.id, input("WriteRenamed")) ==
                SaveOutcome.StorageWriteFailed)
        check("writefail/original-still-listed",
            repoOk.listProfiles().map { it.name } == listOf("WriteBase"))
        // S6 caller: re-list verifies absence -> verified outcome.
        val session = CardSession()
        session.begin()
        session.put(CardValidator.Field.CARD_NUMBER, "DUMMY-NUMBER".toCharArray())
        session.put(CardValidator.Field.EXPIRY, "DUMMY-EXPIRY".toCharArray())
        session.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        check("writefail/s6-verified-absent",
            saveS6InputAsProfile(repoFail, "WriteNew", product(), pickup(), session) ==
                SaveS6Outcome.StorageWriteFailedAfterBorrow)
        check("writefail/s6-session-ended", !session.isActive)
        // S6 caller: listing itself fails -> unverifiable outcome.
        // Loads: 1 = S6 pre-check, 2 = saveProfile's own
        // validation list, 3 = the D-67 re-list (fails here).
        var loads = 0
        val failListAfterFirst = object : ProfileBackend {
            override fun loadAll(): List<StoredProfile> {
                loads++
                if (loads > 2) throw java.io.IOException("list failed (test)")
                return real.loadAll()
            }
            override fun saveAll(profiles: List<StoredProfile>) {
                throw java.io.IOException("disk full (test)")
            }
        }
        val repoUnverifiable = ProfileRepository(
            failListAfterFirst, TestCrypto, { "id-y" },
        )
        val session2 = CardSession()
        session2.begin()
        session2.put(CardValidator.Field.CARD_NUMBER, "DUMMY-NUMBER".toCharArray())
        session2.put(CardValidator.Field.EXPIRY, "DUMMY-EXPIRY".toCharArray())
        session2.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        check("writefail/s6-unverifiable",
            saveS6InputAsProfile(repoUnverifiable, "WriteNew", product(), pickup(), session2) ==
                SaveS6Outcome.StorageWriteUnverifiableAfterBorrow)
    }

    // ---------- S6SaveCallbacks factory (D-54 host wiring) ----------
    run {
        var nextId = 0
        val repo = ProfileRepository(
            FileProfileBackend(tmpDir()), TestCrypto, { "id-${++nextId}" },
        )
        val emptyCb = createS6SaveCallbacks(
            repo, product(), pickup(), CardSession(),
        ) { _, _, _ -> }
        check("savecb/first-save-empty", emptyCb.isFirstSave())
        val session = CardSession()
        session.begin()
        session.put(CardValidator.Field.CARD_NUMBER, "DUMMY-NUMBER".toCharArray())
        session.put(CardValidator.Field.EXPIRY, "DUMMY-EXPIRY".toCharArray())
        session.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        var got: Triple<WorkingCopy, Long, Long>? = null
        val cb = createS6SaveCallbacks(
            repo, product(), pickup(), session,
        ) { copy, abs, idle -> got = Triple(copy, abs, idle) }
        val outcome = cb.onSaveProfile("Factory")
        check("savecb/save-saved", outcome is SaveS6Outcome.Saved)
        if (outcome is SaveS6Outcome.Saved) {
            cb.onSavedWithWorkingCopy(
                outcome.copy,
                outcome.absoluteElapsedMs,
                outcome.idleElapsedMs,
            )
        }
        check("savecb/continuation-receives-copy", got != null)
        check("savecb/no-longer-first", !cb.isFirstSave())
        check("savecb/session-ended-by-borrow", !session.isActive)
    }

    // ---------- delete caller verification (D-73/D-74/D-76) ----------
    run {
        // Pure helper: the five D-74 outcomes. The Compose
        // dialog itself is Android-only and uncompiled; this
        // helper is the exact decision it branches on.
        val target = ProfileSummary("id-t", "Target", "0000")
        val other = ProfileSummary("id-o", "Other", "1111")
        check("delete/verified-others-present",
            verifyDeleteAfterWriteFailure("id-t", 2, listOf(other)) ==
                DeleteVerification.VerifiedDeleted)
        check("delete/verified-last-combination",
            verifyDeleteAfterWriteFailure("id-t", 1, emptyList()) ==
                DeleteVerification.VerifiedDeleted)
        check("delete/store-file-lost",
            verifyDeleteAfterWriteFailure("id-t", 3, emptyList()) ==
                DeleteVerification.StoreFileLost)
        check("delete/still-present",
            verifyDeleteAfterWriteFailure("id-t", 2, listOf(target, other)) ==
                DeleteVerification.StillPresent)
        check("delete/unverifiable",
            verifyDeleteAfterWriteFailure("id-t", 2, null) ==
                DeleteVerification.Unverifiable)
    }
    run {
        // Repository delete paths (Water D-75 part, exercised
        // through the caller test): existing delete, the
        // D-76 silent no-op for a nonexistent id, and both
        // WriteFailed arms.
        var nextId = 0
        val dir = tmpDir()
        val real = FileProfileBackend(dir)
        val repo = ProfileRepository(real, TestCrypto, { "id-${++nextId}" })
        val a = repo.saveProfile(input("DelA")) as SaveOutcome.Saved
        val b = repo.saveProfile(input("DelB")) as SaveOutcome.Saved
        check("delete/existing-deleted",
            repo.deleteProfile(a.id) == DeleteOutcome.Deleted &&
                repo.listProfiles().map { it.id } == listOf(b.id))
        check("delete/nonexistent-silent-noop",
            repo.deleteProfile("no-such-id") == DeleteOutcome.Deleted &&
                repo.listProfiles().map { it.id } == listOf(b.id))
        val failLoad = object : ProfileBackend {
            override fun loadAll(): List<StoredProfile> =
                throw java.io.IOException("load failed (test)")
            override fun saveAll(profiles: List<StoredProfile>) {
                real.saveAll(profiles)
            }
        }
        val repoFailLoad = ProfileRepository(failLoad, TestCrypto, { "id-x" })
        check("delete/load-failure-writefailed",
            repoFailLoad.deleteProfile(b.id) == DeleteOutcome.WriteFailed)
        val failSave = object : ProfileBackend {
            override fun loadAll(): List<StoredProfile> = real.loadAll()
            override fun saveAll(profiles: List<StoredProfile>) {
                throw java.io.IOException("disk full (test)")
            }
        }
        val repoFailSave = ProfileRepository(failSave, TestCrypto, { "id-x" })
        check("delete/save-failure-writefailed",
            repoFailSave.deleteProfile(b.id) == DeleteOutcome.WriteFailed)
        check("delete/untouched-after-failures",
            repo.listProfiles().map { it.id } == listOf(b.id))
    }

    // ---------- pre-save list read failure (D-79) ----------
    run {
        fun filledSession(): CardSession {
            val s = CardSession()
            s.begin()
            s.put(CardValidator.Field.CARD_NUMBER, "DUMMY-NUMBER".toCharArray())
            s.put(CardValidator.Field.EXPIRY, "DUMMY-EXPIRY".toCharArray())
            s.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
            return s
        }
        // (1) Pre-check read fails (first load): no save
        // attempted, session fully intact.
        run {
            val real = FileProfileBackend(tmpDir())
            var loads = 0
            val failFirst = object : ProfileBackend {
                override fun loadAll(): List<StoredProfile> {
                    loads++
                    if (loads == 1) {
                        throw java.io.IOException("read failed (test)")
                    }
                    return real.loadAll()
                }
                override fun saveAll(profiles: List<StoredProfile>) {
                    real.saveAll(profiles)
                }
            }
            val repo = ProfileRepository(failFirst, TestCrypto, { "id-r1" })
            val session = filledSession()
            check("readfail/precheck-outcome",
                saveS6InputAsProfile(repo, "ReadOne", product(), pickup(), session) ==
                    SaveS6Outcome.PrecheckReadFailed)
            check("readfail/precheck-session-intact",
                session.isActive && session.hasAllFields())
            check("readfail/precheck-nothing-saved",
                ProfileRepository(real, TestCrypto, { "id-r1b" })
                    .listProfiles().isEmpty())
        }
        // (2) saveProfile's internal validation read fails
        // (second load): no write had occurred, but the
        // borrow ended the session.
        run {
            val real = FileProfileBackend(tmpDir())
            var loads = 0
            val failSecond = object : ProfileBackend {
                override fun loadAll(): List<StoredProfile> {
                    loads++
                    if (loads == 2) {
                        throw java.io.IOException("read failed (test)")
                    }
                    return real.loadAll()
                }
                override fun saveAll(profiles: List<StoredProfile>) {
                    real.saveAll(profiles)
                }
            }
            val repo = ProfileRepository(failSecond, TestCrypto, { "id-r2" })
            val session = filledSession()
            check("readfail/save-read-outcome",
                saveS6InputAsProfile(repo, "ReadTwo", product(), pickup(), session) ==
                    SaveS6Outcome.SaveReadFailedAfterBorrow)
            check("readfail/save-read-session-ended", !session.isActive)
            check("readfail/save-read-nothing-saved",
                ProfileRepository(real, TestCrypto, { "id-r2b" })
                    .listProfiles().isEmpty())
        }
        // (3) Materialize read fails (third load): the
        // combination WAS saved; outcome is the
        // materialize-failed one, not a raw throw.
        run {
            val real = FileProfileBackend(tmpDir())
            var loads = 0
            val failThird = object : ProfileBackend {
                override fun loadAll(): List<StoredProfile> {
                    loads++
                    if (loads == 3) {
                        throw java.io.IOException("read failed (test)")
                    }
                    return real.loadAll()
                }
                override fun saveAll(profiles: List<StoredProfile>) {
                    real.saveAll(profiles)
                }
            }
            val repo = ProfileRepository(failThird, TestCrypto, { "id-r3" })
            val session = filledSession()
            check("readfail/materialize-outcome",
                saveS6InputAsProfile(repo, "ReadThree", product(), pickup(), session) ==
                    SaveS6Outcome.MaterializeFailedAfterBorrow)
            check("readfail/materialize-combination-saved",
                ProfileRepository(real, TestCrypto, { "id-r3b" })
                    .listProfiles().map { it.name } == listOf("ReadThree"))
        }
        // (4) isFirstSave fail-safe: a throwing list read
        // reports "first save" (warning shown) instead of
        // throwing raw out of the tap handler.
        run {
            val failAll = object : ProfileBackend {
                override fun loadAll(): List<StoredProfile> =
                    throw java.io.IOException("read failed (test)")
                override fun saveAll(profiles: List<StoredProfile>) {}
            }
            val repo = ProfileRepository(failAll, TestCrypto, { "id-r4" })
            val cb = createS6SaveCallbacks(
                repo, product(), pickup(), CardSession(),
            ) { _, _, _ -> }
            check("readfail/isfirstsave-failsafe-true", cb.isFirstSave())
        }
    }

    // ---------- encryption failure (D-53 reservation (5) supplement) ----------
    run {
        var nextId = 0
        val backend = FileProfileBackend(tmpDir())
        val repoOk = ProfileRepository(backend, TestCrypto, { "id-${++nextId}" })
        val saved = repoOk.saveProfile(input("EncBase")) as SaveOutcome.Saved
        val failEncrypt = object : Crypto {
            override fun encrypt(plain: CharArray): ByteArray =
                throw RuntimeException("boom")
            override fun decrypt(cipher: ByteArray): CharArray =
                String(cipher, Charsets.UTF_8).toCharArray()
        }
        val repoBad = ProfileRepository(backend, failEncrypt, { "id-x" })
        check("enc/save-encryption-failed",
            repoBad.saveProfile(input("EncNew")) == SaveOutcome.EncryptionFailed)
        check("enc/update-encryption-failed",
            repoBad.updateProfile(saved.id, input("EncRenamed")) ==
                SaveOutcome.EncryptionFailed)
        check("enc/nothing-written-original-kept",
            repoOk.listProfiles().map { it.name } == listOf("EncBase"))
    }

    if (failures == 0) println("ALL TESTS PASSED") else println("FAILURES: $failures")
}
