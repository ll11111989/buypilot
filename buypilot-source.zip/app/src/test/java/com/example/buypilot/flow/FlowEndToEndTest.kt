package com.example.buypilot.flow

import com.example.buypilot.integration.FileProfileBackend
import com.example.buypilot.payment.CardSession
import com.example.buypilot.payment.CardValidator
import com.example.buypilot.state.GlobalState
import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.PurchaseStep
import com.example.buypilot.state.StepOutcome
import com.example.buypilot.steps.ElementInfo
import com.example.buypilot.steps.FakePageDriver
import com.example.buypilot.steps.PageElements
import com.example.buypilot.steps.PageModel
import com.example.buypilot.steps.PageState
import com.example.buypilot.steps.PaymentFieldFact
import com.example.buypilot.steps.PaymentFields
import com.example.buypilot.steps.ResultStatus
import com.example.buypilot.steps.StoreOption
import com.example.buypilot.steps.SummaryData
import com.example.buypilot.storage.Crypto
import com.example.buypilot.storage.PickupGroup
import com.example.buypilot.storage.ProductGroup
import com.example.buypilot.storage.ProfileInput
import com.example.buypilot.storage.ProfileRepository
import com.example.buypilot.storage.SaveOutcome
import com.example.buypilot.storage.WorkingCopy
import java.io.File

/**
 * Flow-layer end-to-end tests (JVM, offline fixtures only).
 *
 * The complete S1→S9 flow runs against the FakePageDriver's
 * offline page models. Page transitions that no handler owns
 * (payment page after fulfillment, submit-confirm page after
 * the S7 fill, result page after dispatch) are fixture-driven
 * via setModel between steps — exactly the transitions a real
 * page would perform on its own; the flow layer invents no
 * clicks for them. All card values are non-numeric dummy text;
 * output is test names and counts only — zero card values.
 */

private var failures = 0

private fun check(name: String, condition: Boolean) {
    if (condition) {
        println("PASS $name")
    } else {
        println("FAIL $name")
        failures++
    }
}

private object TestCrypto : Crypto {
    override fun encrypt(plain: CharArray): ByteArray =
        String(plain).toByteArray(Charsets.UTF_8)
    override fun decrypt(cipher: ByteArray): CharArray =
        String(cipher, Charsets.UTF_8).toCharArray()
}

private fun tmpDir(): File {
    val dir = File(
        System.getProperty("java.io.tmpdir"),
        "buypilot-flow-test-" + System.nanoTime(),
    )
    dir.mkdirs()
    return dir
}

private fun el(text: String? = null) = ElementInfo(1, true, text)

private val mEntry = PageModel(
    pageState = PageState.ENTRY,
    elements = mapOf(
        PageElements.ENTRY_CONTINUE to el(),
        PageElements.PRODUCT_NAVIGATE to el(),
    ),
)
private val mProduct = PageModel(
    pageState = PageState.PRODUCT,
    elements = mapOf(
        PageElements.PRICE to el("PRICE-TEXT"),
        PageElements.PRODUCT_SELECT to el(),
    ),
)
private val mProductConfigured = PageModel(
    pageState = PageState.PRODUCT,
    configuredProductKey = "PK",
    elements = mapOf(
        PageElements.PRICE to el("PRICE-TEXT"),
        PageElements.ADD_TO_BAG to el(),
    ),
)
private val mBag = PageModel(
    pageState = PageState.BAG,
    bagProductKey = "PK",
    bagQuantity = 1,
    elements = mapOf(PageElements.CHECKOUT_BUTTON to el()),
)
private val mCheckout = PageModel(
    pageState = PageState.CHECKOUT,
    storeOptions = listOf(StoreOption("STORE-A", true)),
    elements = mapOf(PageElements.STORE_SELECT to el()),
)
private val mPayment = PageModel(
    pageState = PageState.PAYMENT,
    paymentFields = PaymentFields.REQUIRED.map { PaymentFieldFact(it, 1, true) },
)
private val mSubmit = PageModel(
    pageState = PageState.SUBMIT_CONFIRM,
    summaryProductKey = "PK",
    summaryTotalText = "TOTAL-TEXT",
    summaryPickupText = "PICKUP-TEXT",
    elements = mapOf(FlowElements.SUBMIT_BUTTON to el()),
)
private val mResult = PageModel(
    pageState = PageState.RESULT,
    resultStatus = ResultStatus.SUCCESS,
)

private fun scriptedDriver(readBackOverrides: Map<String, String?> = emptyMap()) =
    FakePageDriver(
        initial = mEntry,
        clickEffects = mapOf(
            PageElements.PRODUCT_NAVIGATE to mProduct,
            PageElements.PRODUCT_SELECT to mProductConfigured,
            PageElements.ADD_TO_BAG to mBag,
            PageElements.CHECKOUT_BUTTON to mCheckout,
        ),
        readBackOverrides = readBackOverrides,
    )

private fun flowConfig(selectedProfileId: String? = null) = FlowConfig(
    productKey = "PK",
    priorityStores = listOf("STORE-A"),
    summary = SummaryData("PK", "TOTAL-TEXT", "PICKUP-TEXT"),
    selectedProfileId = selectedProfileId,
)

private fun fillSession(session: CardSession) {
    session.begin()
    session.put(CardValidator.Field.CARD_NUMBER, "DUMMY-NUMBER".toCharArray())
    session.put(CardValidator.Field.EXPIRY, "DUMMY-EXPIRY".toCharArray())
    session.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
}

fun main() {
    // ---------- manual path: complete S1→S9 ----------
    run {
        val driver = scriptedDriver()
        val session = CardSession()
        val run = buildFlow(driver, flowConfig(), session, null, s7Unlocked = true)
        check("manual/start", run.machine.start())
        val head = runFlowUntilStop(run)
        check("manual/head-stops-at-s6",
            head is StepOutcome.Pause && head.reason == "S6_INPUT_INCOMPLETE" &&
                run.machine.currentStep == PurchaseStep.S6_PAYMENT_INPUT &&
                run.machine.globalState == GlobalState.STOPPED)
        fillSession(session)
        driver.setModel(mPayment)
        check("manual/resume", run.machine.resumeFromStopped())
        check("manual/s6-advance",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                run.machine.currentStep == PurchaseStep.S7_PAYMENT_FILL)
        check("manual/s7-advance",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                run.machine.currentStep == PurchaseStep.S8_SUBMIT_CONFIRM)
        check("manual/s7-filled-3-fields",
            driver.fillCount(PaymentFields.NUMBER) == 1 &&
                driver.fillCount(PaymentFields.EXPIRY) == 1 &&
                driver.fillCount(PaymentFields.CVV) == 1)
        driver.setModel(mSubmit)
        check("manual/s8-dispatch-advance",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                run.machine.submitted &&
                run.machine.currentStep == PurchaseStep.S9_RESULT)
        driver.setModel(mResult)
        check("manual/s9-complete",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                run.machine.isComplete)
    }

    // ---------- stored path: complete S1→S9 ----------
    run {
        var nextId = 0
        val repo = ProfileRepository(
            FileProfileBackend(tmpDir()), TestCrypto, { "id-${++nextId}" },
        )
        val saved = repo.saveProfile(
            ProfileInput(
                "Stored",
                ProductGroup("MODEL", "COLOUR", "CAP", 1),
                PickupGroup("pickup", listOf("STORE-A")),
                "DUMMY-NUMBER".toCharArray(),
                "DUMMY-EXPIRY".toCharArray(),
            ),
        ) as SaveOutcome.Saved
        val driver = scriptedDriver()
        val session = CardSession()
        session.begin()
        session.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        val run = buildFlow(
            driver, flowConfig(saved.id), session, repo, s7Unlocked = true,
        )
        check("stored/start", run.machine.start())
        runFlowUntilStop(run, maxSteps = 6)
        check("stored/head-at-s6-running",
            run.machine.currentStep == PurchaseStep.S6_PAYMENT_INPUT &&
                run.machine.globalState == GlobalState.RUNNING)
        driver.setModel(mPayment)
        check("stored/s6-materialize-advance",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                !session.isActive &&
                run.state.storedWorkingCopy != null)
        check("stored/s7-advance",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                run.machine.currentStep == PurchaseStep.S8_SUBMIT_CONFIRM)
        check("stored/s7-filled-from-copy",
            driver.fillCount(PaymentFields.NUMBER) == 1 &&
                driver.fillCount(PaymentFields.CVV) == 1)
        driver.setModel(mSubmit)
        check("stored/s8-dispatch",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                run.machine.submitted)
        driver.setModel(mResult)
        check("stored/s9-complete",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                run.machine.isComplete)
    }

    // ---------- S7 locked: the product default ----------
    run {
        val driver = scriptedDriver()
        val session = CardSession()
        val run = buildFlow(driver, flowConfig(), session, null, s7Unlocked = false)
        run.machine.start()
        runFlowUntilStop(run)
        fillSession(session)
        driver.setModel(mPayment)
        run.machine.resumeFromStopped()
        check("locked/s6-advance",
            run.machine.executeCurrentStep() == StepOutcome.Advance)
        val outcome = run.machine.executeCurrentStep()
        check("locked/s7-never-entered",
            outcome is StepOutcome.Pause && outcome.reason == "S7_LOCKED" &&
                run.machine.globalState == GlobalState.STOPPED &&
                driver.fillCount(PaymentFields.NUMBER) == 0 &&
                driver.fillCount(PaymentFields.CVV) == 0)
    }

    // ---------- unverified fields: S8 lists, host confirms ----------
    run {
        val driver = scriptedDriver(readBackOverrides = mapOf(PaymentFields.CVV to null))
        val session = CardSession()
        val run = buildFlow(driver, flowConfig(), session, null, s7Unlocked = true)
        run.machine.start()
        runFlowUntilStop(run)
        fillSession(session)
        driver.setModel(mPayment)
        run.machine.resumeFromStopped()
        run.machine.executeCurrentStep()
        check("unverified/s7-advance-with-report",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                run.state.unverifiedFieldCodes == listOf(PaymentFields.CVV))
        driver.setModel(mSubmit)
        val stay = run.machine.executeCurrentStep()
        check("unverified/s8-stays-and-lists",
            stay == StepOutcome.Stay && !run.machine.submitted &&
                run.state.lastUnverifiedListed == listOf(PaymentFields.CVV) &&
                run.machine.currentStep == PurchaseStep.S8_SUBMIT_CONFIRM)
        run.state.confirmUnverified(listOf(PaymentFields.CVV))
        check("unverified/s8-dispatch-after-confirm",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                run.machine.submitted)
    }

    // ---------- FlowS6Handler stored failures (direct) ----------
    run {
        val snap = MachineSnapshot(
            step = PurchaseStep.S6_PAYMENT_INPUT,
            global = GlobalState.RUNNING,
            submitted = false,
            needsRevalidation = false,
            isComplete = false,
            s7Unlocked = true,
            timeCheck = null,
        )
        var nextId = 0
        val backend = FileProfileBackend(tmpDir())
        val repoOk = ProfileRepository(backend, TestCrypto, { "id-${++nextId}" })
        val saved = repoOk.saveProfile(
            ProfileInput(
                "Stored",
                ProductGroup("MODEL", "COLOUR", "CAP", 1),
                PickupGroup("pickup", listOf("STORE-A")),
                "DUMMY-NUMBER".toCharArray(),
                "DUMMY-EXPIRY".toCharArray(),
            ),
        ) as SaveOutcome.Saved
        val failCrypto = object : Crypto {
            override fun encrypt(plain: CharArray): ByteArray =
                String(plain).toByteArray(Charsets.UTF_8)
            override fun decrypt(cipher: ByteArray): CharArray =
                throw RuntimeException("boom")
        }
        val repoFail = ProfileRepository(backend, failCrypto, { "id-x" })
        val session = CardSession()
        session.begin()
        session.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        val decryptHandler = FlowS6Handler(
            session, repoFail, FlowRuntimeState(saved.id),
        )
        val decryptOutcome = decryptHandler.execute(snap)
        check("s6fail/decryption-failed-pause",
            decryptOutcome is StepOutcome.Pause &&
                decryptOutcome.reason == "PROFILE_DECRYPTION_FAILED" &&
                session.isActive)
        val missingHandler = FlowS6Handler(
            session, repoOk, FlowRuntimeState("no-such-id"),
        )
        val missingOutcome = missingHandler.execute(snap)
        check("s6fail/not-found-pause",
            missingOutcome is StepOutcome.Pause &&
                missingOutcome.reason == "PROFILE_NOT_FOUND")
    }

    // ---------- D-63 stored retry: detection fail, re-materialize, success ----------
    run {
        var nextId = 0
        val repo = ProfileRepository(
            FileProfileBackend(tmpDir()), TestCrypto, { "id-${++nextId}" },
        )
        val saved = repo.saveProfile(
            ProfileInput(
                "Stored",
                ProductGroup("MODEL", "COLOUR", "CAP", 1),
                PickupGroup("pickup", listOf("STORE-A")),
                "DUMMY-NUMBER".toCharArray(),
                "DUMMY-EXPIRY".toCharArray(),
            ),
        ) as SaveOutcome.Saved
        val driver = scriptedDriver()
        val session = CardSession()
        session.begin()
        session.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        val run = buildFlow(
            driver, flowConfig(saved.id), session, repo, s7Unlocked = true,
        )
        run.machine.start()
        runFlowUntilStop(run, maxSteps = 6)
        // S6 materializes first; then attempt 1 runs on a
        // payment page that reports no fields -> detection
        // Pause, copy consumed by the wrapper's finally.
        driver.setModel(PageModel(pageState = PageState.PAYMENT))
        run.machine.executeCurrentStep()
        val attempt1 = run.machine.executeCurrentStep()
        check("retry-stored/attempt1-detection-pause",
            attempt1 is StepOutcome.Pause &&
                attempt1.reason == "PAYMENT_FIELD_MISSING" &&
                run.state.s7Attempts == 1 &&
                run.state.storedWorkingCopy == null)
        // Retry: top up CVV only, re-materialize, attempt 2 fills.
        val topUp = CardSession()
        topUp.begin()
        topUp.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        check("retry-stored/supply-ok",
            supplyStoredRetryCvv(run, topUp, repo) &&
                run.state.storedWorkingCopy != null)
        check("retry-stored/top-up-session-ended", !topUp.isActive)
        run.machine.resumeFromStopped()
        driver.setModel(mPayment)
        check("retry-stored/attempt2-advance",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                run.state.s7Attempts == 2 &&
                driver.fillCount(PaymentFields.NUMBER) == 1)
    }

    // ---------- D-63 retry limit: 3 attempts, no 4th fill ----------
    run {
        var nextId = 0
        val repo = ProfileRepository(
            FileProfileBackend(tmpDir()), TestCrypto, { "id-${++nextId}" },
        )
        val saved = repo.saveProfile(
            ProfileInput(
                "Stored",
                ProductGroup("MODEL", "COLOUR", "CAP", 1),
                PickupGroup("pickup", listOf("STORE-A")),
                "DUMMY-NUMBER".toCharArray(),
                "DUMMY-EXPIRY".toCharArray(),
            ),
        ) as SaveOutcome.Saved
        val driver = scriptedDriver()
        val session = CardSession()
        session.begin()
        session.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        val run = buildFlow(
            driver, flowConfig(saved.id), session, repo, s7Unlocked = true,
        )
        run.machine.start()
        runFlowUntilStop(run, maxSteps = 6)
        driver.setModel(PageModel(pageState = PageState.PAYMENT))
        run.machine.executeCurrentStep()
        repeat(3) { i ->
            if (i > 0) {
                val topUp = CardSession()
                topUp.begin()
                topUp.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
                supplyStoredRetryCvv(run, topUp, repo)
                run.machine.resumeFromStopped()
            }
            run.machine.executeCurrentStep()
        }
        check("retry-limit/three-attempts-used", run.state.s7Attempts == 3)
        val topUp = CardSession()
        topUp.begin()
        topUp.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        supplyStoredRetryCvv(run, topUp, repo)
        run.machine.resumeFromStopped()
        driver.setModel(mPayment)
        val limited = run.machine.executeCurrentStep()
        check("retry-limit/fourth-blocked-no-fill",
            limited is StepOutcome.Pause &&
                limited.reason == "S7_RETRY_LIMIT_EXCEEDED" &&
                run.state.s7Attempts == 3 &&
                driver.fillCount(PaymentFields.NUMBER) == 0 &&
                run.state.storedWorkingCopy != null)
    }

    // ---------- D-63 manual retry: consumed session, re-input, attempt 2 ----------
    run {
        val driver = FakePageDriver(
            mEntry,
            clickEffects = mapOf(
                PageElements.PRODUCT_NAVIGATE to mProduct,
                PageElements.PRODUCT_SELECT to mProductConfigured,
                PageElements.ADD_TO_BAG to mBag,
                PageElements.CHECKOUT_BUTTON to mCheckout,
            ),
            fillRefusals = setOf(PaymentFields.NUMBER),
        )
        val session = CardSession()
        val run = buildFlow(driver, flowConfig(), session, null, s7Unlocked = true)
        run.machine.start()
        runFlowUntilStop(run)
        fillSession(session)
        driver.setModel(mPayment)
        run.machine.resumeFromStopped()
        run.machine.executeCurrentStep()
        val failed = run.machine.executeCurrentStep()
        check("retry-manual/attempt1-fill-refused",
            failed is StepOutcome.Pause &&
                failed.reason == "PAYMENT_FILL_FAILED" &&
                run.state.s7Attempts == 1 &&
                !session.isActive)
        run.machine.resumeFromStopped()
        val consumed = run.machine.executeCurrentStep()
        check("retry-manual/consumed-state",
            consumed is StepOutcome.Pause &&
                consumed.reason == "S7_DATA_CONSUMED" &&
                run.state.s7Attempts == 1)
        fillSession(session)
        run.machine.resumeFromStopped()
        val failed2 = run.machine.executeCurrentStep()
        check("retry-manual/attempt2-counted",
            failed2 is StepOutcome.Pause &&
                failed2.reason == "PAYMENT_FILL_FAILED" &&
                run.state.s7Attempts == 2)
    }

    // ---------- D-61 (3): S8 submit click explicit false ----------
    run {
        val driver = scriptedDriver()
        val session = CardSession()
        val run = buildFlow(driver, flowConfig(), session, null, s7Unlocked = true)
        run.machine.start()
        runFlowUntilStop(run)
        fillSession(session)
        driver.setModel(mPayment)
        run.machine.resumeFromStopped()
        run.machine.executeCurrentStep()
        run.machine.executeCurrentStep()
        val noButton = mSubmit.copy(
            elements = emptyMap(),
        )
        driver.setModel(noButton)
        val outcome = runFlowUntilStop(run)
        check("s8-click-false/pause-not-submitted",
            outcome is StepOutcome.Pause &&
                outcome.reason == "S8_SUBMIT_CLICK_FAILED" &&
                !run.machine.submitted &&
                run.machine.currentStep == PurchaseStep.S8_SUBMIT_CONFIRM &&
                run.machine.globalState == GlobalState.STOPPED)
    }

    // ---------- S6 button-saved continuation: stashed copy advances S6 ----------
    run {
        val driver = scriptedDriver()
        val session = CardSession()
        val run = buildFlow(driver, flowConfig(), session, null, s7Unlocked = true)
        run.machine.start()
        runFlowUntilStop(run)
        check("savebtn/s6-stops-incomplete",
            run.machine.currentStep == PurchaseStep.S6_PAYMENT_INPUT)
        // Host continuation (save button): stash copy + clocks.
        run.state.storedWorkingCopy = WorkingCopy(
            "DUMMY-NUMBER".toCharArray(),
            "DUMMY-EXPIRY".toCharArray(),
            "DUMMY-CVV".toCharArray(),
        )
        run.state.storedAbsoluteElapsedMs = 1000L
        run.state.storedIdleElapsedMs = 500L
        run.machine.resumeFromStopped()
        check("savebtn/s6-advance-on-stashed-copy",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                run.machine.currentStep == PurchaseStep.S7_PAYMENT_FILL)
    }

    // ---------- S7 button-saved continuation: stored branch from stashed copy ----------
    run {
        val driver = scriptedDriver()
        val session = CardSession()
        val run = buildFlow(driver, flowConfig(), session, null, s7Unlocked = true)
        run.machine.start()
        runFlowUntilStop(run)
        fillSession(session)
        driver.setModel(mPayment)
        run.machine.resumeFromStopped()
        run.machine.executeCurrentStep()
        check("savebtn/s7-head",
            run.machine.currentStep == PurchaseStep.S7_PAYMENT_FILL)
        // Borrow ended the session; host continuation stashed
        // the copy. S7 must take the stored branch from it,
        // not report the session as consumed.
        session.clear(CardSession.ClearTrigger.SESSION_ENDED)
        run.state.storedWorkingCopy = WorkingCopy(
            "DUMMY-NUMBER".toCharArray(),
            "DUMMY-EXPIRY".toCharArray(),
            "DUMMY-CVV".toCharArray(),
        )
        run.state.storedAbsoluteElapsedMs = 1000L
        run.state.storedIdleElapsedMs = 500L
        check("savebtn/s7-fill-from-stashed-copy",
            run.machine.executeCurrentStep() == StepOutcome.Advance &&
                driver.fillCount(PaymentFields.NUMBER) == 1 &&
                run.state.s7Attempts == 1)
    }

    // ---------- supplyStoredRetryCvv failure: deleted combination ----------
    run {
        val repo = ProfileRepository(
            FileProfileBackend(tmpDir()), TestCrypto, { "id-x" },
        )
        val driver = scriptedDriver()
        val session = CardSession()
        val run = buildFlow(
            driver, flowConfig("missing-id"), session, repo, s7Unlocked = true,
        )
        session.begin()
        session.put(CardValidator.Field.CVV, "DUMMY-CVV".toCharArray())
        check("retry-supply/missing-profile-false",
            !supplyStoredRetryCvv(run, session, repo))
    }

    if (failures == 0) println("ALL TESTS PASSED") else println("FAILURES: $failures")
}
