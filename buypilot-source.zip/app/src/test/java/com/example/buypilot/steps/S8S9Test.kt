package com.example.buypilot.steps

import com.example.buypilot.state.GlobalState
import com.example.buypilot.state.MachineSnapshot
import com.example.buypilot.state.PurchaseStep
import com.example.buypilot.state.StateMachine
import com.example.buypilot.state.StepHandler
import com.example.buypilot.state.StepOutcome

/**
 * JVM unit tests for the S8–S9 handlers and the D-21 core fix.
 *
 * Offline fixture only: every page state is scripted through
 * FakePageDriver, no real page is loaded, no URL is used, no
 * real order is placed and no real submit happens. The
 * "dispatch" in these tests is only the machine's submitted
 * flag being set through S8's onDispatch callback, as the
 * flow layer will do for a real page submit.
 * This file and its output contain no card values at all:
 * unverified fields are identified by field CODES only,
 * never by values.
 * Run: kotlinc the P2 state core + the steps sources (S1–S3,
 * S4–S5, S8–S9) + this file, execute S8S9TestKt. Output
 * prints test names only.
 */
private var failures = 0
private fun check(name: String, cond: Boolean) {
    println((if (cond) "PASS " else "FAIL ") + name)
    if (!cond) failures++
}

private fun snap(
    step: PurchaseStep,
    submitted: Boolean = false,
    needsRevalidation: Boolean = false,
): MachineSnapshot = MachineSnapshot(
    step = step,
    global = GlobalState.RUNNING,
    submitted = submitted,
    needsRevalidation = needsRevalidation,
    isComplete = false,
    s7Unlocked = false,
    timeCheck = null,
)

private fun submitModel(
    product: String? = "TEST-PRODUCT",
    total: String? = "TEST-TOTAL",
    pickup: String? = "TEST-PICKUP",
    soldOut: Boolean = false,
    rejected: Boolean = false,
) = PageModel(
    pageState = PageState.SUBMIT_CONFIRM,
    soldOut = soldOut,
    fulfillmentDataRejected = rejected,
    summaryProductKey = product,
    summaryTotalText = total,
    summaryPickupText = pickup,
)

private fun resultModel(status: ResultStatus?) = PageModel(
    pageState = PageState.RESULT,
    resultStatus = status,
)

private fun stateModel(state: PageState) = PageModel(pageState = state)

private val summary = SummaryData("TEST-PRODUCT", "TEST-TOTAL", "TEST-PICKUP")

private fun noUnverified() = S8UnverifiedStatus()

fun main() {
    // ---------- S8 direct ----------
    run {
        var dispatched = 0
        val driver = FakePageDriver(submitModel())
        val out = S8SubmitConfirmHandler(driver, summary, { noUnverified() }, { dispatched++ })
            .execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM))
        check("s8/summary-match-auto-advance-dispatch",
            out is StepOutcome.Advance && dispatched == 1)
    }
    run {
        var dispatched = 0
        val driver = FakePageDriver(submitModel(product = "OTHER-PRODUCT"))
        val out = S8SubmitConfirmHandler(driver, summary, { noUnverified() }, { dispatched++ })
            .execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM))
        check("s8/product-mismatch-E08-no-dispatch",
            out is StepOutcome.Pause && out.errorId == "E08" && dispatched == 0)
    }
    run {
        var dispatched = 0
        val driver = FakePageDriver(submitModel(total = "OTHER-TOTAL"))
        val out = S8SubmitConfirmHandler(driver, summary, { noUnverified() }, { dispatched++ })
            .execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM))
        check("s8/total-mismatch-E08-no-dispatch",
            out is StepOutcome.Pause && out.errorId == "E08" && dispatched == 0)
    }
    run {
        var dispatched = 0
        val driver = FakePageDriver(submitModel(product = null, total = null, pickup = null))
        val out = S8SubmitConfirmHandler(driver, summary, { noUnverified() }, { dispatched++ })
            .execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM))
        check("s8/summary-missing-E08-no-dispatch",
            out is StepOutcome.Pause && out.errorId == "E08" && dispatched == 0)
    }
    run {
        // D-36: unverified fields present and not item-confirmed
        // at all -> listed item by item, Stay, no dispatch.
        // (There is no general confirmation gate any more:
        // with no unverified fields the handler dispatches
        // automatically — see the summary-match test above.)
        var dispatched = 0
        var listed: List<String>? = null
        val driver = FakePageDriver(submitModel())
        val status = S8UnverifiedStatus(
            fieldCodes = listOf("cc-number"),
            confirmedCodes = emptySet(),
        )
        val out = S8SubmitConfirmHandler(
            driver, summary, { status }, { dispatched++ }, { listed = it },
        ).execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM))
        check("s8/unverified-unconfirmed-stay-listed-no-dispatch",
            out is StepOutcome.Stay && dispatched == 0 &&
                listed == listOf("cc-number"))
    }
    run {
        var dispatched = 0
        var listed: List<String>? = null
        val driver = FakePageDriver(submitModel())
        val status = S8UnverifiedStatus(
            fieldCodes = listOf("cc-number", "cc-exp"),
            confirmedCodes = setOf("cc-number"),
        )
        val out = S8SubmitConfirmHandler(
            driver, summary, { status }, { dispatched++ }, { listed = it },
        ).execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM))
        check("s8/unverified-partial-stay-listed-no-dispatch",
            out is StepOutcome.Stay && dispatched == 0 &&
                listed == listOf("cc-number", "cc-exp"))
    }
    run {
        var dispatched = 0
        var listed: List<String>? = null
        val driver = FakePageDriver(submitModel())
        val status = S8UnverifiedStatus(
            fieldCodes = listOf("cc-number", "cc-exp"),
            confirmedCodes = setOf("cc-number", "cc-exp"),
        )
        val out = S8SubmitConfirmHandler(
            driver, summary, { status }, { dispatched++ }, { listed = it },
        ).execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM))
        check("s8/unverified-fully-confirmed-advance",
            out is StepOutcome.Advance && dispatched == 1 && listed == null)
    }
    run {
        // Unverified status is re-asked per execute, never
        // cached: first call lists cc-exp unconfirmed, second
        // call has it item-confirmed and dispatches.
        var calls = 0
        var dispatched = 0
        val driver = FakePageDriver(submitModel())
        val handler = S8SubmitConfirmHandler(driver, summary, {
            calls++
            if (calls == 1) {
                S8UnverifiedStatus(
                    fieldCodes = listOf("cc-exp"),
                    confirmedCodes = emptySet(),
                )
            } else {
                S8UnverifiedStatus(
                    fieldCodes = listOf("cc-exp"),
                    confirmedCodes = setOf("cc-exp"),
                )
            }
        }, { dispatched++ })
        val first = handler.execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM))
        val second = handler.execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM, needsRevalidation = true))
        check("s8/unverified-status-reasked-per-execute",
            first is StepOutcome.Stay && second is StepOutcome.Advance &&
                calls == 2 && dispatched == 1)
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.QUEUE_OR_MAINTENANCE))
        val out = S8SubmitConfirmHandler(driver, summary, { noUnverified() }, {})
            .execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM))
        check("s8/queue-wait-E02",
            out is StepOutcome.Wait && out.errorId == "E02")
    }
    run {
        val driver = FakePageDriver(submitModel(soldOut = true))
        val out = S8SubmitConfirmHandler(driver, summary, { noUnverified() }, {})
            .execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM))
        check("s8/sold-out-E09",
            out is StepOutcome.Pause && out.errorId == "E09")
    }
    run {
        val driver = FakePageDriver(submitModel(rejected = true))
        val out = S8SubmitConfirmHandler(driver, summary, { noUnverified() }, {})
            .execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM))
        check("s8/fulfillment-rejected-E14",
            out is StepOutcome.Pause && out.errorId == "E14")
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.CHECKOUT))
        val out = S8SubmitConfirmHandler(driver, summary, { noUnverified() }, {})
            .execute(snap(PurchaseStep.S8_SUBMIT_CONFIRM))
        check("s8/wrong-page-E08",
            out is StepOutcome.Pause && out.errorId == "E08")
    }
    run {
        var threw = false
        try {
            S8SubmitConfirmHandler(FakePageDriver(submitModel()), SummaryData("", "T", "P"), { noUnverified() }, {})
        } catch (e: IllegalArgumentException) {
            threw = true
        }
        check("s8/blank-summary-refused-not-inferred", threw)
    }

    // ---------- S9 direct ----------
    run {
        val driver = FakePageDriver(resultModel(ResultStatus.SUCCESS))
        val out = S9ResultHandler(driver)
            .execute(snap(PurchaseStep.S9_RESULT, submitted = true))
        check("s9/success-advance", out is StepOutcome.Advance)
    }
    run {
        val driver = FakePageDriver(resultModel(ResultStatus.UNKNOWN))
        val out = S9ResultHandler(driver)
            .execute(snap(PurchaseStep.S9_RESULT, submitted = true))
        check("s9/unknown-fail-E18",
            out is StepOutcome.Fail && out.errorId == "E18")
    }
    run {
        val driver = FakePageDriver(resultModel(null))
        val out = S9ResultHandler(driver)
            .execute(snap(PurchaseStep.S9_RESULT, submitted = true))
        check("s9/no-result-fail-E18",
            out is StepOutcome.Fail && out.errorId == "E18")
    }
    run {
        val driver = FakePageDriver(resultModel(ResultStatus.PENDING))
        val out = S9ResultHandler(driver)
            .execute(snap(PurchaseStep.S9_RESULT, submitted = true))
        check("s9/pending-stay", out is StepOutcome.Stay)
    }
    run {
        val driver = FakePageDriver(resultModel(ResultStatus.DECLINED))
        val out = S9ResultHandler(driver)
            .execute(snap(PurchaseStep.S9_RESULT, submitted = true))
        check("s9/declined-handler-signals-decline",
            out is StepOutcome.Decline)
    }
    run {
        val driver = FakePageDriver(resultModel(ResultStatus.SUCCESS))
        val out = S9ResultHandler(driver)
            .execute(snap(PurchaseStep.S9_RESULT, submitted = false))
        check("s9/not-submitted-pause-E08",
            out is StepOutcome.Pause && out.errorId == "E08")
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.ERROR))
        val out = S9ResultHandler(driver)
            .execute(snap(PurchaseStep.S9_RESULT, submitted = true))
        check("s9/error-page-fail-E18",
            out is StepOutcome.Fail && out.errorId == "E18")
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.QUEUE_OR_MAINTENANCE))
        val out = S9ResultHandler(driver)
            .execute(snap(PurchaseStep.S9_RESULT, submitted = true))
        check("s9/queue-wait-E02",
            out is StepOutcome.Wait && out.errorId == "E02")
    }

    // ---------- machine: S7 lock is not bypassed ----------
    run {
        var s7Calls = 0
        val driver = FakePageDriver(submitModel())
        val machine = StateMachine(config = StateMachine.Config(s7Unlocked = false))
        for (step in PurchaseStep.entries) {
            machine.registerHandler(step, if (step == PurchaseStep.S7_PAYMENT_FILL) {
                StepHandler { s7Calls++; StepOutcome.Advance }
            } else {
                StepHandler { StepOutcome.Advance }
            })
        }
        machine.start()
        repeat(6) { machine.executeCurrentStep() }
        check("machine/locked-S7-reached", machine.currentStep == PurchaseStep.S7_PAYMENT_FILL)
        machine.executeCurrentStep()
        check("machine/locked-S7-stops-handler-not-called",
            machine.currentStep == PurchaseStep.S7_PAYMENT_FILL &&
                machine.globalState == GlobalState.STOPPED && s7Calls == 0)
    }

    // ---------- machine: unlocked test-only S8 -> S9 success ----------
    run {
        val driver = FakePageDriver(stateModel(PageState.ENTRY))
        val machine = StateMachine(
            config = StateMachine.Config(s7Unlocked = true),
        )
        for (step in PurchaseStep.entries) {
            if (step != PurchaseStep.S8_SUBMIT_CONFIRM && step != PurchaseStep.S9_RESULT) {
                machine.registerHandler(step, StepHandler { StepOutcome.Advance })
            }
        }
        machine.registerHandler(
            PurchaseStep.S8_SUBMIT_CONFIRM,
            S8SubmitConfirmHandler(driver, summary, { noUnverified() }, { machine.markSubmitted() }),
        )
        machine.registerHandler(PurchaseStep.S9_RESULT, S9ResultHandler(driver))
        machine.start()
        repeat(7) { machine.executeCurrentStep() }
        check("machine/test-only-to-S8", machine.currentStep == PurchaseStep.S8_SUBMIT_CONFIRM)
        driver.setModel(submitModel())
        machine.executeCurrentStep()
        check("machine/S8-dispatch-to-S9",
            machine.currentStep == PurchaseStep.S9_RESULT && machine.submitted)
        driver.setModel(resultModel(ResultStatus.SUCCESS))
        machine.executeCurrentStep()
        check("machine/S9-success-complete",
            machine.isComplete && machine.currentStep == PurchaseStep.S9_RESULT)
    }

    // ---------- machine: D-21 Pause / Block after submit -> UNKNOWN ----------
    run {
        val driver = FakePageDriver(stateModel(PageState.ENTRY))
        val machine = StateMachine(
            config = StateMachine.Config(s7Unlocked = true),
        )
        for (step in PurchaseStep.entries) {
            if (step != PurchaseStep.S8_SUBMIT_CONFIRM && step != PurchaseStep.S9_RESULT) {
                machine.registerHandler(step, StepHandler { StepOutcome.Advance })
            }
        }
        machine.registerHandler(
            PurchaseStep.S8_SUBMIT_CONFIRM,
            S8SubmitConfirmHandler(driver, summary, { noUnverified() }, { machine.markSubmitted() }),
        )
        machine.registerHandler(PurchaseStep.S9_RESULT, S9ResultHandler(driver))
        machine.start()
        repeat(7) { machine.executeCurrentStep() }
        driver.setModel(submitModel())
        machine.executeCurrentStep()
        check("machine/d21-setup-at-S9-submitted",
            machine.currentStep == PurchaseStep.S9_RESULT && machine.submitted)
        machine.registerHandler(
            PurchaseStep.S9_RESULT,
            StepHandler { StepOutcome.Pause(reason = "POST_SUBMIT_PAGE_ERROR") },
        )
        machine.executeCurrentStep()
        check("machine/d35-pause-after-submit-unknown-no-autoclear",
            machine.globalState == GlobalState.UNKNOWN)
    }
    run {
        val driver = FakePageDriver(stateModel(PageState.ENTRY))
        val machine = StateMachine(
            config = StateMachine.Config(s7Unlocked = true),
        )
        for (step in PurchaseStep.entries) {
            if (step != PurchaseStep.S8_SUBMIT_CONFIRM && step != PurchaseStep.S9_RESULT) {
                machine.registerHandler(step, StepHandler { StepOutcome.Advance })
            }
        }
        machine.registerHandler(
            PurchaseStep.S8_SUBMIT_CONFIRM,
            S8SubmitConfirmHandler(driver, summary, { noUnverified() }, { machine.markSubmitted() }),
        )
        machine.registerHandler(PurchaseStep.S9_RESULT, S9ResultHandler(driver))
        machine.start()
        repeat(7) { machine.executeCurrentStep() }
        driver.setModel(submitModel())
        machine.executeCurrentStep()
        machine.registerHandler(
            PurchaseStep.S9_RESULT,
            StepHandler { StepOutcome.Block(reason = "POST_SUBMIT_CAPTCHA", errorId = "E04") },
        )
        machine.executeCurrentStep()
        check("machine/d35-block-after-submit-unknown-no-autoclear",
            machine.globalState == GlobalState.UNKNOWN)
    }
    run {
        // Pause / Block BEFORE submit are unchanged by D-21.
        val machine = StateMachine()
        machine.registerHandler(
            PurchaseStep.S1_ENTRY,
            StepHandler { StepOutcome.Pause(reason = "PRE_SUBMIT_PAUSE") },
        )
        machine.start()
        machine.executeCurrentStep()
        check("machine/d21-pause-before-submit-still-stopped",
            machine.globalState == GlobalState.STOPPED)
        val machine2 = StateMachine()
        machine2.registerHandler(
            PurchaseStep.S1_ENTRY,
            StepHandler { StepOutcome.Block(reason = "PRE_SUBMIT_BLOCK", errorId = "E04") },
        )
        machine2.start()
        machine2.executeCurrentStep()
        check("machine/d21-block-before-submit-still-blocked",
            machine2.globalState == GlobalState.BLOCKED)
    }
    run {
        // S9 explicit decline, via the machine: D-34 resolved
        // the former open item — after submit an explicit
        // refusal now ends as DECLINED, not UNKNOWN.
        val driver = FakePageDriver(stateModel(PageState.ENTRY))
        val machine = StateMachine(
            config = StateMachine.Config(s7Unlocked = true),
        )
        for (step in PurchaseStep.entries) {
            if (step != PurchaseStep.S8_SUBMIT_CONFIRM && step != PurchaseStep.S9_RESULT) {
                machine.registerHandler(step, StepHandler { StepOutcome.Advance })
            }
        }
        machine.registerHandler(
            PurchaseStep.S8_SUBMIT_CONFIRM,
            S8SubmitConfirmHandler(driver, summary, { noUnverified() }, { machine.markSubmitted() }),
        )
        machine.registerHandler(PurchaseStep.S9_RESULT, S9ResultHandler(driver))
        machine.start()
        repeat(7) { machine.executeCurrentStep() }
        driver.setModel(submitModel())
        machine.executeCurrentStep()
        driver.setModel(resultModel(ResultStatus.DECLINED))
        machine.executeCurrentStep()
        check("machine/s9-declined-after-submit-declined-D34",
            machine.globalState == GlobalState.DECLINED)
    }

    println(if (failures == 0) "ALL TESTS PASSED" else "$failures TEST(S) FAILED")
    if (failures > 0) kotlin.system.exitProcess(1)
}
