# P1 App 骨架＋P2 狀態機核心 — build notes (Fire)

工作包：階段 1 P1＋P2（協調者 2026-10-27 派發）。S1–S3 及
S4–S5 頁面邏輯留待之後工作包，本包一次過交晒 S1–S5 實作
以外的骨架＋核心；S7 PAYMENT_FILL 仍未放行。

## 內容
- P1 骨架（Android 來源，未編譯，見下「已驗／未驗」）：
  - `settings.gradle`、`build.gradle`（專案）、`app/build.gradle`
    — 單一 `:app` 模組，Kotlin 2.0.21（與 S6 JVM 工具鏈同版本）。
  - `app/src/main/AndroidManifest.xml` — MainActivity 為啟動頁；
    INTERNET 權限已宣告（未來 WebView 步驟先用得著），骨架
    本身唔載入任何 URL。
  - `app/src/main/java/com/example/buypilot/MainActivity.kt`
    — 殼 Activity：顯示狀態機步驟／全域／事件，開始／執行
    本步／暫停／繼續／取消五個掣 1:1 對應狀態機 API；
    WebView 佔位載入 nothing、JavaScript 已關（導航／JS／
    WebView 回調屬 S1–S5 包，嗰時先接管呢個 WebView）。
    MainActivity 內無任何卡輸入、卡欄位、卡狀態。
- P2 核心（純 Kotlin，無 Android 依賴，已 JVM 驗證）：
  - `state/PurchaseStep.kt` — S1–S9 凍結編號及順序，S9 之後無下一步。
  - `state/GlobalState.kt` — RUNNING／WAITING／BLOCKED／
    STOPPED／CANCELLED／DECLINED／FAILED／UNKNOWN；
    終端為 CANCELLED／DECLINED／FAILED／UNKNOWN；
    未開始前全域為 null（顯示「未開始」，唔係新狀態）。
  - `state/StepOutcome.kt` — Advance／Stay／Pause／Wait／
    Block／Cancel／Decline／Fail；StepHandler 介面；
    NotImplementedStepHandler（S1–S5 未到包時的佔位：
    只會 Pause，永不推進、永不判 Fail、永不掂頁面）。
  - `state/StateMachine.kt` — 唯一擁有轉移的類別：
    WAITING 記錄返原步、resume 回原步＋需重驗；
    BLOCKED 無 resume API（E03／E04 永不繞過），只可
    resetForNewRun() 開新一輪；提交優先序集中一處
    （S8 markSubmitted() 後，背景／斷網／崩潰／取消／
    失敗／WAITING 一律變 UNKNOWN，絕不變 CANCELLED／
    FAILED；其後修訂：D-21 將 handler Pause／Block
    納入同一規則，D-34 定已提交後明確拒絕係已知
    結果、變 DECLINED 唔變 UNKNOWN；清卡方面：原文
    的清卡回調先經 D-33 喺 Pause／Block 兩條轉移
    取消，再經 D-35 全面取消 — 核心而家無清卡回調、
    無任何自動刪除已輸入資料嘅觸發，取代本段及
    本文件其他段落對清卡回調的描述）；
    提交前：背景→CANCELLED（E23）、斷網→STOPPED（E20）、
    崩潰／工作階段過期→STOPPED（機內模擬中斷；真崩潰
    會重啟 App，下一輪係新一輪）；
    S7 鎖：s7Unlocked=false 時到 S7 即 STOPPED，S7
    handler 一次都唔會被叫；S1 時間偏差檢查見下。
  - `state/StateMachineTest.kt` ＋ `jvm-test-output.txt`
    — 51/51 PASS（kotlinc 2.0.21、Temurin 17.0.21，
    2026-10-27；原 50 項＋D-34 修訂新增 1 項 decline
    已提交後變 DECLINED 測試）。測試檔同輸出檔入面
    完全無卡值，連假資料卡號都無（D-35 後核心無
    清卡行為，清卡計次斷言已全數移除）。

## S1 時間偏差檢查（O-01 未決，數值無發明）
- Config.timeDeviationLimitMs 預設 null＝未決：檢查結果
  記為 LimitUndecided，永不扮作已通過，亦不阻塞開跑。
- 只有當上限＋量度來源齊晒、偏差超上限時先擋：
  開跑前超上限＝S1 位置 STOPPED、無 handler 執行，
  修正裝置時間＋resume 可繼續；行緊時超上限亦
  STOPPED＋需重驗（主文件：行緊→STOPPED）。
  O-01 上限數值本身仍待 Kenneth 裁決，本包無定。

## QA S6 第一審例外項 — 本包點處理（無冒稱）
1. 裝置層未完成（同 D-13 同類限制，延續、唔係已解決）：
   狀態機核心已 JVM 編譯＋測試，但 Gradle／Manifest／
   MainActivity 未喺本環境編譯或運行（無 Android SDK／
   裝置／模擬器）。本通過只限 JVM 核心，絕不引用為
   已在目標 WebView／真裝置驗證。
2. Water 術語對齊 — 已按 D-19 定案（本段舊「待合併確認」
   寫法已取代，2026-10-27 更新）：
   合併檔以程式名為準：idleTimeoutMs（120 秒）、
   absoluteTimeoutMs（5 分鐘）；CARD_IDLE_TIMEOUT_MS／
   CARD_ABSOLUTE_TIMEOUT_MS 只作舊稱對照，新內容唔再
   混用。逾時起點統一為 begin()／進入 S6，唔係物件構造時。
   數值及行為不變，只係用語對齊。本包無新增任何卡逾時
   常數，狀態機本身無步驟逾時常數，步驟逾時（如有）屬未來包。
3. UI 暫存狀態：S6 PaymentInputScreen 的 Compose String
   暫存（提交即清、只顯示遮蔽）維持原狀，本包無改、
   無扮作已解決。P1 MainActivity 本身無卡欄位，所以呢
   個保留項唔會擴散到骨架畫面。

## 與 app-s6 的合併路徑（同一 App，唔係兩個 App）
- 套件同為 com.example.buypilot；類名無重複
  （MainActivity 殼 vs PaymentHostActivity S6 宿主）。
- 裝置建置時將 app-s6 的 payment 來源併入本模組。
  原計劃「將狀態機的 onClearCardData 接去
  CardSession.clear」已按 D-35 取消（唔再係待辦）：
  狀態機已無清卡回調，唔存在呢條接線。
- S6 宿主的 FLAG_SECURE 保留在 S6 畫面，唔會因為
  殼無設 FLAG_SECURE 而消失。

## 真裝置運行路徑及時程（(b) 測試的前置）
本包之後，骨架可喺真裝置運行嘅路徑（需 S1–S5 包完成
先做到完整流程，骨架本身只驗到以下幾步）：
1. 有 Android SDK 的機器開 Android Studio，開本專案，
   接真裝置或模擬器，執行 `./gradlew installDebug`。
   SDK／AGP 版本如有不符，第一次建置的報錯先係準，
   修正要入建置包摘要，唔好喺度靜靜改規格。
2. 裝置上預期見到：啟動頁顯示「未開始」→開始→S1，
   執行本步→因 S1 未實作而 STOPPED（佔位行為，如實
   顯示原因 STEP_NOT_IMPLEMENTED），繼續／取消掣正常。
   WebView 佔位保持空白、唔載入任何頁面。
3. 之後工作包次序（按 Fire 自定時間表，S6 包已用過的
   同一套次序）：S1–S3 包 → S4–S5 包 → 裝置建置＋
   (b) 真頁面測試（目標 App WebView、假資料經 S6、
   渲染後即時 DOM 逐欄 frame 布林、唯一偵測、3 欄
   E16 讀回、裝置／Android／WebView 版本，經 QA
   第一審後送 Kenneth 裁 S7 解鎖）。(b) 測試本身唔屬本包。

## 已驗／未驗（誠實範圍）
- 已驗：狀態機核心 JVM 編譯＋50/50 測試（轉移鏈、
  佔位 Pause、Stay 重試鉤、WAITING 回原步、BLOCKED
  無 resume、提交前後中斷對照、S7 鎖及測試用解鎖對照、
  S9 完成、行緊時間偏差 STOPPED、事件記錄只含
  步驟代號／全域／原因）。
- 未驗：Gradle／Manifest／MainActivity 未編譯未運行
  （無 SDK／裝置）；S1–S5 頁面邏輯未寫（佔位而已）；
  S6 接駁（清卡回調接線）未做；(b) 真頁面測試未做；
  S7 未放行，生產設定 s7Unlocked=false 硬編碼於
  MainActivity，測試用解鎖只存在於 JVM 測試機，唔係
  產品解鎖。
